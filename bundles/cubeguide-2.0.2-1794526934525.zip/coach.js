"use strict";
/* ===== Ассистент сборки (guided CFOP) =====
   Смотрит на живое состояние GAN-кубика (facelets), вступает после сборки креста
   и подсказывает: F2L-пара → её случай, затем OLL, затем PLL.
   Всё распознавание детерминированное — переиспользуем движок из renderer.js (CubeEngine). */
(function () {
  const E = window.CubeEngine, F = window.Facelet;
  const $ = id => document.getElementById(id);

  /* ---------- переключение разделов в шапке ---------- */
  const nav = $('topnav');
  if (nav) {
    nav.addEventListener('click', ev => {
      const b = ev.target.closest('.navtab'); if (!b) return;
      const v = b.dataset.v;
      [...nav.querySelectorAll('.navtab')].forEach(t => t.classList.toggle('on', t === b));
      document.querySelectorAll('.view').forEach(el => { el.hidden = el.id !== 'view-' + v; });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (!E || !F) { const b = $('coachBody'); if (b) b.innerHTML = '<p class="cmsg">Движок не загрузился.</p>'; return; }

  /* ================= конвертер facelets → модель движка =================
     GAN-facelets: белый=U, красный=R, зелёный=F, жёлтый=D, оранж=L, синий=B (URFDLB).
     Движок: жёлтый=U, белый=D, красный=F, оранж=B, зелёный=R, синий=L.
     Между системами — жёсткий поворот M: (x,y,z)→(z,-y,x); цвета переклеиваем по центрам. */
  const LET2COL = { U: E.COL.D, D: E.COL.U, R: E.COL.F, L: E.COL.B, F: E.COL.R, B: E.COL.L };
  const M = v => [v[2], -v[1], v[0]];
  const FACES = {
    U: { base: 0,  pos: (r, c) => [c - 1, 1, r - 1],  nrm: [0, 1, 0] },
    R: { base: 9,  pos: (r, c) => [1, 1 - r, 1 - c],  nrm: [1, 0, 0] },
    F: { base: 18, pos: (r, c) => [c - 1, 1 - r, 1],  nrm: [0, 0, 1] },
    D: { base: 27, pos: (r, c) => [c - 1, -1, 1 - r], nrm: [0, -1, 0] },
    L: { base: 36, pos: (r, c) => [-1, 1 - r, c - 1], nrm: [-1, 0, 0] },
    B: { base: 45, pos: (r, c) => [1 - c, 1 - r, -1], nrm: [0, 0, -1] }
  };
  function faceletsToCubies(fac) {
    const byPos = new Map();
    for (const f in FACES) {
      const FC = FACES[f];
      for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) {
        const letter = fac[FC.base + r * 3 + c];
        const p = M(FC.pos(r, c)), n = M(FC.nrm), key = p.join(',');
        if (!byPos.has(key)) byPos.set(key, { p: p.slice(), st: [] });
        byPos.get(key).st.push({ n, c: LET2COL[letter] || '#888' });
      }
    }
    return [...byPos.values()];
  }

  /* перекрасить куб так, чтобы центры стали каноничными (после поворота y для нужного слота) */
  function recolor(cs) {
    const map = {};
    for (const nk in E.NKEY) { const n = nk.split(',').map(Number); map[E.readSt(cs, n, n)] = E.COL[E.NKEY[nk]]; }
    for (const cu of cs) for (const s of cu.st) s.c = map[s.c] || s.c;
  }
  const yTurn = cs => E.applyMove(cs, { eng: 'y', face: 'y' });

  const AUF_STR = ['', 'U', 'U2', "U'"];   // доворот верха

  /* ---------- индексы случаев из готовой базы ---------- */
  /* ВАЖНО: f2lSigRaw из движка сортирует нормали ребра без привязки к цвету и потому
     НЕ различает перевёрнутое ребро — разные случаи схлопывались в один, и подсказка
     не решала ситуацию. Своя полная сигнатура: позиция + какой цвет на какой нормали. */
  function f2lSigFull(cs) {
    const { corner, edge } = E.findPair(cs);
    if (!corner || !edge) return null;
    const st = cu => cu.st.map(s => s.n.join('') + ':' + s.c).sort().join('|');
    return corner.p.join(',') + '#' + st(corner) + ' ' + edge.p.join(',') + '#' + st(edge);
  }
  const F2L_INDEX = {}, OLL_INDEX = {}, PLL_INDEX = {};
  E.DATA.f2l.forEach(e => { const s = f2lSigFull(e.states[0]); if (s && (!(s in F2L_INDEX) || e.mc < F2L_INDEX[s].mc)) F2L_INDEX[s] = e; });
  E.DATA.oll.forEach(e => { OLL_INDEX[E.aufCanon(e.states[0], E.ollSigRaw)] = e; });

  /* состояние, которое решается данным алгоритмом (собранный куб «назад» по ходам) */
  function stateSolvedBy(alg) {
    const cs = E.solvedCube(), moves = E.parseAlg(alg);
    for (let i = moves.length - 1; i >= 0; i--) {
      const m = moves[i];
      E.applyMove(cs, { eng: m.eng, face: m.face, prime: m.dbl ? false : !m.prime, dbl: m.dbl });
    }
    return cs;
  }
  /* PLL-случай определяется доворотом И ДО, И ПОСЛЕ алгоритма. Индексируем все 4 пост-доворота,
     иначе распознаётся лишь ~38% реальных ситуаций (остальные падали в «доверни верх»). */
  /* ВАЖНО: берём e.eff, а не e.alg — в eff уже скомпенсирован поворот всего куба
     (Ga/Gc/Ja/... начинаются с y), иначе состояние выходит с повёрнутыми центрами
     и ключ индекса не совпадает ни с одной реальной ситуацией. */
  E.DATA.pll.forEach(e => {
    for (let post = 0; post < 4; post++) {
      const alg = (e.eff + ' ' + AUF_STR[post]).trim();
      const state = stateSolvedBy(alg);
      const key = E.aufCanon(state, E.pllSigRaw);
      if (!(key in PLL_INDEX)) PLL_INDEX[key] = { entry: e, post, state, alg };
    }
  });

  /* ---------- распознавание стадий ---------- */
  const eqp = (p, a, b, c) => p[0] === a && p[1] === b && p[2] === c;
  const CROSS = [[0, -1, 1, 0, 0, 1], [1, -1, 0, 1, 0, 0], [0, -1, -1, 0, 0, -1], [-1, -1, 0, -1, 0, 0]];
  function crossEdges(cs) {
    let n = 0;
    for (const [px, py, pz, nx, ny, nz] of CROSS) {
      const down = E.readSt(cs, [px, py, pz], [0, -1, 0]);
      const side = E.readSt(cs, [px, py, pz], [nx, ny, nz]);
      if (down === E.COL.D && side === E.COL[E.NKEY[[nx, ny, nz].join(',')]]) n++;
    }
    return n;
  }
  function frSolved(norm) {
    return E.readSt(norm, [1, -1, 1], [0, -1, 0]) === E.COL.D &&
           E.readSt(norm, [1, -1, 1], [0, 0, 1]) === E.COL.F &&
           E.readSt(norm, [1, -1, 1], [1, 0, 0]) === E.COL.R &&
           E.readSt(norm, [1, 0, 1], [0, 0, 1]) === E.COL.F &&
           E.readSt(norm, [1, 0, 1], [1, 0, 0]) === E.COL.R;
  }
  function analyzeF2L(base) {
    const cands = []; let solved = 0;
    const rot = E.clone(base);
    for (let k = 0; k < 4; k++) {
      if (k > 0) yTurn(rot);
      const sideF = E.readSt(rot, [0, 0, 1], [0, 0, 1]);   // истинные цвета слота (до перекраски)
      const sideR = E.readSt(rot, [1, 0, 0], [1, 0, 0]);
      const norm = E.clone(rot); recolor(norm);
      if (frSolved(norm)) { solved++; continue; }
      const { corner, edge } = E.findPair(norm);
      if (!corner || !edge) continue;
      const entry = F2L_INDEX[f2lSigFull(norm)];
      const cornerBuried = corner.p[1] === -1 && !eqp(corner.p, 1, -1, 1);
      const edgeBuried = edge.p[1] === 0 && !eqp(edge.p, 1, 0, 1);
      const penalty = (cornerBuried ? 100 : 0) + (edgeBuried ? 100 : 0);
      const mc = entry ? entry.mc : 12;
      cands.push({ k, sideF, sideR, entry, penalty, score: penalty + mc });
    }
    return { solved, cands };
  }
  function bestOf(cands) {
    return cands.slice().sort((a, b) => a.score - b.score || a.penalty - b.penalty)[0] || null;
  }
  /* кубик собран с точностью до доворота верха */
  function solvedUpToAUF(base) {
    const t = E.clone(base);
    for (let k = 0; k < 4; k++) {
      if (k > 0) E.applyMove(t, { eng: 'U', face: 'U' });
      let ok = true;
      for (const cu of t) { for (const s of cu.st) if (E.COL[E.NKEY[s.n.join(',')]] !== s.c) { ok = false; break; } if (!ok) break; }
      if (ok) return true;
    }
    return false;
  }
  /* пара с боковыми цветами cA,cB реально стоит в своём слоте (угол+ребро дома и верно) */
  function slotSolvedByColors(base, cA, cB) {
    const want = [cA, cB].sort().join();
    const rot = E.clone(base);
    for (let k = 0; k < 4; k++) {
      if (k > 0) yTurn(rot);
      const sF = E.readSt(rot, [0, 0, 1], [0, 0, 1]), sR = E.readSt(rot, [1, 0, 0], [1, 0, 0]);
      if ([sF, sR].sort().join() !== want) continue;
      const norm = E.clone(rot); recolor(norm);
      return frSolved(norm);
    }
    return false;
  }
  function analyze(fac) {
    if (fac === F.SOLVED) return { stage: 'solved' };
    const base = faceletsToCubies(fac);
    if (E.isLastLayer(base)) {
      if (!E.pllOriented(base)) {                      // ---- OLL ----
        const entry = OLL_INDEX[E.aufCanon(base, E.ollSigRaw)];
        const r = { stage: 'oll', entry, auf: 0, live: null };
        if (entry) {
          const k = aufFor(base, entry.states[0], E.ollSigRaw);
          if (k >= 0) { r.auf = k; r.live = buildLive(base, (AUF_STR[k] + ' ' + entry.eff).trim(), entry); }
        }
        return r;
      }
      // ---- PLL ---- (случай задан доворотом и до, и после алгоритма)
      const rec = PLL_INDEX[E.aufCanon(base, E.pllSigRaw)];
      const r = { stage: 'pll', entry: rec && rec.entry, auf: 0, post: rec ? rec.post : 0, live: null };
      if (rec) {
        const k = aufFor(base, rec.state, E.pllSigRaw);
        if (k >= 0) { r.auf = k; r.live = buildLive(base, (AUF_STR[k] + ' ' + rec.alg).trim(), rec.entry); }
      }
      return r;
    }
    const crossN = crossEdges(base);
    if (crossN < 4) return { stage: 'cross', crossN };
    const f = analyzeF2L(base);
    return { stage: 'f2l', solved: f.solved, best: bestOf(f.cands), base };
  }

  /* ---------- имена цветов ---------- */
  const CNAME = {}; CNAME[E.COL.F] = 'красный'; CNAME[E.COL.R] = 'зелёный'; CNAME[E.COL.B] = 'оранжевый'; CNAME[E.COL.L] = 'синий'; CNAME[E.COL.U] = 'жёлтый'; CNAME[E.COL.D] = 'белый';
  const swatch = hex => `<span class="csw" style="background:${hex}"></span>`;

  /* ---------- доворот верха (AUF) под конкретно твою ситуацию ---------- */
  function aufFor(base, entryState, sigFn) {
    const target = sigFn(entryState), t = E.clone(base);
    for (let k = 0; k < 4; k++) {
      if (sigFn(t) === target) return k;
      E.applyMove(t, { eng: 'U', face: 'U' });
    }
    return -1;
  }
  /* сколько ходов кубик реально отрапортует: U2 — это две четверти, слайс/широкий — два слоя,
     повороты всего куба он не видит вовсе. Нужно для честного допуска на ошибки. */
  function reportedCost(alg) {
    let n = 0;
    for (const m of E.parseAlg(alg)) {
      if (m.rot) continue;
      n += (m.wide || /[MES]/.test(m.face) ? 2 : 1) * (m.dbl ? 2 : 1);
    }
    return n;
  }
  /* карточка, построенная из ТВОЕГО реального состояния: свои цвета, свой доворот */
  function buildLive(baseCubies, algStr, meta) {
    const moves = E.parseAlg(algStr), cs = E.clone(baseCubies), states = [E.clone(cs)];
    for (const m of moves) { E.applyMove(cs, m); states.push(E.clone(cs)); }
    return { label: meta.label, type: meta.type, mode: meta.mode, mc: moves.length, eff: algStr, moves, states };
  }
  /* перекраска схемы F2L под реальные цвета твоей пары */
  const OPP = {}; OPP[E.COL.F] = E.COL.B; OPP[E.COL.B] = E.COL.F; OPP[E.COL.R] = E.COL.L; OPP[E.COL.L] = E.COL.R;
  function remapHTML(html, sideF, sideR) {
    if (sideF === E.COL.F && sideR === E.COL.R) return html;
    const map = {};
    map[E.COL.F] = sideF; map[E.COL.B] = OPP[sideF]; map[E.COL.R] = sideR; map[E.COL.L] = OPP[sideR];
    return html.replace(/#[0-9a-fA-F]{6}/g, m => map[m.toLowerCase()] || m);
  }

  /* ---------- отрисовка карточки случая ---------- */
  /* startState — состояние подключённого кубика; 3D показывает пример на нём, а не на «идеальном» */
  /* Живая подсказка: ходы — одной строкой на всю ширину, картинка ситуации — под ними,
     без 3D-проигрывателя (он есть в «Схемах»). Сделанные ходы потом прячем (см. progress). */
  function caseCardHTML(e, labelText) {
    const strip = e.moves.map((mv, i) => E.moveCard(e.states[i], mv, i + 1)).join('');
    return `<div class="csolve"><div class="cstrip">${strip}</div>`
      + `<div class="casebox ccase">${E.caseDiagram(e.states[0], e.mode)}<div class="clabel">${labelText || e.label}</div></div></div>`;
  }

  /* ---------- где ты в схеме ----------
     Для каждого шага схемы заранее считаем, как должен выглядеть кубик после него,
     и сравниваем с живым — с точностью до поворота всего куба (y, x кубик не видит,
     а d — это ход грани плюс поворот). Самый дальний совпавший шаг = сделано. */
  const ROT = [E.parseAlg('x')[0], E.parseAlg('y')[0]];
  const keyOf = cs => cs.filter(cu => cu.st.length)
    .map(cu => cu.p.join(',') + ':' + cu.st.map(t => t.n.join('') + t.c).sort().join('|')).sort().join(' ');
  function rotKeys(cs) {
    const keys = new Set(), q = [E.clone(cs)];
    while (q.length && keys.size < 24) {
      const c = q.shift(), k = keyOf(c);
      if (keys.has(k)) continue;
      keys.add(k);
      for (const r of ROT) { const d = E.clone(c); E.applyMove(d, r); q.push(d); }
    }
    return keys;
  }
  function trackFor(startCs, moves) {
    const cs = E.clone(startCs), out = [rotKeys(cs)];
    for (const m of moves) { E.applyMove(cs, m); out.push(rotKeys(cs)); }
    return out;
  }
  function updateProgress(c) {
    if (!c || !c.track) return;
    const k = keyOf(faceletsToCubies(last));
    for (let i = c.track.length - 1; i >= 0; i--) if (c.track[i].has(k)) { c.progress = i; break; }
    const cards = body.querySelectorAll('.cstrip .move'), p = c.progress || 0;
    cards.forEach((el, i) => { el.classList.toggle('gone', i < p); el.classList.toggle('now', i === p); });
  }
  function toSchemes(mode, label) {
    return `<button class="act ghost cgo" data-mode="${mode}" data-label="${label || ''}">Открыть в «Схемах» →</button>`;
  }

  /* ---------- состояние UI ---------- */
  /* Подсказка работает всегда, пока кубик подключён: её не гасят ни скрамбл, ни таймер —
     сессией («Разобрать» → «Сборка») рулит session.js, а ассистент просто ведёт по CFOP. */
  let connected = false, last = F.SOLVED;
  let commit = null;    // зафиксированная подсказка: держим её, пока цель не достигнута
  let movesSince = 0;   // ходов с момента показа: перебор = сбились, пересчитываем
  let fresh = false;    // пришло ли состояние с кубика после старта/подключения (иначе оно устаревшее)
  const retryNote = `<p class="cretry">⟳ Что-то пошло не так — пересчитал под текущее состояние кубика и подобрал ближайший вариант.</p>`;
  const body = $('coachBody'), trailEl = $('coachTrail');

  /* ---------- чекпоинты этапов ----------
     Внутри алгоритма нижние слои временно разобраны — на OLL с широкими ходами особенно.
     Честный анализ в этот момент говорит «крест 3/4», и подсказка откатывалась на этап
     назад прямо посреди комбинации. Поэтому пройденное запоминаем: назад этап уходит
     только когда подсказки на руках нет И кубик держится ниже чекпоинта много ходов —
     то есть его действительно разобрали, а не крутят алгоритм. */
  const RANK = { cross: 0, f2l: 1, oll: 2, pll: 3, solved: 4 };
  const MISS_TOL = 6;    // запас ходов сверх длины алгоритма, прежде чем пересчитывать
  const HARD_TOL = 20;   // ушли совсем далеко — отпускаем подсказку, даже если кубик разобран
  const BACK_OFF = 10;   // столько ходов ниже чекпоинта = этап правда потерян
  let reached = 'cross'; // самый дальний пройденный этап
  let slotsDone = 0;     // зачтённые F2L-слоты
  let lowStreak = 0;     // сколько подряд состояний кубик стоит ниже чекпоинта
  function resetProgress() { reached = 'cross'; slotsDone = 0; lowStreak = 0; }

  /* полоска этапов: видно, что уже зачтено, и подсказка не «прыгает» назад незаметно */
  function trail(cur) {
    if (!trailEl) return;
    const r = RANK[reached];
    const step = (key, label, note) => {
      const done = r >= RANK[key] + 1, now = !done && key === cur;
      return `<span class="cstep ${done ? 'done' : now ? 'now' : ''}">${done ? '✓ ' : ''}${label}`
           + `${note && !done ? ` <i>${note}</i>` : ''}</span>`;
    };
    trailEl.innerHTML =
        step('cross', 'Крест', null)
      + step('f2l', 'F2L', slotsDone + '/4')
      + step('oll', 'OLL', null)
      + step('pll', 'PLL', null);
  }

  let shownHTML = null;
  function show(html) { if (html === shownHTML) return; shownHTML = html; body.innerHTML = html; E.mountPlayers(body); }

  function stageBadge(txt, cls) { return `<span class="cstage ${cls || ''}">${txt}</span>`; }
  function dots(done, total) {
    let s = ''; for (let i = 0; i < total; i++) s += `<span class="cdot ${i < done ? 'on' : ''}"></span>`;
    return `<span class="cdots">${s}</span>`;
  }
  const hold = txt => `<p class="chold">✓ ${txt} Подсказка не пропадёт, пока не увижу, что готово — делай спокойно.</p>`;

  /* ---------- построители карточек ---------- */
  function crossHTML(a) {
    return `<div class="chead">${stageBadge('Крест', 'wait')}${dots(a.crossN, 4)}<span class="cprog">${a.crossN}/4 рёбер</span></div>`
      + `<p class="cmsg">Собери белый крест снизу — правильные боковые цвета к центрам. Вступлю, как встанут все 4 ребра.</p>`;
  }
  function solvedHTML() {
    return `<div class="chead">${stageBadge('Собрано!', 'ok')}</div><p class="cmsg">🎉 Кубик собран. Отличная работа! Жми «Разобрать» — и по новой.</p>`;
  }
  function f2lHTML(a) {
    const b = a.best, head = `<div class="chead">${stageBadge('F2L', 'f2l')}${dots(a.solved, 4)}<span class="cprog">${a.solved}/4 слота</span></div>`;
    const nm = `${swatch(b.sideF)}${CNAME[b.sideF]} + ${swatch(b.sideR)}${CNAME[b.sideR]}`;
    const txt = b.penalty >= 100
      ? `Самая доступная пара: <b>${nm}</b>. Одна из деталей застряла в чужом слоте — этот случай её достанет и поставит на место.`
      : `Бери пару <b>${nm}</b> — сейчас это самый короткий вариант, он гарантированно ставит пару в слот.`;
    // держи кубик так, чтобы пара была спереди-справа (y^k), схему красим в цвета твоей пары
    const turn = b.k ? `<p class="cturn">↻ Сначала поверни весь кубик: <b>${AUF_STR[b.k].replace('U', 'y').replace(/'/g, '′')}</b> — чтобы пара <b>${CNAME[b.sideF]} + ${CNAME[b.sideR]}</b> была спереди-справа, как на схеме.</p>` : '';
    // 3D стартует с твоего живого кубика, уже довёрнутого на y^k — как ты его и возьмёшь в руки.
    // Ходы те же, что на картинках, поэтому подсветка и перемотка по карточкам совпадают.
    const held = E.clone(a.base); for (let i = 0; i < b.k; i++) yTurn(held);
    const card = remapHTML(caseCardHTML(b.entry, nm.replace(/<[^>]+>/g, '').trim()), b.sideF, b.sideR);
    a.track = trackFor(held, E.parseAlg(b.entry.eff));
    return head
      + `<p class="cmsg">${txt} Случай <b>«${b.entry.label}»</b>, ${b.entry.mc} ход. — <code>${b.entry.eff.replace(/'/g, '′')}</code></p>`
      + turn + card
      + hold('Пройди все ходы — как только пара сядет в слот, покажу следующую.')
      + `<div class="row">${toSchemes('f2l', b.entry.label)}</div>`;
  }
  function ollHTML(a) {
    const e = a.live || a.entry;
    const auf = a.auf ? `<p class="cturn">↻ Доворот верха уже включён первым ходом: <b>${AUF_STR[a.auf].replace(/'/g, '′')}</b> — схема показана под твою ситуацию.</p>` : '';
    return `<div class="chead">${stageBadge('OLL', 'oll')}<span class="cprog">ориентация верха</span></div>`
      + `<p class="cmsg">Твой случай: <b>«${a.entry.label}»</b>${a.entry.type ? ' · ' + a.entry.type : ''}, ${e.mc} ход. — <code>${e.eff.replace(/'/g, '′')}</code></p>`
      + auf + caseCardHTML(e, a.entry.label)
      + hold('Сделай весь алгоритм — держу, пока верх не станет жёлтым.')
      + `<div class="row">${toSchemes('oll', a.entry.label)}</div>`;
  }
  function pllHTML(a) {
    const e = a.live || a.entry;
    const parts = [];
    if (a.auf) parts.push(`доворот <b>${AUF_STR[a.auf].replace(/'/g, '′')}</b> в начале`);
    if (a.post) parts.push(`доворот <b>${AUF_STR[a.post].replace(/'/g, '′')}</b> в конце`);
    const auf = parts.length
      ? `<p class="cturn">↻ Схема подогнана под твою ситуацию: ${parts.join(' и ')} — уже включены в ходы ниже.</p>` : '';
    return `<div class="chead">${stageBadge('PLL', 'pll')}<span class="cprog">перестановка верха</span></div>`
      + `<p class="cmsg">Финиш! Случай <b>«${a.entry.label}»</b>${a.entry.type ? ' · ' + a.entry.type : ''}, ${e.mc} ход. — <code>${e.eff.replace(/'/g, '′')}</code></p>`
      + auf + caseCardHTML(e, a.entry.label)
      + hold('Сделай весь алгоритм — держу, пока кубик не соберётся.')
      + `<div class="row">${toSchemes('pll', a.entry.label)}</div>`;
  }

  /* цель зафиксированной подсказки достигнута?
     Внутри алгоритма крест обычно временно сломан — это и есть надёжный признак «ещё крутит». */
  function commitDone(c, base) {
    if (c.kind === 'f2l') {
      if (E.isLastLayer(base)) return true;                   // все 4 пары собраны
      if (crossEdges(base) !== 4) return false;               // алгоритм ещё идёт
      if (slotSolvedByColors(base, c.pair[0], c.pair[1])) return true;  // пара села в слот
      return analyzeF2L(base).solved > c.solved;              // собрал другую пару — тоже прогресс
    }
    if (c.kind === 'oll') return E.isLastLayer(base) && E.pllOriented(base);
    if (c.kind === 'pll') return solvedUpToAUF(base);
    return true;
  }

  function render() {
    if (!body) return;
    if (!connected) {
      commit = null; if (trailEl) trailEl.innerHTML = '';
      show(`<p class="cmsg">☝ Подключи кубик и нажми «Калибровать» на собранном — дальше просто крути.</p>`);
      return;
    }

    // не строим подсказку по устаревшему состоянию — сначала спросим кубик, как он стоит сейчас
    if (!fresh) {
      show(`<p class="cmsg">Смотрю на кубик… Крутани любую грань, если я не отзовусь.</p>`);
      if (window.SmartCube && SmartCube.requestFacelets) { try { SmartCube.requestFacelets(); } catch (e) {} }
      return;
    }

    const base = faceletsToCubies(last);
    const a = analyze(last);
    const rank = RANK[a.stage];

    // вперёд чекпоинт двигаем сразу и без условий
    if (rank > RANK[reached]) reached = a.stage;
    if (a.stage === 'f2l' && a.solved > slotsDone) slotsDone = a.solved;
    if (rank >= RANK[reached]) lowStreak = 0; else lowStreak++;

    // держим зафиксированную подсказку, пока ассистент не убедится, что цель выполнена
    let note = '';
    if (commit) {
      if (commitDone(commit, base)) { commit = null; lowStreak = 0; }   // готово — показываем следующее
      // пересчитываем только если кубик стоит на своём этапе: посреди комбинации он ниже,
      // и «промах» там означает не ошибку, а то, что алгоритм ещё не дошёл до конца
      else if (movesSince > commit.mc + MISS_TOL && rank >= RANK[reached]) { commit = null; note = retryNote; }
      else if (movesSince > commit.mc + HARD_TOL) { commit = null; note = retryNote; }
      else { trail(commit.kind); show(commit.html); updateProgress(commit); return; }
    }

    // подсказки на руках нет, а кубик ниже чекпоинта — скорее всего комбинация ещё идёт
    if (rank < RANK[reached]) {
      if (reached !== 'solved' && lowStreak < BACK_OFF) { trail(reached); return; }    // держим экран как есть
      resetProgress(); reached = a.stage;                                              // нет, правда разобрали
      if (a.stage === 'f2l') slotsDone = a.solved;
    }

    trail(a.stage);
    if (a.stage === 'solved') { show(solvedHTML()); return; }
    if (a.stage === 'cross') { show(note + crossHTML(a)); return; }
    if (a.stage === 'f2l') {
      const head = `<div class="chead">${stageBadge('F2L', 'f2l')}${dots(a.solved, 4)}<span class="cprog">${a.solved}/4 слота</span></div>`;
      const b = a.best;
      if (!b) { show(head + `<p class="cmsg">Ищу пару…</p>`); return; }
      if (!b.entry) {
        const nm = `${swatch(b.sideF)}${CNAME[b.sideF]} + ${swatch(b.sideR)}${CNAME[b.sideR]}`;
        show(note + head + `<p class="cmsg">Самая доступная пара: <b>${nm}</b>. Случай редкий — покрути пару наверх (R U R′ / F′ U′ F), и я покажу точный случай.</p>`);
        return; // не фиксируем: пусть обновляется, пока пара не станет распознаваемой
      }
      const html = note + f2lHTML(a);
      commit = { kind: 'f2l', pair: [b.sideF, b.sideR], solved: a.solved, mc: reportedCost(b.entry.eff), html, track: a.track, progress: 0 };
      movesSince = 0; show(commit.html); updateProgress(commit); return;
    }
    if (a.stage === 'oll') {
      if (!a.entry) { show(note + `<div class="chead">${stageBadge('OLL', 'oll')}<span class="cprog">ориентация верха</span></div><p class="cmsg">Вижу необычную ориентацию верха — покрути верх (U) и я узнаю случай.</p>`); return; }
      commit = { kind: 'oll', mc: reportedCost((a.live || a.entry).eff), html: note + ollHTML(a),
                 track: a.live ? trackFor(a.live.states[0], a.live.moves) : null, progress: 0 };
      movesSince = 0; show(commit.html); updateProgress(commit); return;
    }
    if (a.stage === 'pll') {
      if (!a.entry) { show(note + `<div class="chead">${stageBadge('PLL', 'pll')}<span class="cprog">перестановка верха</span></div><p class="cmsg">Вижу перестановку верха — доверни верх (U), чтобы кубик встал на место.</p>`); return; }
      commit = { kind: 'pll', mc: reportedCost((a.live || a.entry).eff), html: note + pllHTML(a),
                 track: a.live ? trackFor(a.live.states[0], a.live.moves) : null, progress: 0 };
      movesSince = 0; show(commit.html); updateProgress(commit); return;
    }
  }

  /* ---------- переход в «Схемы» на нужный случай ---------- */
  body && body.addEventListener('click', ev => {
    const b = ev.target.closest('.cgo'); if (!b) return;
    if (window.CoachNav) window.CoachNav(b.dataset.mode, b.dataset.label);
  });

  /* ---------- публичный API для smartcube-ui ---------- */
  window.Coach = {
    onMove() { movesSince++; },
    onState(fac) {
      if (!fac || fac.length < 54) return;
      const changed = fac !== last || !fresh;   // то же состояние второй раз — анализировать нечего
      last = fac; fresh = true;
      if (connected && changed) render();
    },
    onConnection(on) { connected = on; commit = null; fresh = false; resetProgress(); render(); },
    /* новая попытка (жмут «Сборка»): отпускаем подсказку и пересчитываем от свежего состояния */
    restart() { commit = null; fresh = false; movesSince = 0; resetProgress(); render(); },
    analyze, faceletsToCubies,
    // для разбора сборки (review.js): те же проверки этапов, что и у подсказок
    eng: { crossEdges, analyzeF2L, bestOf, reportedCost, slotSolvedByColors, solvedUpToAUF, CNAME, AUF_STR },
    _selftest: () => selftest()
  };
  render();

  /* ================= самопроверка конвертера ================= *
     Прогоняем случайные скрамблы: конвертированный из facelets куб должен
     совпасть с кубом движка, собранным теми же ходами (facelet-грань → грань движка). */
  const F2E_MOVE = { U: 'D', D: 'U', R: 'F', L: 'B', F: 'R', B: 'L' };
  function cubeKey(cs) {
    return cs.map(cu => cu.p.join(',') + ':' + cu.st.map(s => s.n.join('') + s.c).sort().join('|'))
             .sort().join('  ');
  }
  function selftest(n = 200) {
    const faces = 'UDRLFB'.split(''), sufs = ['', "'", '2'];
    let ok = 0, fail = 0, firstBad = null;
    for (let t = 0; t < n; t++) {
      const len = 8 + (Math.random() * 15 | 0), seq = [];
      for (let i = 0; i < len; i++) seq.push(faces[Math.random() * 6 | 0] + sufs[Math.random() * 3 | 0]);
      const facSeq = seq.join(' ');
      const engSeq = seq.map(m => F2E_MOVE[m[0]] + m.slice(1)).join(' ');
      const csA = faceletsToCubies(F.applySeq(F.SOLVED, facSeq));
      const csB = E.solvedCube().filter(c => c.st.length);
      for (const m of E.parseAlg(engSeq)) E.applyMove(csB, m);
      if (cubeKey(csA) === cubeKey(csB)) ok++;
      else { fail++; if (!firstBad) firstBad = { facSeq, engSeq }; }
    }
    const r = { ok, fail, firstBad };
    console.log('[Coach selftest]', r);
    return r;
  }
})();
