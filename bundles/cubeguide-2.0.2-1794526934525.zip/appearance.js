"use strict";
/* ===== CubeGuide · оформление =====
   Полный кастом внешнего вида:
   1) четыре цвета — основной, второй (градиент), подсветка и ФОН. Из фона генерируется
      вся шкала поверхностей (панели, карточки, линии, текст), поэтому приложение
      целиком перекрашивается, а не только кнопки;
   2) обои — фото или видео с затемнением/размытием и палитрой, подобранной из картинки.
   Настройки лежат в localStorage (включая готовый набор CSS-переменных — его применяет
   маленький скрипт в <head>, чтобы при старте ничего не моргало), файл обоев — в IndexedDB. */
(function () {
  const $ = id => document.getElementById(id);
  const root = document.documentElement, body = document.body;
  const KEY = 'cg-appearance';

  const DARK_BG = '#0a0c11', LIGHT_BG = '#eef1f6';
  const DEF = { theme: 'dark', grad: 1, c1: '#6d8cff', c2: '#8f6dff', c3: '#22d3ac', bg: DARK_BG,
                dim: 55, blur: 0, glass: 1, wall: null, wallLum: null, vars: null };
  const IC_MOON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linejoin="round"><path d="M20.2 14.4A8.3 8.3 0 0 1 9.6 3.8a8.5 8.5 0 1 0 10.6 10.6Z"/></svg>';
  const IC_SUN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="4.1"/><path d="M12 2.7v2.3M12 19v2.3M4.7 12H2.4M21.6 12h-2.3M6.4 6.4 4.8 4.8M19.2 19.2l-1.6-1.6M17.6 6.4l1.6-1.6M4.8 19.2l1.6-1.6"/></svg>';
  /* пресет = [имя, основной, градиент, подсветка, фон] */
  const PRESETS = [
    ['Индиго', '#6d8cff', '#8f6dff', '#22d3ac', '#0a0c11'],
    ['Закат',  '#ff7a45', '#ff4d8d', '#ffc247', '#150d0e'],
    ['Неон',   '#28e0d5', '#7c5cff', '#b9ff5c', '#07100f'],
    ['Изумруд','#2fd08a', '#12b3a8', '#c2f75f', '#08120e'],
    ['Вишня',  '#ff5470', '#c81e5a', '#ffb26b', '#140a0e'],
    ['Графит', '#9aa7bd', '#6f7b91', '#d5dde9', '#0d0f13'],
    ['Бумага', '#3f62e8', '#7a5cf0', '#0aa47f', '#eef1f6'],
    ['Песок',  '#c2703a', '#a8503a', '#3f8f7a', '#f4efe6']
  ];

  let S = Object.assign({}, DEF, read());
  let wallURL = null, pendingAuto = false;

  function read() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }

  /* ---------- файл обоев в IndexedDB ---------- */
  function idb() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('cubeguide', 1);
      r.onupgradeneeded = () => { if (!r.result.objectStoreNames.contains('files')) r.result.createObjectStore('files'); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  async function fileGet() {
    try { const db = await idb(); return await new Promise(res => {
      const q = db.transaction('files', 'readonly').objectStore('files').get('wall');
      q.onsuccess = () => res(q.result || null); q.onerror = () => res(null);
    }); } catch (e) { return null; }
  }
  async function filePut(blob) {
    try { const db = await idb(); await new Promise((res, rej) => {
      const t = db.transaction('files', 'readwrite'); t.objectStore('files').put(blob, 'wall');
      t.oncomplete = res; t.onerror = () => rej(t.error);
    }); return true; } catch (e) { return false; }
  }
  async function fileDel() {
    try { const db = await idb(); await new Promise(res => {
      const t = db.transaction('files', 'readwrite'); t.objectStore('files').delete('wall');
      t.oncomplete = res; t.onerror = res;
    }); } catch (e) {}
  }

  /* ---------- цвет ---------- */
  const hex = v => /^#[0-9a-f]{6}$/i.test(v) ? v.toLowerCase() : null;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function rgb(h) { h = h.replace('#', ''); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
  function lum(h) {
    const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); };
    const [r, g, b] = rgb(h); return .2126 * f(r) + .7152 * f(g) + .0722 * f(b);
  }
  function rgb2hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
    if (mx === mn) return [0, 0, l];
    const d = mx - mn, s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
    let h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return [h / 6, s, l];
  }
  function hsl2hex(h, s, l) {
    h = ((h % 1) + 1) % 1;
    const f = n => { const k = (n + h * 12) % 12, a = s * Math.min(l, 1 - l);
      return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, Math.min(9 - k, 1))))); };
    return '#' + [f(0), f(8), f(4)].map(v => v.toString(16).padStart(2, '0')).join('');
  }
  const hsl = h => rgb2hsl.apply(null, rgb(h));
  /* читаемый акцент: насыщенность и светлота в рабочем диапазоне */
  const boost = (h, s, l, dl) => hsl2hex(h, Math.min(.92, Math.max(.5, s)), Math.min(.74, Math.max(.5, l + (dl || 0))));
  /* очень тёмная подложка в тон цвета */
  const deepBg = (h, s) => hsl2hex(h, Math.min(.35, Math.max(.12, s)), .055);

  /* ---------- поверхности из цвета фона ---------- */
  function surfaceVars(base) {
    const [h, s, l] = hsl(base), dark = lum(base) < .42, dir = dark ? 1 : -1;
    const S1 = Math.min(s, .42);                       // фон может быть цветным, но не кислотным
    const step = d => hsl2hex(h, S1, clamp(l + dir * d, .015, .995));
    const text = (sat, li) => hsl2hex(h, Math.min(S1, sat), li);
    return {
      '--bg': base,
      '--bg2': step(dark ? .022 : .012),
      '--surface': step(dark ? .045 : .035),
      '--raise': step(dark ? .066 : .05),
      '--chip': step(dark ? .088 : .028),
      '--line': step(dark ? .125 : .085),
      '--line-soft': step(dark ? .075 : .052),
      '--ink': dark ? text(.16, .95) : text(.35, .10),
      '--ink-dim': dark ? text(.15, .82) : text(.30, .24),
      '--muted': dark ? text(.13, .62) : text(.24, .44),
      '--shadow': dark ? '0 1px 2px rgba(0,0,0,.5), 0 18px 44px -18px rgba(0,0,0,.85)'
                       : '0 1px 2px rgba(20,25,35,.06), 0 14px 34px -16px rgba(20,25,35,.32)'
    };
  }

  /* ---------- применение цветов ---------- */
  function buildVars() {
    const v = surfaceVars(S.bg);
    v['--accent'] = S.c1;
    v['--accent-2b'] = S.grad ? S.c2 : S.c1;
    v['--accent-2'] = S.c3;
    v['--accent-ink'] = lum(S.c1) > .48 ? '#0a0c11' : '#ffffff';
    /* служебные цвета этапов тоже идут из палитры — иначе бейджи остаются чужого цвета */
    v['--blue'] = S.c2;
    v['--green'] = S.c3;
    return v;
  }
  function applyColors() {
    const dark = lum(S.bg) < .42;
    root.setAttribute('data-theme', dark ? 'dark' : 'light');
    S.theme = dark ? 'dark' : 'light';
    const v = buildVars();
    for (const k in v) root.style.setProperty(k, v[k]);
    S.vars = v;
  }

  /* ---------- обои ---------- */
  function applyWallVars() {
    root.style.setProperty('--wall-dim', (S.dim / 100).toFixed(2));
    root.style.setProperty('--wall-blur', S.blur + 'px');
    body.classList.toggle('glass', !!S.glass);
  }
  /* средняя яркость обоев — по ней подбираем затемнение, чтобы текст читался */
  function wallLuma(el) {
    const w = 48, h = 48, cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    try { ctx.drawImage(el, 0, 0, w, h); } catch (e) { return null; }
    let d; try { d = ctx.getImageData(0, 0, w, h).data; } catch (e) { return null; }
    let sum = 0, n = 0;
    for (let i = 0; i < d.length; i += 4) { sum += (.2126 * d[i] + .7152 * d[i + 1] + .0722 * d[i + 2]) / 255; n++; }
    return n ? sum / n : null;
  }
  function autoDim(l) {
    const dark = lum(S.bg) < .42;
    const conflict = dark ? l : 1 - l;            // насколько обои спорят с цветом текста
    return Math.round(clamp(24 + conflict * 52, 18, 82));
  }

  async function applyWall() {
    const media = $('wallMedia');
    if (wallURL) { URL.revokeObjectURL(wallURL); wallURL = null; }
    media.innerHTML = '';
    const blob = S.wall ? await fileGet() : null;
    if (!blob) { body.classList.remove('has-wall'); S.wall = null; return; }
    wallURL = URL.createObjectURL(blob);
    let el;
    if ((S.wall.type || '').startsWith('video')) {
      el = document.createElement('video');
      el.autoplay = true; el.loop = true; el.muted = true; el.playsInline = true;
    } else el = document.createElement('img');
    el.src = wallURL;
    media.appendChild(el);
    body.classList.add('has-wall');
    applyWallVars();
    el.addEventListener(el.tagName === 'VIDEO' ? 'loadeddata' : 'load', () => {
      buildPalettes(el);
      const l = wallLuma(el);
      if (l != null) S.wallLum = l;
      if (pendingAuto && l != null) { S.dim = autoDim(l); pendingAuto = false; applyWallVars(); syncUI(); }
      save();
    }, { once: true });
  }

  /* ---------- палитра из обоев ---------- */
  function extract(el) {
    const w = 72, h = 72, cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    try { ctx.drawImage(el, 0, 0, w, h); } catch (e) { return []; }
    let d; try { d = ctx.getImageData(0, 0, w, h).data; } catch (e) { return []; }
    const buckets = {};
    for (let i = 0; i < d.length; i += 4) {
      const [hu, sa, li] = rgb2hsl(d[i], d[i + 1], d[i + 2]);
      if (li < .10 || li > .94) continue;                       // почти чёрное/белое не в счёт
      const k = Math.round(hu * 18) + '|' + Math.round(sa * 3);
      const b = buckets[k] || (buckets[k] = { n: 0, h: 0, s: 0, l: 0 });
      b.n++; b.h += hu; b.s += sa; b.l += li;
    }
    return Object.values(buckets)
      .map(b => ({ n: b.n, h: b.h / b.n, s: b.s / b.n, l: b.l / b.n }))
      .filter(b => b.n > 12)
      .sort((a, b) => b.n * (.35 + b.s) - a.n * (.35 + a.s))
      .slice(0, 4);
  }
  function palettesFrom(tops) {
    if (!tops.length) return [];
    const d0 = tops[0], d1 = tops[1] || tops[0], out = [];
    out.push(['Из обоев', boost(d0.h, d0.s, d0.l), boost(d0.h + .06, d0.s, d0.l, .06), boost(d1.h, d1.s, d1.l, .04), deepBg(d0.h, d0.s)]);
    out.push(['Контраст', boost(d0.h, d0.s, d0.l), boost(d0.h + .5, d0.s, d0.l), boost(d0.h + .08, d0.s, d0.l, .08), deepBg(d0.h + .5, d0.s)]);
    if (tops[1]) out.push(['Второй тон', boost(d1.h, d1.s, d1.l), boost(d1.h + .06, d1.s, d1.l, .06), boost(d0.h, d0.s, d0.l, .04), deepBg(d1.h, d1.s)]);
    out.push(['Мягкая', boost(d0.h, Math.min(.6, d0.s), .62), boost(d0.h + .04, Math.min(.55, d0.s), .68), boost(d0.h - .1, Math.min(.6, d0.s), .6), deepBg(d0.h, Math.min(.3, d0.s))]);
    return out;
  }
  function swatchBtn(p, cls) {
    return `<button class="pal ${cls || ''}" data-c="${p[1]},${p[2]},${p[3]},${p[4] || ''}" title="${p[0]}">
      <span class="sw"><i style="background:${p[1]}"></i><i style="background:${p[2]}"></i><i style="background:${p[3]}"></i>${p[4] ? `<i style="background:${p[4]}"></i>` : ''}</span>
      <span class="pn">${p[0]}</span></button>`;
  }
  function buildPalettes(el) {
    const box = $('wallPalettes'); if (!box) return;
    const list = palettesFrom(extract(el));
    box.innerHTML = list.length
      ? list.map(p => swatchBtn(p)).join('')
      : '<p class="skin-hint dim">Не получилось разобрать цвета этой картинки — выбери палитру во вкладке «Цвета».</p>';
  }

  /* ---------- интерфейс ---------- */
  function syncUI() {
    [['c1', S.c1], ['c2', S.c2], ['c3', S.c3], ['cbg', S.bg]].forEach(([id, v]) => {
      $(id).value = v; $(id + 'v').textContent = v;
    });
    seg('skinTheme', S.theme); seg('skinGrad', String(S.grad));
    seg('skinGlass', String(S.glass));
    $('wallDim').value = S.dim; $('dimV').textContent = S.dim + '%';
    $('wallBlur').value = S.blur; $('blurV').textContent = S.blur + ' px';
    $('c2').closest('.ccell').classList.toggle('off', !S.grad);
    const inf = $('wallInfo');
    if (S.wall) { inf.hidden = false; inf.innerHTML = `<b>${S.wall.name || 'обои'}</b><span>${(S.wall.type || '').startsWith('video') ? 'видео' : 'фото'}</span>`; }
    else inf.hidden = true;
    const t = $('themeToggle');
    if (t) { t.innerHTML = S.theme === 'light' ? IC_SUN : IC_MOON;
             t.title = S.theme === 'light' ? 'Светлая тема — переключить на тёмную' : 'Тёмная тема — переключить на светлую'; }
  }
  function seg(id, val) {
    const g = $(id); if (!g) return;
    [...g.querySelectorAll('button')].forEach(b => b.classList.toggle('on', b.dataset.v === val));
  }
  function onSeg(id, fn) {
    const g = $(id); if (!g) return;
    g.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; fn(b.dataset.v); save(); syncUI(); });
  }
  const open = () => { $('skinPanel').hidden = false; $('skinBack').hidden = false; requestAnimationFrame(() => body.classList.add('skin-on')); };
  const close = () => { body.classList.remove('skin-on'); setTimeout(() => { $('skinPanel').hidden = true; $('skinBack').hidden = true; }, 220); };

  function setPalette(c1, c2, c3, bg) {
    S.c1 = hex(c1) || S.c1; S.c2 = hex(c2) || S.c2; S.c3 = hex(c3) || S.c3;
    if (hex(bg)) S.bg = hex(bg);
    applyColors(); save(); syncUI();
  }

  async function loadWallFile(file) {
    if (!file) return;
    if (!/^(image|video)\//.test(file.type)) { note('Нужен файл картинки или видео.'); return; }
    if (file.size > 220 * 1024 * 1024) { note('Файл больше 220 МБ — выбери полегче.'); return; }
    if (!await filePut(file)) { note('Не удалось сохранить файл.'); return; }
    S.wall = { type: file.type, name: file.name };
    pendingAuto = true;                                   // под новые обои подберём затемнение сами
    save(); await applyWall(); syncUI();
  }
  function note(t) { const n = $('wallNote'); if (!n) return; n.textContent = t; n.hidden = false; setTimeout(() => { n.hidden = true; }, 4000); }

  function init() {
    $('skinPresets').innerHTML = PRESETS.map(p => swatchBtn(p, 'sm')).join('');

    $('skinOpen').addEventListener('click', open);
    $('skinClose').addEventListener('click', close);
    $('skinBack').addEventListener('click', close);
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('skinPanel').hidden) close(); });

    $('skinPanel').addEventListener('click', e => {
      const t = e.target.closest('.skin-tab');
      if (t) {
        [...$('skinPanel').querySelectorAll('.skin-tab')].forEach(x => x.classList.toggle('on', x === t));
        [...$('skinPanel').querySelectorAll('.skin-body')].forEach(p => { p.hidden = p.dataset.p !== t.dataset.t; });
        return;
      }
      const p = e.target.closest('.pal');
      if (p) { const [a, b, c, d] = p.dataset.c.split(','); setPalette(a, b, c, d); }
    });

    ['c1', 'c2', 'c3'].forEach(id => $(id).addEventListener('input', () => {
      S[id] = $(id).value; applyColors(); save(); syncUI();
    }));
    $('cbg').addEventListener('input', () => { S.bg = $('cbg').value; applyColors(); save(); syncUI(); });
    $('bgTint').addEventListener('click', () => {                  // фон в тон основного цвета
      const [h, s] = hsl(S.c1), dark = lum(S.bg) < .42;
      S.bg = dark ? deepBg(h, s) : hsl2hex(h, Math.min(.20, Math.max(.06, s)), .955);
      applyColors(); save(); syncUI();
    });
    onSeg('skinTheme', v => { S.bg = v === 'light' ? LIGHT_BG : DARK_BG; applyColors(); });
    onSeg('skinGrad', v => { S.grad = Number(v); applyColors(); });
    onSeg('skinGlass', v => { S.glass = Number(v); applyWallVars(); });
    $('skinReset').addEventListener('click', () => {
      Object.assign(S, { c1: DEF.c1, c2: DEF.c2, c3: DEF.c3, bg: DARK_BG, grad: 1 });
      applyColors(); save(); syncUI();
    });

    const t = $('themeToggle');
    if (t) t.addEventListener('click', () => { S.bg = S.theme === 'light' ? DARK_BG : LIGHT_BG; applyColors(); save(); syncUI(); });

    /* обои */
    const drop = $('wallDrop'), inp = $('wallFile');
    drop.addEventListener('click', () => inp.click());
    inp.addEventListener('change', () => { loadWallFile(inp.files[0]); inp.value = ''; });
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', e => { const f = e.dataTransfer && e.dataTransfer.files[0]; loadWallFile(f); });
    $('wallDim').addEventListener('input', e => { S.dim = Number(e.target.value); pendingAuto = false; applyWallVars(); save(); syncUI(); });
    $('wallBlur').addEventListener('input', e => { S.blur = Number(e.target.value); applyWallVars(); save(); syncUI(); });
    $('wallClear').addEventListener('click', async () => {
      await fileDel(); S.wall = null; save(); await applyWall(); syncUI();
      $('wallPalettes').innerHTML = '<p class="skin-hint dim">Добавь обои, чтобы подобрать палитру.</p>';
    });

    applyColors(); save(); syncUI(); applyWall();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
