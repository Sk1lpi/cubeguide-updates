"use strict";
/* ===== Оптимальный белый крест =====
   Четыре белых ребра — это всего 24·22·20·18 ≈ 190 тыс. положений, поэтому таблицу
   расстояний до собранного креста строим целиком обходом в ширину (один раз, ~0.1 с),
   а решение достаём жадным спуском по ней. Метрика — HTM (R2 = один ход).
   Работает в системе кубика GAN (белый = U); для показа ходы переводят через Facelet.toView. */
(function (root) {
  const F = root.Facelet || (typeof require === 'function' ? require('./facelet.js') : null);

  // наклейки рёбер (Kociemba): [наклейка 1, наклейка 2]
  const EDGES = [[5, 10], [7, 19], [3, 37], [1, 46], [32, 16], [28, 25], [30, 43], [34, 52], [23, 12], [21, 41], [50, 39], [48, 14]];
  const SLOT = new Int8Array(54).fill(-1);                 // номер наклейки ребра → 0..23
  const STK = [];
  EDGES.forEach(([a, b]) => { SLOT[a] = STK.length; STK.push(a); SLOT[b] = STK.length; STK.push(b); });
  const PARTNER = {}; EDGES.forEach(([a, b]) => { PARTNER[a] = b; PARTNER[b] = a; });

  const MOVES = [];
  'URFDLB'.split('').forEach(f => ['', '2', "'"].forEach(s => MOVES.push(f + s)));

  // куда переезжает наклейка с позиции p после хода: метим позиции уникальными символами
  const MOVE_MAP = MOVES.map(m => {
    const lab = Array.from({ length: 54 }, (_, i) => String.fromCharCode(0x100 + i)).join('');
    const after = F.applyMove(lab, m), map = new Int8Array(24);
    for (let i = 0; i < 54; i++) {
      const from = after.charCodeAt(i) - 0x100;            // на месте i теперь то, что было на from
      if (SLOT[from] >= 0) map[SLOT[from]] = SLOT[i];
    }
    return map;
  });

  // белое ребро определяем по второму цвету: B, L, R, F — дом белой наклейки 1, 3, 5, 7
  const HOME = { B: 1, L: 3, R: 5, F: 7 };
  const ORDER = ['B', 'L', 'R', 'F'];
  const enc = (a, b, c, d) => ((a * 24 + b) * 24 + c) * 24 + d;
  let DIST = null;
  function build() {
    if (DIST) return DIST;
    DIST = new Int8Array(24 ** 4).fill(-1);
    const s0 = ORDER.map(k => SLOT[HOME[k]]);
    let frontier = [s0]; DIST[enc(...s0)] = 0;
    for (let d = 0; frontier.length; d++) {
      const next = [];
      for (const s of frontier) for (const mm of MOVE_MAP) {
        const t = [mm[s[0]], mm[s[1]], mm[s[2]], mm[s[3]]], k = enc(...t);
        if (DIST[k] < 0) { DIST[k] = d + 1; next.push(t); }
      }
      frontier = next;
    }
    return DIST;
  }

  function crossState(fac) {
    const s = [];
    for (const k of ORDER) {
      let pos = -1;
      for (const [a, b] of EDGES) {
        if (fac[a] === 'U' && fac[b] === k) { pos = a; break; }
        if (fac[b] === 'U' && fac[a] === k) { pos = b; break; }
      }
      if (pos < 0) return null;
      s.push(SLOT[pos]);
    }
    return s;
  }

  /* оптимальное решение креста для состояния facelets: { n, moves:[...] } в нотации кубика */
  function solve(fac) {
    const D = build();
    let s = crossState(fac);
    if (!s) return null;
    const out = [];
    let d = D[enc(...s)];
    while (d > 0) {
      let found = false;
      for (let i = 0; i < MOVE_MAP.length; i++) {
        const mm = MOVE_MAP[i], t = [mm[s[0]], mm[s[1]], mm[s[2]], mm[s[3]]];
        if (D[enc(...t)] === d - 1) { out.push(MOVES[i]); s = t; d--; found = true; break; }
      }
      if (!found) break;
    }
    return { n: out.length, moves: out };
  }
  function dist(fac) { const s = crossState(fac); return s ? build()[enc(...s)] : -1; }

  const API = { solve, dist };
  root.CrossSolver = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})(typeof window !== 'undefined' ? window : globalThis);
