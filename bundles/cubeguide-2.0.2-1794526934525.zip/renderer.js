"use strict";
/* ===== iso cube geometry ===== */
const P={T:{x:70,y:26},RR:{x:116,y:50},LL:{x:24,y:50},FR:{x:70,y:74},LLd:{x:24,y:104},FRd:{x:70,y:128},RRd:{x:116,y:104}};
const FU=[P.T,P.RR,P.FR,P.LL], FF=[P.LL,P.FR,P.FRd,P.LLd], FR=[P.FR,P.RR,P.RRd,P.FRd];
const Lp=(p,q,t)=>({x:p.x+(q.x-p.x)*t,y:p.y+(q.y-p.y)*t});
const add=(p,q)=>({x:p.x+q.x,y:p.y+q.y}), sub=(p,q)=>({x:p.x-q.x,y:p.y-q.y}), mul=(p,s)=>({x:p.x*s,y:p.y*s}), mid=(p,q)=>({x:(p.x+q.x)/2,y:(p.y+q.y)/2});
function faceGrid(c, colorAt){
  let s="";
  for(let j=0;j<3;j++)for(let i=0;i<3;i++){
    const t0=Lp(c[0],c[1],i/3),t1=Lp(c[0],c[1],(i+1)/3),b0=Lp(c[3],c[2],i/3),b1=Lp(c[3],c[2],(i+1)/3);
    const A=Lp(t0,b0,j/3),B=Lp(t1,b1,j/3),C=Lp(t1,b1,(j+1)/3),D=Lp(t0,b0,(j+1)/3);
    s+=`<polygon points="${A.x.toFixed(1)},${A.y.toFixed(1)} ${B.x.toFixed(1)},${B.y.toFixed(1)} ${C.x.toFixed(1)},${C.y.toFixed(1)} ${D.x.toFixed(1)},${D.y.toFixed(1)}" fill="${colorAt(i,j)}" stroke="var(--seam)" stroke-width="1.4" stroke-linejoin="round"/>`;
  }
  return s;
}
/* ===== arrows =====
   Стрелка рисуется НА той грани, которая крутится: столбец/ряд фронта для R/L/D,
   дуга по самой грани для U/F. Скрытые грани (B) — пунктиром. Каждая стрелка идёт
   с белым «ореолом», чтобы читалась поверх любого цвета наклейки. */
const ARROW="var(--arrow)";
/* Голова — узкий «дротик» с вогнутым хвостом: на картинке 140×150 читается
   острее и аккуратнее широкого треугольника. */
function headPoly(tip,ang,hs){
  const a1=ang+Math.PI*0.745,a2=ang-Math.PI*0.745;
  const h1={x:tip.x+hs*Math.cos(a1),y:tip.y+hs*Math.sin(a1)},h2={x:tip.x+hs*Math.cos(a2),y:tip.y+hs*Math.sin(a2)};
  const back={x:tip.x-hs*0.60*Math.cos(ang),y:tip.y-hs*0.60*Math.sin(ang)};
  return [tip,h1,back,h2].map(p=>`${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
}
/* Стрелка = белый ореол + тёмное тело. Ореол ровно на 1.5 px шире тела с каждой
   стороны: хватает, чтобы читалось на любой наклейке, и не превращается в кляксу. */
function arrowMarkup(d,tip,ang,dashed,o){
  const w=(o&&o.w)||3.9, hs=(o&&o.head)||11, halo=w+3;
  const head=headPoly(tip,ang,hs);
  const dash=dashed?`stroke-dasharray="${(w*2.2).toFixed(1)} ${(w*1.5).toFixed(1)}"`:'';
  return `<g stroke-linecap="round" stroke-linejoin="round">`
       +`<path d="${d}" fill="none" stroke="var(--arrow-halo)" stroke-width="${halo.toFixed(1)}" opacity=".92" ${dash}/>`
       +`<polygon points="${head}" fill="var(--arrow-halo)" stroke="var(--arrow-halo)" stroke-width="${(halo-w).toFixed(1)}" opacity=".92"/>`
       +`<path d="${d}" fill="none" stroke="${ARROW}" stroke-width="${w}" ${dash}/>`
       +`<polygon points="${head}" fill="${ARROW}" stroke="${ARROW}" stroke-width=".7"/>`
       +`</g>`;
}
function faceBasis(c){const rM=mid(c[1],c[2]),bM=mid(c[2],c[3]),C={x:(c[0].x+c[1].x+c[2].x+c[3].x)/4,y:(c[0].y+c[1].y+c[2].y+c[3].y)/4},BX=sub(rM,C),BY=sub(bM,C);return {C,BX,BY,orient:Math.sign(BX.x*BY.y-BX.y*BY.x)||1};}
/* Дуга по грани. Разрыв кольца всегда внизу и по центру — тогда прямой и обратный
   ход читаются одинаково ровно, без «крючка» через край. Начало отсчитываем от разрыва,
   поэтому дуга остаётся симметричной при любом sweepDeg. */
function curved(c,{prime=false,rFrac=0.74,startDeg=null,sweepDeg=208,dashed=false,w,head}={}){
  const {C,BX,BY,orient}=faceBasis(c), sgn=orient*(prime?-1:1);
  const sweep=sgn*sweepDeg*Math.PI/180, start=(startDeg==null?(90+sgn*(360-sweepDeg)/2):startDeg)*Math.PI/180, N=56, pts=[];
  for(let k=0;k<=N;k++){const th=start+sweep*k/N;pts.push(add(C,add(mul(BX,rFrac*Math.cos(th)),mul(BY,rFrac*Math.sin(th)))));}
  const d="M "+pts.map(p=>`${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" L "), tip=pts[N],prev=pts[N-1];
  return arrowMarkup(d,tip,Math.atan2(tip.y-prev.y,tip.x-prev.x),dashed,{w,head});
}
function straight(from,to,dashed,o){return arrowMarkup(`M ${from.x.toFixed(1)},${from.y.toFixed(1)} L ${to.x.toFixed(1)},${to.y.toFixed(1)}`,to,Math.atan2(to.y-from.y,to.x-from.x),dashed,o);}
/* точка на грани в её собственных осях: u — поперёк (-1 лево … 1 право), v — вдоль (-1 верх … 1 низ) */
function facePoint(c,u,v){const {C,BX,BY}=faceBasis(c);return add(C,add(mul(BX,u),mul(BY,v)));}
function faceStraight(c,u0,v0,u1,v1,dashed,o){return straight(facePoint(c,u0,v0),facePoint(c,u1,v1),dashed,o);}
/* clean thin arrow for flat PLL diagram; doubleHead=true for a swap */
function flatArrowMarkup(a,b,doubleHead){
  const ang=Math.atan2(b.y-a.y,b.x-a.x), ins=9;
  const ax=a.x+Math.cos(ang)*ins, ay=a.y+Math.sin(ang)*ins, bx=b.x-Math.cos(ang)*ins, by=b.y-Math.sin(ang)*ins;
  const d=`M ${ax.toFixed(1)},${ay.toFixed(1)} L ${bx.toFixed(1)},${by.toFixed(1)}`, hs=8;
  const head=(tx,ty,dir)=>{const a1=dir+Math.PI*0.745,a2=dir-Math.PI*0.745;
    const bkx=tx-hs*0.6*Math.cos(dir), bky=ty-hs*0.6*Math.sin(dir);
    const p=`${tx.toFixed(1)},${ty.toFixed(1)} ${(tx+hs*Math.cos(a1)).toFixed(1)},${(ty+hs*Math.sin(a1)).toFixed(1)} ${bkx.toFixed(1)},${bky.toFixed(1)} ${(tx+hs*Math.cos(a2)).toFixed(1)},${(ty+hs*Math.sin(a2)).toFixed(1)}`;
    return `<polygon points="${p}" fill="var(--arrow-halo)" stroke="var(--arrow-halo)" stroke-width="2.4" stroke-linejoin="round" opacity=".92"/><polygon points="${p}" fill="${ARROW}" stroke="${ARROW}" stroke-width=".6" stroke-linejoin="round"/>`;};
  let out=`<path d="${d}" fill="none" stroke="var(--arrow-halo)" stroke-width="5.2" stroke-linecap="round" opacity=".92"/>`
        +`<path d="${d}" fill="none" stroke="${ARROW}" stroke-width="2.6" stroke-linecap="round"/>`
        +head(bx,by,ang);
  if(doubleHead) out+=head(ax,ay,ang+Math.PI);
  return out;
}
function moveArrow(mv){
  const pr=mv.prime, T=0.80, COLN=0.667;   // T — длина стрелки вдоль грани, COLN — центр крайнего столбца/ряда
  const thin={w:3.2,head:9.5};
  const rot={dashed:true,sweepDeg:214,w:3.4,head:10};   // повороты всего куба
  switch(mv.face){
    /* видимые грани — дуга по самой грани */
    case 'U':return curved(FU,{prime:pr,rFrac:0.80});
    case 'F':return curved(FF,{prime:pr,rFrac:0.74});
    /* R/L/D — прямая стрелка по нужному столбцу/ряду фронтальной грани */
    case 'R':return pr?faceStraight(FF, COLN,-T, COLN, T):faceStraight(FF, COLN, T, COLN,-T);
    case 'L':return pr?faceStraight(FF,-COLN, T,-COLN,-T):faceStraight(FF,-COLN,-T,-COLN, T);
    case 'D':return pr?faceStraight(FF, T, COLN,-T, COLN):faceStraight(FF,-T, COLN, T, COLN);
    /* скрытая задняя грань — пунктир по дальнему ряду верха */
    case 'B':return pr?faceStraight(FU,-T,-COLN, T,-COLN,true):faceStraight(FU, T,-COLN,-T,-COLN,true);
    /* повороты всего куба — крупная пунктирная дуга вокруг грани */
    case 'x':return curved(FR,{prime:pr,rFrac:1.04,...rot});
    case 'y':return curved(FU,{prime:pr,rFrac:1.16,...rot});
    case 'z':return curved(FF,{prime:pr,rFrac:1.12,...rot});
    /* слои — по центральному столбцу/ряду */
    case 'M':return pr?faceStraight(FF,0, T,0,-T,false,thin):faceStraight(FF,0,-T,0, T,false,thin);
    case 'E':return pr?faceStraight(FF, T,0,-T,0,false,thin):faceStraight(FF,-T,0, T,0,false,thin);
    case 'S':return curved(FF,{prime:pr,rFrac:0.34,w:3.2,head:9.5});
    default:return "";
  }
}
/* ===== cube engine ===== */
const AX={x_cw:v=>[v[0],v[2],-v[1]],x_ccw:v=>[v[0],-v[2],v[1]],y_cw:v=>[-v[2],v[1],v[0]],y_ccw:v=>[v[2],v[1],-v[0]],z_cw:v=>[v[1],-v[0],v[2]],z_ccw:v=>[-v[1],v[0],v[2]]};
const COL={U:"#ffd23f",D:"#fbfbfb",F:"#e12b38",B:"#ff801a",R:"#25a35a",L:"#2d6fd6"};
const NKEY={"0,1,0":"U","0,-1,0":"D","0,0,1":"F","0,0,-1":"B","1,0,0":"R","-1,0,0":"L"};
function solvedCube(){const cs=[];for(let x=-1;x<=1;x++)for(let y=-1;y<=1;y++)for(let z=-1;z<=1;z++){const st=[];if(x)st.push({n:[x,0,0],c:COL[NKEY[`${x},0,0`]]});if(y)st.push({n:[0,y,0],c:COL[NKEY[`0,${y},0`]]});if(z)st.push({n:[0,0,z],c:COL[NKEY[`0,0,${z}`]]});cs.push({p:[x,y,z],st});}return cs;}
const clone=cs=>cs.map(c=>({p:c.p.slice(),st:c.st.map(s=>({n:s.n.slice(),c:s.c}))}));
const FACEDEF={U:{fn:'y_cw',pred:p=>p[1]===1},D:{fn:'y_ccw',pred:p=>p[1]===-1},R:{fn:'x_cw',pred:p=>p[0]===1},L:{fn:'x_ccw',pred:p=>p[0]===-1},F:{fn:'z_cw',pred:p=>p[2]===1},B:{fn:'z_ccw',pred:p=>p[2]===-1},M:{fn:'x_ccw',pred:p=>p[0]===0},E:{fn:'y_ccw',pred:p=>p[1]===0},S:{fn:'z_cw',pred:p=>p[2]===0},x:{fn:'x_cw',pred:_=>true},y:{fn:'y_cw',pred:_=>true},z:{fn:'z_cw',pred:_=>true},r:{fn:'x_cw',pred:p=>p[0]>=0},l:{fn:'x_ccw',pred:p=>p[0]<=0},u:{fn:'y_cw',pred:p=>p[1]>=0},d:{fn:'y_ccw',pred:p=>p[1]<=0},f:{fn:'z_cw',pred:p=>p[2]>=0},b:{fn:'z_ccw',pred:p=>p[2]<=0}};
function applyMove(cs,mv){const def=FACEDEF[mv.eng];if(!def)return;const fn=AX[def.fn],times=mv.dbl?2:(mv.prime?3:1);for(let t=0;t<times;t++)for(const cu of cs)if(def.pred(cu.p)){cu.p=fn(cu.p);for(const s of cu.st)s.n=fn(s.n);}}
function readSt(cs,pos,n){for(const cu of cs)if(cu.p[0]===pos[0]&&cu.p[1]===pos[1]&&cu.p[2]===pos[2])for(const s of cu.st)if(s.n[0]===n[0]&&s.n[1]===n[1]&&s.n[2]===n[2])return s.c;return "#cfd3d9";}
/* ===== parse ===== */
function parseAlg(str){
  const re=/([UDLRFBMESudlrfbxyz])(w)?(2|')?/g; let m,out=[];
  while((m=re.exec(str))){const letter=m[1],w=!!m[2],suf=m[3]||"",isRot=/[xyz]/.test(letter),lower=/[udlrfb]/.test(letter);
    out.push({raw:letter+(m[2]||"")+suf,face:isRot?letter:letter.toUpperCase(),eng:isRot?letter:(w||lower?letter.toLowerCase():letter.toUpperCase()),prime:suf==="'",dbl:suf==="2",wide:w||lower,rot:isRot});}
  return out;
}
const invert=moves=>moves.slice().reverse().map(m=>({...m,prime:m.dbl?false:!m.prime}));
function centersSolved(cs){for(const cu of cs){if(cu.p.filter(v=>v!==0).length===1){const s=cu.st[0];if(COL[NKEY[s.n.join(',')]]!==s.c)return false;}}return true;}
function netRotInverse(alg){
  let c=solvedCube();for(const m of parseAlg(alg))applyMove(c,m);
  const bases=["","x","x2","x'","z","z'"],aufs=["","y","y2","y'"];
  for(const b of bases)for(const a of aufs){const seq=(b+" "+a).trim();const t=clone(c);for(const m of parseAlg(seq))applyMove(t,m);if(centersSolved(t))return seq;}
  return "";
}
/* ===== «честный» финал этапа =====
   F2L-алгоритм не должен дособирать кубик: после вставки пары верх остаётся неразобранным.
   После OLL жёлтая шапка есть, но бока не совпадают — впереди ещё PLL.
   Поэтому цепочку состояний строим не от собранного куба, а от куба, у которого последний
   слой ещё в работе. Первый и второй слои алгоритмы этих этапов не трогают, поэтому
   распознавание случая (сигнатуры, серые схемы) от этого не меняется. */
const LL_SEED={
  /* только перестановка верха — жёлтый верх целый (нужно для старта OLL) */
  /* важно: без поворотов всего куба (x/y/z) — иначе «перевернём» всю раскладку */
  pll:["R U R' U' R' F R2 U' R' U' R U R' F'","R' U L U' R U2 L' U L U2 L'",
       "F R U' R' U' R U R' F' R U R' U' R' F R F'","M2 U M2 U2 M2 U M2"],
  /* + сбитая ориентация верха (нужно для старта F2L) */
  oll:["R U R' U R U2 R'","R U2 R' U' R U' R'","F R U R' U' F'","R U R' U' R' F R F'"]
};
function seedCube(mode,variant){
  const c=solvedCube(); if(mode!=='f2l'&&mode!=='oll')return c;
  const v=Math.abs(variant|0), pll=LL_SEED.pll[v%LL_SEED.pll.length];
  const alg=mode==='oll'?pll:(pll+" "+LL_SEED.oll[v%LL_SEED.oll.length]);
  for(const m of parseAlg(alg))applyMove(c,m);
  return c;
}
function statesFor(alg,seedMode,variant){
  const eff=(alg+" "+netRotInverse(alg)).trim().replace(/\s+/g,' ');
  const moves=parseAlg(eff); let c=seedMode?seedCube(seedMode,variant):solvedCube();
  for(const m of invert(moves))applyMove(c,m);
  const states=[clone(c)];
  for(const m of moves){applyMove(c,m);states.push(clone(c));}
  return {moves,states,eff};
}
/* ===== case classification ===== */
function findPair(cs){let corner=null,edge=null;for(const cu of cs){const set=cu.st.map(s=>s.c);if(cu.st.length===3&&set.includes(COL.D)&&set.includes(COL.F)&&set.includes(COL.R))corner=cu;if(cu.st.length===2&&set.includes(COL.F)&&set.includes(COL.R))edge=cu;}return {corner,edge};}
function isF2LCase(cs){for(const cu of cs){const[x,y,z]=cu.p;if(y>0)continue;if(x===1&&z===1)continue;for(const s of cu.st)if(COL[NKEY[s.n.join(',')]]!==s.c)return false;}return true;}
function isLastLayer(cs){for(const cu of cs){if(cu.p[1]>0)continue;for(const s of cu.st)if(COL[NKEY[s.n.join(',')]]!==s.c)return false;}return true;}
function pllOriented(cs){for(const cu of cs){if(cu.p[1]!==1)continue;const up=cu.st.find(s=>s.n[0]===0&&s.n[1]===1&&s.n[2]===0);if(!up||up.c!==COL.U)return false;}return true;}
function detectMode(cs){if(isF2LCase(cs))return 'f2l';if(isLastLayer(cs))return pllOriented(cs)?'pll':'oll';return 'full';}
/* signatures */
function f2lSigRaw(cs){const{corner,edge}=findPair(cs);const cN=corner?corner.st.find(s=>s.c===COL.D).n.join(''):'?';return (corner?corner.p.join(''):'?')+'/'+cN+' e'+(edge?edge.p.join(''):'?')+'/'+(edge?edge.st.map(s=>s.n.join('')).sort().join('|'):'?');}
function f2lSig(cs){return f2lSigRaw(cs);}
function ollSigRaw(cs){const a=[];for(const cu of cs){if(cu.p[1]!==1)continue;for(const s of cu.st)if(s.c===COL.U)a.push(s.n.join(',')+'@'+cu.p.join(','));}return a.sort().join('|');}
function pllSigRaw(cs){const a=[];for(const cu of cs){if(cu.p[1]!==1)continue;for(const s of cu.st)if(s.n[1]===0)a.push(cu.p.join(',')+'#'+s.c);}return a.sort().join('|');}
function aufCanon(cs,sigFn){let best=null,t=clone(cs);for(let k=0;k<4;k++){const s=sigFn(t);if(best===null||s<best)best=s;applyMove(t,{eng:'U',face:'U'});}return best;}
/* description */
function caseDesc(cs,mode){
  if(mode==='f2l'){const{corner,edge}=findPair(cs);const loc=cu=>cu?(cu.p[1]===1?"наверху":"в слоте"):"?";let t="угол "+loc(corner);if(corner&&corner.p[1]===-1){const wu=corner.st.some(s=>s.c===COL.D&&s.n[1]===-1);t+=wu?" (верно)":" (перевёрнут)";}else if(corner){const wu=corner.st.some(s=>s.c===COL.D&&s.n[1]===1);if(wu)t+=" (белым вверх)";}return t+", ребро "+loc(edge);}
  if(mode==='oll'){let up=0;for(const cu of cs){if(cu.p[1]!==1)continue;const u=cu.st.find(s=>s.n[0]===0&&s.n[1]===1&&s.n[2]===0);if(u&&u.c===COL.U)up++;}return "ориентация верха · жёлтых наверху: "+up+"/9";}
  if(mode==='pll')return "перестановка верха · верх уже жёлтый, двигаем детали";
  return "";
}
/* ===== render cube ===== */
function cubeSVG(cs,arrowMv,extra,mode){
  let pc=null,pe=null; if(mode==='f2l'){const pr=findPair(cs);pc=pr.corner&&pr.corner.p;pe=pr.edge&&pr.edge.p;}
  const eqp=(a,b)=>a&&b&&a[0]===b[0]&&a[1]===b[1]&&a[2]===b[2];
  const GU="var(--gu)",GF="var(--gf)",GR="var(--gr)";
  const pick=(p,real,gray)=>{
    if(!mode||mode==='full')return real();
    if(Math.abs(p[0])+Math.abs(p[1])+Math.abs(p[2])===1)return real();   // центры всегда в цвете — видно, где какая грань
    if(mode==='f2l')return (eqp(p,pc)||eqp(p,pe))?real():gray;
    if(mode==='oll'){const c=real();return c===COL.U?c:gray;}
    if(mode==='pll')return p[1]===1?real():gray;
    return real();
  };
  const colU=(i,j)=>{const p=[i-1,1,j-1];return pick(p,()=>readSt(cs,p,[0,1,0]),GU);};
  const colF=(i,j)=>{const p=[i-1,1-j,1];return pick(p,()=>readSt(cs,p,[0,0,1]),GF);};
  const colR=(i,j)=>{const p=[1,1-j,1-i];return pick(p,()=>readSt(cs,p,[1,0,0]),GR);};
  let s=`<rect x="2" y="2" width="136" height="146" rx="14" fill="var(--plate)"/>`;
  s+=faceGrid(FU,colU)+faceGrid(FF,colF)+faceGrid(FR,colR);
  if(arrowMv)s+=moveArrow(arrowMv); if(extra)s+=extra;
  return `<svg viewBox="0 0 140 150" role="img">${s}</svg>`;
}
/* flat top-view diagram for OLL / PLL (like the reference site) */
const HOME={}; solvedCube().forEach(cu=>{ if(cu.p[1]===1) HOME[cu.st.map(s=>s.c).sort().join()]=cu.p; });
function flatSVG(cs, mode, showArrows){
  const C=30,G=4,gx=22,gy=22,TT=8,TG=3, YEL="#ffd23f", GRY="var(--gf)";
  const cellX=i=>gx+i*(C+G), cellY=j=>gy+j*(C+G);
  const tcol=(pos,n)=>{ const c=readSt(cs,pos,n); return mode==='oll'?(c===COL.U?YEL:GRY):c; };
  let s=`<rect x="2" y="2" width="136" height="136" rx="14" fill="var(--plate)"/>`;
  const tab=(x,y,w,h,c)=>{ s+=`<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w}" height="${h}" rx="2.5" fill="${c}"/>`; };
  for(let i=0;i<3;i++){
    tab(cellX(i), gy-TG-TT, C, TT, tcol([i-1,1,-1],[0,0,-1]));
    tab(cellX(i), gy+3*C+2*G+TG, C, TT, tcol([i-1,1,1],[0,0,1]));
  }
  for(let j=0;j<3;j++){
    tab(gx-TG-TT, cellY(j), TT, C, tcol([-1,1,j-1],[-1,0,0]));
    tab(gx+3*C+2*G+TG, cellY(j), TT, C, tcol([1,1,j-1],[1,0,0]));
  }
  for(let j=0;j<3;j++)for(let i=0;i<3;i++){
    const c=readSt(cs,[i-1,1,j-1],[0,1,0]);
    const col=mode==='oll'?(c===COL.U?YEL:GRY):c;
    s+=`<rect x="${cellX(i)}" y="${cellY(j)}" width="${C}" height="${C}" rx="4" fill="${col}" stroke="var(--seam)" stroke-width="1.4"/>`;
  }
  if(showArrows && mode==='pll'){
    const center=(x,z)=>({x:cellX(x+1)+C/2, y:cellY(z+1)+C/2});
    const key=p=>p[0]+','+p[1];
    const mv=[];
    for(const cu of cs){
      if(cu.p[1]!==1 || cu.st.length<2) continue;
      const home=HOME[cu.st.map(s2=>s2.c).sort().join()];
      if(!home || (home[0]===cu.p[0]&&home[2]===cu.p[2])) continue;
      mv.push({from:[cu.p[0],cu.p[2]], to:[home[0],home[2]]});
    }
    const drawn=new Set();
    for(const m of mv){
      const k=key(m.from)+'>'+key(m.to);
      if(drawn.has(k)) continue;
      const swap=mv.some(o=>key(o.from)===key(m.to)&&key(o.to)===key(m.from));
      drawn.add(k);
      if(swap) drawn.add(key(m.to)+'>'+key(m.from)); // draw the pair once, double-headed
      s+=flatArrowMarkup(center(m.from[0],m.from[1]), center(m.to[0],m.to[1]), swap);
    }
  }
  return `<svg viewBox="0 0 140 140" role="img">${s}</svg>`;
}
function caseDiagram(cs, mode){
  if(mode==='oll') return flatSVG(cs,'oll',false);
  if(mode==='pll') return flatSVG(cs,'pll',true);
  return cubeSVG(cs,null,"",mode);
}
function ollType(cs){
  const up=[[0,1,-1],[0,1,1],[-1,1,0],[1,1,0]].map(p=>readSt(cs,p,[0,1,0])===COL.U);
  const n=up.filter(Boolean).length;
  if(n===4) return "Крест — все рёбра";
  if(n===0) return "Точка — нет рёбер";
  if((up[0]&&up[1])||(up[2]&&up[3])) return "Линия";
  return "Уголок (L)";
}
const PLL_NAME={Aa:"Треугольники углов (A-perm)",Ab:"Треугольники углов (A-perm)",E:"Терминатор (E-perm)",F:"Параллельный перенос (F-perm)",Ga:"Восьмёрки (G-perm)",Gb:"Восьмёрки (G-perm)",Gc:"Восьмёрки (G-perm)",Gd:"Восьмёрки (G-perm)",H:"Крест сторон (H-perm)",Ja:"Лямбды (J-perm)",Jb:"Лямбды (J-perm)",Na:"Буквы X (N-perm)",Nb:"Буквы X (N-perm)",Ra:"Семёрки (R-perm)",Rb:"Семёрки (R-perm)",T:"Буква Т (T-perm)",Ua:"Треугольники сторон (U-perm)",Ub:"Треугольники сторон (U-perm)",V:"Летающая тарелка (V-perm)",Y:"Копьё (Y-perm)",Z:"Саночки (Z-perm)"};
function hintText(mv){
  const base={U:`верх ${mv.prime?"↺ против":"↻ по"} час.`,D:`низ ${mv.prime?"↺":"↻"}`,R:`прав. столбец ${mv.prime?"↓ вниз":"↑ вверх"}`,L:`лев. столбец ${mv.prime?"↑ вверх":"↓ вниз"}`,F:`фронт ${mv.prime?"↺ против":"↻ по"} час.`,B:`зад ${mv.prime?"↺":"↻"}`,x:`весь куб (как ${mv.prime?"R'":"R"})`,y:`весь куб (как ${mv.prime?"U'":"U"})`,z:`весь куб (как ${mv.prime?"F'":"F"})`,M:`центр. столбец ${mv.prime?"↑":"↓"}`,E:`центр. ряд ${mv.prime?"←":"→"}`,S:`центр. слой ${mv.prime?"↺":"↻"}`}[mv.face]||mv.raw;
  const ex=[];if(mv.dbl)ex.push("2 раза");if(mv.wide)ex.push("2 слоя");
  return ex.length?base+" · "+ex.join(" · "):base;
}
function moveCard(cs,mv,idx){
  const dbl=mv.dbl?`<g><rect x="100" y="8" width="33" height="20" rx="10" fill="${ARROW}" opacity=".92"/><text x="116.5" y="22.4" font-family="JetBrains Mono, monospace" font-size="12.5" font-weight="700" fill="var(--arrow-halo)" text-anchor="middle">×2</text></g>`:"";
  return `<figure class="move"><span class="idx">${idx}</span>${cubeSVG(cs,mv,dbl,'full')}<div class="notation">${mv.raw.replace("'","′")}</div><div class="hint">${hintText(mv)}</div></figure>`;
}
/* ===== 3D-проигрыватель алгоритма ===== */
/* 54 цвета в порядке URFDLB — стартовое состояние для 3D. Пишем их без «#», чтобы
   перекраска схемы в coach.js (она правит только #rrggbb) не задевала состояние плеера:
   ассистент передаёт сюда состояние живого кубика, оно уже в правильных цветах. */
const SLOTDEF={U:(r,c)=>[[c-1,1,r-1],[0,1,0]],F:(r,c)=>[[c-1,1-r,1],[0,0,1]],R:(r,c)=>[[1,1-r,1-c],[1,0,0]],
               D:(r,c)=>[[c-1,-1,1-r],[0,-1,0]],L:(r,c)=>[[-1,1-r,c-1],[-1,0,0]],B:(r,c)=>[[1-c,1-r,-1],[0,0,-1]]};
function stateColors(cs){
  const out=[];
  for(const f of ["U","R","F","D","L","B"])for(let r=0;r<3;r++)for(let c=0;c<3;c++){
    const [p,n]=SLOTDEF[f](r,c); out.push(readSt(cs,p,n).replace("#",""));
  }
  return out.join(",");
}
const SPEEDS=[["0.5","Медленно"],["1","Обычно"],["1.7","Быстро"],["2.6","Молния"]];
function playerHTML(eff,state){
  const sp=localStorage.getItem("algSpeed")||"1";
  const btns=SPEEDS.map(([v,n])=>`<button class="p3b spd${v===sp?" on":""}" data-v="${v}">${n}</button>`).join("");
  return `<div class="p3d" data-alg="${eff.replace(/"/g,'&quot;')}" data-state="${state||""}">
    <div class="p3d-stage"></div>
    <div class="p3d-now"><b class="nmv">—</b><span class="nhint">нажми ▶, чтобы посмотреть</span></div>
    <div class="p3d-bar">
      <button class="p3b act-rew" title="В начало">⏮</button>
      <button class="p3b act-prev" title="Шаг назад">◀</button>
      <button class="p3b main act-play" title="Пуск / пауза">▶</button>
      <button class="p3b act-next" title="Шаг вперёд">▶︎</button>
      <button class="p3b act-loop" title="Повторять по кругу">🔁</button>
      <button class="p3b act-view" title="Вернуть ракурс">⟲</button>
    </div>
    <div class="p3d-speed">${btns}</div>
    <div class="p3d-prog"><i></i></div>
    <div class="p3d-cap">3D · крутится то, что нужно вращать</div>
  </div>`;
}
/* монтируем плееры внутри контейнера; ушедшие из DOM гасим сами — WebGL-контекстов мало */
const LIVE=new Set();
function mountPlayers(root){
  if(!window.CubePlayer)return;
  for(const p of [...LIVE])if(!p.el.isConnected){p.dispose();LIVE.delete(p);}
  root.querySelectorAll(".p3d[data-alg]").forEach(box=>{
    if(box.__player)return;
    const stage=box.querySelector(".p3d-stage");
    const strip=box.closest(".solve")&&box.closest(".solve").querySelector(".strip");
    const cards=strip?[...strip.querySelectorAll(".move")]:[];
    const nmv=box.querySelector(".nmv"),nhint=box.querySelector(".nhint"),prog=box.querySelector(".p3d-prog i");
    const play=box.querySelector(".act-play"),loopB=box.querySelector(".act-loop");
    const speed=Number(localStorage.getItem("algSpeed")||1);
    const p=new window.CubePlayer(stage,{colors:COL,speed,onChange:st=>{
      const nx=st.move;
      nmv.textContent=st.rest?"⏸":nx?nx.raw.replace("'","′"):"✓";
      nhint.textContent=st.rest===1?"алгоритм доигран — сейчас заново":st.rest===2?"пауза перед повтором":nx?hintText(nx):"алгоритм доигран";
      play.textContent=st.playing?"⏸":"▶";
      loopB.classList.toggle("on",st.loop);
      prog.style.width=(st.total?st.index/st.total*100:0)+"%";
      cards.forEach((c,i)=>c.classList.toggle("on",i===st.index&&!!nx&&!st.rest));
    }});
    p.load(box.dataset.alg,(box.dataset.state||"").split(",").filter(Boolean).map(v=>"#"+v));
    box.__player=p; LIVE.add(p);
    box.addEventListener("click",e=>{
      const b=e.target.closest("button");if(!b)return;
      if(b.classList.contains("act-play"))p.toggle();
      else if(b.classList.contains("act-next"))p.stepFwd();
      else if(b.classList.contains("act-prev"))p.stepBack();
      else if(b.classList.contains("act-rew")){p.pause();p.rewind();}
      else if(b.classList.contains("act-loop"))p.setLoop(!p.loop);
      else if(b.classList.contains("act-view"))p.resetView();
      else if(b.classList.contains("spd")){
        const v=b.dataset.v;localStorage.setItem("algSpeed",v);p.setSpeed(Number(v));
        [...box.querySelectorAll(".spd")].forEach(x=>x.classList.toggle("on",x===b));
      }
    });
    cards.forEach((c,i)=>{c.style.cursor="pointer";c.title="Показать этот ход в 3D";
      c.addEventListener("click",()=>{p.pause();p.seek(i);});});
  });
}
window.addEventListener("beforeunload",()=>{for(const p of LIVE)p.dispose();LIVE.clear();});

/* startState (необязательно) — с какого состояния стартует 3D. Ассистент передаёт сюда
   живой кубик, чтобы наглядный пример шёл ровно от того, что у тебя в руках. */
function solveHTML(states,moves,eff,mode,label,startState){
  const caseBox=`<div class="casebox">${caseDiagram(states[0],mode)}<div class="clabel">${label||"Случай"}</div></div>`;
  const strip=moves.map((mv,i)=>moveCard(states[i],mv,i+1)).join("");
  return `<div class="solve"><div class="side3d">${caseBox}${playerHTML(eff,startState||stateColors(states[0]))}</div><div class="strip">${strip}</div></div>`;
}
function renderSolveInto(el,alg,mode){
  let sf=statesFor(alg);
  if(!sf.moves.length){el.innerHTML=`<p style="color:var(--muted);font-size:14px">Не вижу ходов. Пример: <code>R U R'</code></p>`;return;}
  const m=mode||detectMode(sf.states[0]);
  if(m==='f2l'||m==='oll')sf=statesFor(alg,m,0);   // финал этапа — без «магической» полной сборки
  el.innerHTML=solveHTML(sf.states,sf.moves,sf.eff,m);
  mountPlayers(el);
}
/* legend */
document.getElementById("legend").innerHTML=["U","U'","R","R'","L","L'","F","F'","D","D'","F2","y"].map(t=>moveCard(solvedCube(),parseAlg(t)[0],"")).join("");

/* ===== data ===== */
const F2L_POOL=["R U R'","F' U' F","U R U' R'","U F' U2 F","R U R2 F R F'","R U' R' F' U' F","F' U' F2 R' F' R","F' U2 F2 R' F' R","R U' R' U R U' R'","R U R' U' R U R'","R U R' d R' U2 R","F' U' F U R U' R'","F' U F U R U' R'","R U R' U2 R U' R'","R U2 R' U2 R U' R'","R d' R U R' U2 F'","y F2 R U R' U' F2","R U2 R' U' R U R'","R2 U2 R2 U' R2 U' R2","R' U2 R2 U R2 U R","R U' R' U2 F' U' F","R U' R' F R' F' R","r' U2 R2 U R2 U r","F2 U2 F U F' U F2","y F2 U R U' R' F2","F' U2 F U F' U' F","U' R' F R F' R U' R'","U R U2 R' U R U' R'","U R U' R' U2 R U' R'","U' R U' R' U R U R'","U R U2' R' U R U R'","U2 R2 U2 R' U' R U' R2","U2 R U' R' U' F' U' F","U' R U2 R' d R' U' R","d R' U R U' R' U' R","R U' R U2 R2 U' R2 U' R2","R F U R U' R' F' U' R'","R2 U2 F R2 F' U2 R' U R'","R2 U2 R' U' R U' R' U2 R'","R2 U2 F R' F' U2 R' U2 R'","R U F R U R' U' F' R'"];

const OLL_ALGS=["R U2' R2' F R F' U2 R' F R F'","R U' R2' D' r U r' D R2 U R'","f R U R' U' f' U' F R U R' U' F'","f R U R' U' f' U F R U R' U' F'","l' U2 L U L' U l","r U2 R' U' R U' r'","r U R' U R U2 r'","l' U' L U' L' U2 l","R U R' U' R' F R2 U R' U' F'","R U R' U R' F R F' R U2' R'","r' R2 U R' U R U2' R' U M'","r R2' U' R U' R' U2 R U' r' R","F U R U2' R' U' R U R' F'","R' F R U R' F' R F U' F'","l' U' l L' U' L U l' U l","r U r' R U R' U' r U' r'","R U R' U R' F R F' U2 R' F R F'","R U2 R2 F R F' U2 M' U R U' r'","S' R U R' S U' R' F R F'","r' R U R U R' U' r R' M' U R U' r'","R U R' U R U' R' U R U2 R'","R U2' R2' U' R2 U' R2' U2' R","R2' D' R U2 R' D R U2 R","r U R' U' r' F R F'","F R' F' r U R U' r'","R U2 R' U' R U' R'","R U R' U R U2' R'","r U R' U' r' R U R U' R'","R U R' U' R U' R' F' U' F R U R'","F R' F R2 U' R' U' R U R' F2","R' U' F U R U' R' F' R","S R U R' U' R' F R f'","R U R' U' R' F R F'","R U R2' U' R' F R U R U' F'","R U2' R2' F R F' R U2' R'","L' U' L U' L' U L U L F' L' F","F R' F' R U R U' R'","R U R' U R U' R' U' R' F R F'","L F' L' U' L U F U' L'","R' F R U R' U' F' U R","R U R' U R U2 R' F R U R' U' F'","R' U' R U' R' U2' R F R U R' U' F'","R' U' F' U F R","F U R U' R' F'","F R U R' U' F'","R' U' R' F R F' U R","F R' F' R U2 R U' R' U R U2' R'","F R U R' U' R U R' U' F'","r U' r2' U r2 U r2' U' r","r' U r2 U' r2' U' r2 U r'","F U R U' R' U R U' R' F'","R' U' R U' R' U F' U F R","l' U' L U' L' U L U' L' U2 l","r U R' U R U' R' U R U2' r'","R' F R U R U' R2' F' R2 U' R' U R U R'","r U r' U R U' R' U R U' R' r U' r'","R U R' U' M' U R U' r'"];

const PLL_ALGS=[
 ["Aa","x' R2 D2 R' U' R D2 R' U R' x"],["Ab","x' R U' R D2 R' U R D2 R2' x"],
 ["E","x' R U' R' D R U R' D' R U R' D R U' R' D' x"],
 ["F","y L R2 U R U R2 U' R' U' R2 U' R U2 L' U R'"],
 ["Ga","y R2 U R' U R' U' R U' R2 D U' R' U R D'"],["Gb","R' U' R U D' R2 U R' U R U' R U' R2 D"],
 ["Gc","y R2 U' R U' R U R' U R2 D' U R U' R' D"],["Gd","y2 R U R' U' D R2 U' R U' R' U R' U R2 D'"],
 ["H","M2 U M2 U2 M2 U M2"],["Ja","y2 L U' R' U L' U2 R U' R' U2 R"],["Jb","y2 R' U L U' R U2 L' U L U2 L'"],
 ["Na","R U R' U R U R' F' R U R' U' R' F R2 U' R' U2 R U' R'"],["Nb","R' U R U' R' F' U' F R U R' F R' F' R U' R"],
 ["Ra","y' R U' R' U' R U R D R' U' R D' R' U2 R'"],["Rb","R' U2 R U2 R' F R U R' U' R' F' R2 U'"],
 ["T","R U R' U' R' F R2 U' R' U' R U R' F'"],["Ua","M2 U M U2 M' U M2"],["Ub","M2 U' M U2 M' U' M2"],
 ["V","y R' U R U' R' f' U' R U2 R' U' R U' R' f R"],["Y","F R U' R' U' R U R' F' R U R' U' R' F R F'"],
 ["Z","M' U M2 U M2 U M' U2 M2"]
];

/* ===== build categories ===== */
function buildCategory(list,type){
  const bySig={};
  for(const it of list){
    let sf; try{sf=statesFor(it.alg);}catch(e){continue;}
    const cs=sf.states[0]; let ok=false,sig="";
    if(type==='f2l'){ok=isF2LCase(cs);sig=it.alg;}
    else if(type==='oll'){ok=isLastLayer(cs)&&!pllOriented(cs);sig=aufCanon(cs,ollSigRaw);}
    else {ok=isLastLayer(cs)&&pllOriented(cs);sig=aufCanon(cs,pllSigRaw);}
    if(!ok)continue;
    const entry={label:it.label,alg:it.alg,eff:sf.eff,moves:sf.moves,states:sf.states,mc:parseAlg(it.alg).length,mode:type};
    if(!bySig[sig]||entry.mc<bySig[sig].mc)bySig[sig]=entry;
  }
  const arr=Object.values(bySig);
  if(type==='oll'){
    const ord={"Точка — нет рёбер":0,"Линия":1,"Уголок (L)":2,"Крест — все рёбра":3};
    arr.forEach(e=>{ e.type=ollType(e.states[0]); e.grp=e.type.split(" — ")[0]; e.ord=ord[e.type]; });
    arr.sort((a,b)=> (a.ord-b.ord) || (a.mc-b.mc));
  } else if(type==='pll'){
    arr.forEach(e=>{ e.type=PLL_NAME[e.label]||e.label; e.grp=e.type; });
    arr.sort((a,b)=> (a.type<b.type?-1:a.type>b.type?1:0) || (a.mc-b.mc));
  } else {
    arr.sort((a,b)=>a.mc-b.mc);
  }
  /* F2L и OLL показываем на кубе с ещё несобранным верхом — чтобы финал этапа выглядел
     так, как он выглядит в реальной сборке. Вариант «мусора» наверху берём по номеру
     случая, чтобы картинка была стабильной между открытиями. */
  if(type!=='pll')arr.forEach((e,i)=>{const s=statesFor(e.alg,type,i);e.states=s.states;e.moves=s.moves;e.eff=s.eff;});
  return arr;
}
const DATA={};
DATA.f2l=buildCategory(F2L_POOL.map(a=>({alg:a})),'f2l'); DATA.f2l.forEach((e,i)=>e.label="Случай "+(i+1));
DATA.oll=buildCategory(OLL_ALGS.map((a,i)=>({alg:a,label:"OLL "+(i+1)})),'oll');
DATA.pll=buildCategory(PLL_ALGS.map(p=>({alg:p[1],label:p[0]})),'pll');

/* ===== tabs + gallery ===== */
const TABDEF=[["f2l","F2L"],["oll","OLL"],["pll","PLL"]];
let curTab="f2l",knownRefresh=null;
const tabsEl=document.getElementById("tabs"),galleryEl=document.getElementById("gallery"),detailEl=document.getElementById("detail");
function renderTabs(){tabsEl.innerHTML=TABDEF.map(([k,n])=>`<button class="tab ${k===curTab?'on':''}" data-k="${k}">${n}<span class="cnt">${DATA[k].length}</span></button>`).join("");}
function renderGallery(){
  const arr=DATA[curTab];
  let html="",lastGrp=null;
  arr.forEach((e,i)=>{
    if(e.grp&&e.grp!==lastGrp){ html+=`<div class="ghead">${e.grp}</div>`; lastGrp=e.grp; }
    html+=`<button class="gcard" data-i="${i}" data-l="${e.label}"><div class="thumb">${caseDiagram(e.states[0],e.mode)}</div><div class="lab">${e.label}</div><div class="mc">${e.mc} ход.</div></button>`;
  });
  galleryEl.innerHTML=html;
  if(knownRefresh)knownRefresh();
}
function renderDetail(i){
  const e=DATA[curTab][i];
  const typ=e.type?`<span class="typ">${e.type}</span>`:"";
  detailEl.innerHTML=`<div class="detbar"><h3>${e.label}</h3>${typ}<span class="alg">${e.eff.replace(/'/g,"′")}</span><button class="act ghost drilladd" data-m="${curTab}" data-l="${e.label}">Зубрить этот случай</button><p class="desc">${caseDesc(e.states[0],e.mode)}</p></div>`
    +solveHTML(e.states,e.moves,e.eff,e.mode,e.label);
  mountPlayers(detailEl);
  [...galleryEl.querySelectorAll('.gcard')].forEach((c,k)=>c.classList.toggle('sel',k===i));
  detailEl.scrollIntoView({behavior:"smooth",block:"nearest"});
}
tabsEl.addEventListener("click",e=>{const b=e.target.closest(".tab");if(!b)return;curTab=b.dataset.k;renderTabs();renderGallery();detailEl.innerHTML="";});
galleryEl.addEventListener("click",e=>{const b=e.target.closest(".gcard");if(!b)return;renderDetail(Number(b.dataset.i));});
/* «Зубрить этот случай» — кладём случай в набор режима «Зубрила» и уходим туда */
detailEl.addEventListener("click",e=>{const b=e.target.closest(".drilladd");if(!b)return;
  if(window.DrillNav)window.DrillNav(b.dataset.m,b.dataset.l);});
renderTabs();renderGallery();
/* «Знаю»: правый клик / режим-галочка зачёркивает выученные случаи (known.js) */
if(window.Known)knownRefresh=window.Known.attach(document.getElementById("knownBar"),galleryEl,()=>curTab,()=>DATA[curTab].length);

/* ===== paste box ===== */
const input=document.getElementById("input"),out=document.getElementById("out");
function run(){renderSolveInto(out,input.value);}
document.getElementById("go").addEventListener("click",run);
document.getElementById("clear").addEventListener("click",()=>{input.value="";out.innerHTML="";input.focus();});
input.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key==="Enter")run();});
run();

/* jump from the coach to a specific case in the Schemes tab */
window.CoachNav=function(mode,label){
  const nav=document.getElementById('topnav');
  if(nav)[...nav.querySelectorAll('.navtab')].forEach(t=>t.classList.toggle('on',t.dataset.v==='schemes'));
  document.querySelectorAll('.view').forEach(el=>{el.hidden=el.id!=='view-schemes';});
  curTab=mode; renderTabs(); renderGallery();
  const i=DATA[mode].findIndex(e=>e.label===label);
  detailEl.innerHTML=""; if(i>=0)renderDetail(i);
  window.scrollTo({top:0,behavior:"smooth"});
};

/* ===== engine API for the learning assistant (coach.js) ===== */
window.CubeEngine={
  solvedCube,clone,applyMove,parseAlg,
  COL,NKEY,readSt,
  findPair,isF2LCase,isLastLayer,pllOriented,detectMode,
  ollSigRaw,pllSigRaw,f2lSigRaw,aufCanon,
  caseDiagram,moveCard,caseDesc,solveHTML,mountPlayers,stateColors,
  DATA
};

/* dev */
window.__stats=()=>({f2l:DATA.f2l.length,oll:DATA.oll.length,pll:DATA.pll.length,
  ollInvalid:OLL_ALGS.filter(a=>{const c=statesFor(a).states[0];return !(isLastLayer(c)&&!pllOriented(c));}),
  pllInvalid:PLL_ALGS.filter(p=>{const c=statesFor(p[1]).states[0];return !(isLastLayer(c)&&pllOriented(c));}).map(p=>p[0])});
