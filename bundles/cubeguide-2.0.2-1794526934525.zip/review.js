"use strict";
/* ===== Разбор сборки (коуч «после финиша») =====
   session.js записывает сборку: состояние на старте + каждый ход с меткой времени.
   После финиша прогоняем ходы заново и по живому состоянию находим, где закончился
   каждый этап CFOP: крест → 4 пары F2L → OLL → PLL. Для каждого этапа — время,
   ходы, пауза на «поиск» перед ним. Дальше сравниваем с лучшим вариантом:
     · крест — с оптимальным решением (CrossSolver, точный перебор);
     · F2L — с самой короткой парой, которую видел ассистент, и с длиной схемы случая;
     · OLL / PLL — с алгоритмом из базы для твоего случая;
   и отдельно ловим ходы впустую (R сразу R′) и долгие паузы.
   Советы сортируем по тому, сколько секунд они реально стоили. */
(function () {
  const F = window.Facelet, E = window.CubeEngine;

  const v = m => (F.toView ? F.toView(m) : m);                 // ход кубика → как на схемах
  const pretty = s => s.replace(/'/g, '′');
  const sec = ms => (ms / 1000).toFixed(ms < 10000 ? 2 : 1);

  /* ходы → HTM: соседние ходы одной грани склеиваем (R R → R2, R R′ → ничего) */
  function merge(list) {
    const out = []; let wasted = 0;
    for (const m of list) {
      const f = m[0], q = /2/.test(m) ? 2 : /'/.test(m) ? 3 : 1;
      const top = out[out.length - 1];
      if (top && top.f === f) {
        top.q = (top.q + q) % 4; top.n++;
        if (top.q === 0) { wasted += top.n; out.pop(); }
      } else out.push({ f, q, n: 1 });
    }
    return { htm: out.length, wasted, alg: out.map(o => o.f + ['', '', '2', "'"][o.q]).join(' ') };
  }

  function stageOf(C, fac) {
    const base = C.faceletsToCubies(fac), g = C.eng;
    const solved = fac === F.SOLVED;
    const ll = E.isLastLayer(base);
    const cross = ll || g.crossEdges(base) === 4;
    const slots = ll ? 4 : cross ? g.analyzeF2L(base).solved : 0;
    return { base, cross, slots, ll, oriented: ll && E.pllOriented(base), solved };
  }

  function build(rec) {
    const C = window.Coach;
    if (!C || !C.eng || !rec || !rec.moves || !rec.moves.length) return null;
    const g = C.eng, mv = rec.moves, n = mv.length;

    // состояния после каждого хода
    const fac = [rec.startFac];
    for (const x of mv) fac.push(F.applyMove(fac[fac.length - 1], x.m));
    const st = fac.map(f => stageOf(C, f));

    // вехи: первый ход, после которого этап готов
    const first = (from, ok) => { for (let i = from; i <= n; i++) if (ok(st[i])) return i; return -1; };
    const at = {};
    at.cross = first(0, s => s.cross);
    let prev = at.cross;
    for (let k = 1; k <= 4 && prev >= 0; k++) { at['f' + k] = first(prev, s => s.cross && s.slots >= k); prev = at['f' + k]; }
    at.oll = prev >= 0 ? first(prev, s => s.oriented) : -1;
    at.pll = at.oll >= 0 ? first(at.oll, s => s.solved) : -1;

    const tAt = i => i === 0 ? rec.t0 : mv[i - 1].t;            // момент, когда стало состояние i
    const SEG = [['cross', 'Крест'], ['f1', 'F2L · пара 1'], ['f2', 'F2L · пара 2'], ['f3', 'F2L · пара 3'], ['f4', 'F2L · пара 4'], ['oll', 'OLL'], ['pll', 'PLL']];
    const segs = [];
    let from = 0;
    for (const [key, label] of SEG) {
      const to = at[key];
      if (to == null || to < 0) break;
      const list = mv.slice(from, to).map(x => x.m);
      const t1 = tAt(from), t2 = key === 'pll' && rec.tEnd ? rec.tEnd : tAt(to);
      let pause = 0, pauseAt = 0;
      for (let i = from + 1; i < to; i++) { const d = mv[i].t - mv[i - 1].t; if (d > pause) { pause = d; pauseAt = i; } }
      segs.push({
        key, label, from, to, ms: Math.max(0, t2 - t1), q: list.length,
        look: to > from ? Math.max(0, mv[from].t - t1) : 0,   // сколько смотрел, прежде чем начать этап
        pause, pauseAt, m: merge(list), list
      });
      from = to;
    }
    const total = Math.max(1, (rec.tEnd || mv[n - 1].t) - rec.t0);
    const perMove = total / n;
    const tips = [], good = [];

    /* ---------- крест ---------- */
    const sc = segs.find(s => s.key === 'cross');
    if (sc && window.CrossSolver) {
      const opt = CrossSolver.solve(rec.startFac);
      if (opt) {
        sc.opt = opt.n;
        if (sc.m.htm > opt.n + 1) tips.push({
          loss: (sc.m.htm - opt.n) * perMove, stage: 'Крест',
          html: `Крест — <b>${sc.m.htm}</b> ход., а можно было за <b>${opt.n}</b>: <code>${pretty(opt.moves.map(v).join(' '))}</code>. ` +
                `Планируй крест целиком ещё до первого хода — все 4 ребра, а не по одному. <a class="rv-cg" href="#">Гайд: быстрый крест →</a>`
        });
        else if (opt.n > 0) good.push(`Крест почти оптимальный: ${sc.m.htm} ход. при лучших ${opt.n}.`);
      }
    }

    /* ---------- F2L ---------- */
    segs.filter(s => /^f\d$/.test(s.key)).forEach(s => {
      const k = +s.key[1];
      const merged = st[s.from].slots >= k;                     // пара встала заодно с предыдущей
      if (merged || !s.q) { s.note = 'вместе с прошлой'; return; }
      const startBase = st[s.from].base, endBase = st[s.to].base;
      const an = g.analyzeF2L(startBase), best = g.bestOf(an.cands);
      const chosen = an.cands.find(c => g.slotSolvedByColors(endBase, c.sideF, c.sideR)) || null;
      const name = c => `${g.CNAME[c.sideF]} + ${g.CNAME[c.sideR]}`;
      const cost = c => c && c.entry ? g.reportedCost(c.entry.eff) : null;
      if (chosen) s.pair = name(chosen);
      const cc = cost(chosen), bc = cost(best);
      if (chosen && cc != null) s.opt = cc;
      if (chosen && cc != null && s.q > cc + 4) {
        const rot = chosen.k ? g.AUF_STR[chosen.k].replace('U', 'y') + ' ' : '';
        tips.push({
          loss: (s.q - cc) * perMove, stage: 'F2L',
          html: `Пара <b>${name(chosen)}</b>: у тебя <b>${s.q}</b> ход., по схеме «${chosen.entry.label}» — <b>${cc}</b>: ` +
                `<code>${pretty(rot + chosen.entry.eff)}</code>. Выучи этот случай — он часто встречается.`
        });
      }
      if (best && chosen && best !== chosen && bc != null && cc != null && cc > bc + 3) {
        tips.push({
          loss: (cc - bc) * perMove, stage: 'F2L',
          html: `Перед парой ${k} выгоднее было взять <b>${name(best)}</b> (случай «${best.entry.label}», ${bc} ход.) вместо ` +
                `<b>${name(chosen)}</b> (${cc}). Окинь взглядом все свободные пары и бери самую короткую.`
        });
      }
    });

    /* ---------- OLL / PLL ---------- */
    for (const key of ['oll', 'pll']) {
      const s = segs.find(x => x.key === key);
      if (!s) continue;
      if (!s.q || s.to === s.from) { s.note = 'скип'; good.push(`${key.toUpperCase()}-скип — повезло!`); continue; }
      const a = C.analyze(fac[s.from]);
      if (a.stage !== key || !a.entry) continue;
      const e = a.live || a.entry, cost = g.reportedCost(e.eff);
      s.case = a.entry.label; s.opt = cost;
      if (s.q > cost + 4) tips.push({
        loss: (s.q - cost) * perMove, stage: key.toUpperCase(),
        html: `${key.toUpperCase()} «${a.entry.label}»: у тебя <b>${s.q}</b> ход., алгоритм — <b>${cost}</b>: <code>${pretty(e.eff)}</code>` +
              (key === 'oll' ? '. Похоже на 2-look — этот случай стоит выучить целиком.' : '. Похоже, шёл в обход — выучи этот PLL.')
      });
      else good.push(`${key.toUpperCase()} «${a.entry.label}» — по алгоритму (${s.q} ход.).`);
    }

    /* ---------- паузы ---------- */
    segs.forEach(s => {
      if (s.key !== 'cross' && s.look > 900) tips.push({
        loss: s.look - 400, stage: s.label,
        html: `Перед «${s.label}» стоял <b>${sec(s.look)} с</b>. ` +
              (/^f/.test(s.key) ? 'Ищи следующую пару, пока докручиваешь текущую (look-ahead) — тогда пауз не будет.'
                                : 'Распознавай случай заранее, на последних ходах прошлого этапа.')
      });
      if (s.pause > 1200) tips.push({
        loss: s.pause - 400, stage: s.label,
        html: `Внутри «${s.label}» застрял на <b>${sec(s.pause)} с</b> (после хода ${pretty(v(mv[s.pauseAt - 1].m))}). ` +
              `Медленнее, но без остановок — быстрее, чем рывками.`
      });
    });

    /* ---------- ходы впустую ---------- */
    const wasted = segs.reduce((a, s) => a + s.m.wasted, 0);
    if (wasted >= 2) tips.push({
      loss: wasted * perMove, stage: 'Чистота',
      html: `<b>${wasted}</b> ход. впустую — грань крутилась и тут же возвращалась (` +
            segs.filter(s => s.m.wasted).map(s => `${s.label}: ${s.m.wasted}`).join(', ') + `). Сначала посмотри, потом крути.`
    });
    else if (n > 20) good.push('Ни одного хода впустую.');

    tips.sort((a, b) => b.loss - a.loss);
    const incomplete = at.pll < 0;
    return { total, n, tps: n / (total / 1000), segs, tips: tips.slice(0, 6), good, incomplete, wasted, speed: speedOf(mv) };
  }

  /* ---------- скорость пальцев: самые быстрые ходы ----------
     Время хода = промежуток от прошлого хода до этого. Берём часы самого кубика (hw),
     если они есть у обоих ходов, иначе — время прихода по Bluetooth. */
  function speedOf(mv) {
    const gap = i => {
      const a = mv[i - 1], b = mv[i];
      if (a.hw != null && b.hw != null && b.hw > a.hw) return b.hw - a.hw;
      return b.t - a.t;
    };
    const ok = d => d > 0 && d < 3000;
    let single = null, dbl = null, pair = null;
    const face = {};
    for (let i = 1; i < mv.length; i++) {
      const d = gap(i), m = v(mv[i].m), p = v(mv[i - 1].m);
      if (!ok(d)) continue;
      if (!single || d < single.ms) single = { ms: d, m };
      const f = m[0];
      if (!face[f] || d < face[f].ms) face[f] = { ms: d, m };
      if (p === m && (!dbl || d < dbl.ms)) dbl = { ms: d, m: m[0] + '2', how: p + ' ' + m };   // R R / R′ R′ = R2
      if (i >= 2 && p[0] !== m[0]) {                                              // связка двух разных граней
        const d0 = gap(i - 1);
        if (ok(d0) && (!pair || d0 + d < pair.ms)) pair = { ms: d0 + d, m: p + ' ' + m };
      }
    }
    if (!single) return null;
    return { single, dbl, pair, face };
  }

  /* ---------- вёрстка ---------- */
  const COLOR = { cross: 'var(--ink-dim)', f1: 'var(--blue)', f2: 'var(--blue)', f3: 'var(--blue)', f4: 'var(--blue)', oll: 'var(--yellow)', pll: 'var(--green)' };
  function html(r) {
    if (!r) return '';
    const bar = r.segs.map(s => s.ms > 0
      ? `<i style="flex:${s.ms} 1 0; background:${COLOR[s.key]}" title="${s.label}: ${sec(s.ms)} с"><b>${s.key === 'cross' ? 'Крест' : s.key.toUpperCase().replace(/^F(\d)/, 'F2L $1')}</b></i>` : '').join('');
    const rows = r.segs.map(s => `<tr>
        <td><span class="rv-dot" style="background:${COLOR[s.key]}"></span>${s.label}${s.pair ? ` <small>${s.pair}</small>` : ''}${s.case ? ` <small>«${s.case}»</small>` : ''}${s.note ? ` <small>${s.note}</small>` : ''}</td>
        <td>${sec(s.ms)} с</td>
        <td>${s.key === 'cross' ? s.m.htm : s.q}${s.opt != null ? ` <small>/ ${s.opt}${s.key === 'cross' ? ' опт.' : ''}</small>` : ''}</td>
        <td>${s.key === 'cross' ? '—' : sec(s.look) + ' с'}</td></tr>`).join('');
    const tips = r.tips.length
      ? r.tips.map(t => `<li><span class="rv-loss">−${sec(t.loss)} с</span><span class="rv-st">${t.stage}</span><div>${t.html}</div></li>`).join('')
      : `<li class="rv-ok"><div>Чистая сборка — явных ошибок не вижу. Дальше — только скорость пальцев и look-ahead.</div></li>`;
    const good = r.good.length ? `<div class="rv-good">${r.good.map(x => `<span>✓ ${x}</span>`).join('')}</div>` : '';
    return `<div class="rv">
      <div class="rv-h"><span class="rv-t">Разбор сборки</span>
        <span class="rv-sum">${sec(r.total)} с · ${r.n} ход. · TPS ${r.tps.toFixed(1)}</span></div>
      ${r.incomplete ? '<p class="rv-warn">Не все ходы дошли с кубика — разбор приблизительный.</p>' : ''}
      <div class="rv-bar">${bar}</div>
      <table class="rv-tab"><thead><tr><th>Этап</th><th>Время</th><th>Ходов <small>/ норма</small></th><th>Пауза до</th></tr></thead><tbody>${rows}</tbody></table>
      <div class="rv-tt">Что улучшить — по тому, сколько стоило</div>
      <ul class="rv-tips">${tips}</ul>
      ${good}
      ${speedHTML(r.speed)}
    </div>`;
  }

  function speedHTML(sp) {
    if (!sp) return '';
    const ms = x => `${Math.round(x)} мс`;
    const card = (t, o, note) => o
      ? `<div class="rv-sp"><span>${t}</span><b>${ms(o.ms)}</b><code>${pretty(o.m)}</code>${note ? `<small>${note}</small>` : ''}</div>`
      : `<div class="rv-sp rv-sp-no"><span>${t}</span><b>—</b><small>не было</small></div>`;
    const faces = ['R', 'U', 'F', 'L', 'D', 'B'].map(f => sp.face[f]
      ? `<span class="rv-fc"><code>${f}</code>${ms(sp.face[f].ms)}</span>`
      : `<span class="rv-fc rv-sp-no"><code>${f}</code>—</span>`).join('');
    return `<div class="rv-tt">Скорость пальцев — самые быстрые ходы</div>
      <div class="rv-sps">
        ${card('Одиночный ход', sp.single)}
        ${card('Двойной ход', sp.dbl, sp.dbl ? pretty(sp.dbl.how) : '')}
        ${card('Связка из 2 ходов', sp.pair)}
      </div>
      <div class="rv-fcs"><span class="rv-st">По граням</span>${faces}</div>`;
  }

  window.Review = { build, html, _merge: merge };
})();
