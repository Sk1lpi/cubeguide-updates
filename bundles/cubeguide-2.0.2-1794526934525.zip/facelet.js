// Facelets (Kociemba URFDLB, 54 стикера) — истинное состояние кубика GAN.
// Порядок: U=0..8, R=9..17, F=18..26, D=27..35, L=36..44, B=45..53. В каждой грани:
//   0 1 2 / 3 4 5 / 6 7 8
// Таблицы сгенерированы из движка renderer.js и сверены с эталоном gan-web-bluetooth (F R).
(function (root) {
  const SOLVED = "UUUUUUUUURRRRRRRRRFFFFFFFFFDDDDDDDDDLLLLLLLLLBBBBBBBBB";
  // Цвета родной раскраски GAN: белый верх, зелёный фронт, красный право, жёлтый низ, оранж лево, синий зад
  const COLORS = { U: '#f6f6f6', R: '#e0202f', F: '#00a651', D: '#ffd23f', L: '#ff7a1a', B: '#2570d8' };

  // Циклы хода по часовой. Семантика: new[cyc[k]] = old[cyc[(k+1)%len]]
  const CW = {
    U: [[0,6,8,2],[1,3,7,5],[9,45,36,18],[10,46,37,19],[11,47,38,20]],
    R: [[2,20,29,51],[5,23,32,48],[8,26,35,45],[9,15,17,11],[10,12,16,14]],
    F: [[6,44,29,9],[7,41,28,12],[8,38,27,15],[18,24,26,20],[19,21,25,23]],
    D: [[15,24,42,51],[16,25,43,52],[17,26,44,53],[27,33,35,29],[28,30,34,32]],
    L: [[0,53,27,18],[3,50,30,21],[6,47,33,24],[36,42,44,38],[37,39,43,41]],
    B: [[0,11,35,42],[1,14,34,39],[2,17,33,36],[45,51,53,47],[46,48,52,50]]
  };

  function applyCyclesOnce(arr) {
    const src = arr.slice();
    return function (cycles) {
      for (const cyc of cycles) {
        const n = cyc.length;
        for (let k = 0; k < n; k++) arr[cyc[k]] = src[cyc[(k + 1) % n]];
      }
    };
  }

  function applyMove(facelets, move) {
    const face = move[0];
    if (!CW[face]) return facelets;
    const prime = move.indexOf("'") >= 0;
    const dbl = move.indexOf('2') >= 0;
    const times = dbl ? 2 : (prime ? 3 : 1);
    let arr = facelets.split('');
    for (let t = 0; t < times; t++) {
      const src = arr.slice();
      for (const cyc of CW[face]) {
        const n = cyc.length;
        for (let k = 0; k < n; k++) arr[cyc[k]] = src[cyc[(k + 1) % n]];
      }
    }
    return arr.join('');
  }

  // Кубик рапортует ходы в СВОЕЙ системе (белый верх, зелёный фронт), а всё приложение
  // показывает кубик так, как его собирают: белый вниз, красный фронт. Между системами —
  // тот же жёсткий разворот, что и для наклеек (M: (x,y,z) → (z,-y,x)): грани меняются
  // парами U↔D, L↔B, R↔F, а направление поворота сохраняется — разворот собственный.
  // Проверено сравнением facelets после хода кубика с состоянием движка схем.
  const VIEW_FACE = { U: 'D', D: 'U', L: 'B', B: 'L', R: 'F', F: 'R' };
  const toView = move => (move && VIEW_FACE[move[0]] ? VIEW_FACE[move[0]] + move.slice(1) : move);

  function applySeq(facelets, seq) {
    let f = facelets;
    for (const m of seq.trim().split(/\s+/)) if (m) f = applyMove(f, m);
    return f;
  }

  const API = { SOLVED, COLORS, applyMove, applySeq, VIEW_FACE, toView };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  if (root) root.Facelet = API;
})(typeof window !== 'undefined' ? window : null);
