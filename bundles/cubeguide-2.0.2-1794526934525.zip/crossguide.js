"use strict";
/* ===== Гайд «Быстрый крест» (раздел «Схемы») =====
   Правила быстрого креста, вставки одного ребра (посчитаны CrossSolver'ом — оптимальные)
   и тренажёр: случайный скрамбл → оптимальная длина креста → «Показать решение».
   Нотация — как на схемах: белый крест снизу, красный центр к себе. */
(function () {
  const F = window.Facelet, CS = window.CrossSolver;
  const root = document.getElementById('crossGuide');
  if (!root || !F || !CS) return;
  const pretty = s => s.replace(/'/g, '′');

  const RULES = [
    ['Крест — снизу', 'Собирай белый крест сразу на нижней грани. Не надо «ромашки» сверху и переворота куба: это +4–6 ходов и потеря обзора. Сразу после креста видно пары F2L.'],
    ['Весь крест — в инспекции', 'У тебя 15 секунд до старта. Найди все 4 белых ребра и придумай ходы для всех. Цель — 8 ходов или меньше: любой крест решается максимум за 8, в среднем ~6.'],
    ['Относительно, а не на место', 'Неважно, совпало ли ребро с центром сразу. Главное — чтобы рёбра стояли правильно <b>друг относительно друга</b> (по кругу: красный → синий → оранжевый → зелёный). В конце один доворот <code>D</code> ставит всё на место.'],
    ['Сначала пары', 'Начинай с двух рёбер, которые одним-двумя ходами встают рядом правильно. Ход, который ставит сразу два ребра, — лучший ход креста.'],
    ['Доворачивай низ, а не верх', 'Чтобы подставить место под ребро, крути <code>D</code>: так уже собранные рёбра «уезжают» из-под удара. Это главный приём быстрого креста.'],
    ['Без B и перехватов', 'Ходы <code>B</code> неудобны — перестрой план на <code>R L F D U</code>. Держи кубик одним хватом: каждый перехват — минус 0.3–0.5 с.'],
    ['Глаза — на следующую пару', 'Пока докручиваешь последнее ребро, уже ищи первую пару F2L. Пауза после креста — самая дорогая в сборке.']
  ];

  // одно ребро (место — спереди снизу), остальные три уже стоят. Ходы — оптимум.
  const INS = [
    ['Сверху, белым вверх, прямо над местом', 'F2'],
    ['Сверху, белым вверх, над правым/левым/задним', "U F2 · U′ F2 · U2 F2"],
    ['Сверху спереди, белым к себе', "F D R′ D′  или  U′ R′ F R"],
    ['Сверху справа, белым вправо', "R′ F R"],
    ['Сверху слева, белым влево', "L F′ L′"],
    ['В среднем слое справа спереди, белым вправо', 'F'],
    ['В среднем слое слева спереди, белым влево', "F′"],
    ['В среднем слое справа спереди, белым к себе', "D R′ D′"],
    ['В среднем слое слева спереди, белым к себе', "D′ L D"],
    ['На своём месте, но перевёрнуто', "D R D′ F"],
    ['Внизу, но не на своём месте', 'Не вынимай! Подкрути D — может, оно уже стоит верно относительно других рёбер.']
  ];

  root.innerHTML = `
    <h2 class="h2"><span class="num">3</span>Быстрый крест — гайд</h2>
    <p class="sub">Крест — первые 2–3 секунды каждой сборки. У новичка он часто съедает 5–8 с и 12+ ходов, а у быстрых — 8 ходов за 1.5 с. Вот как к этому прийти.</p>
    <div class="cg-rules">${RULES.map(([t, d], i) => `<div class="cg-rule"><span class="cg-n">${i + 1}</span><div><b>${t}</b><p>${d}</p></div></div>`).join('')}</div>

    <div class="cg-tt">Вставка одного ребра <small>— место спереди снизу, белый крест снизу</small></div>
    <table class="cg-tab"><tbody>${INS.map(([w, a]) => `<tr><td>${w}</td><td><code>${pretty(a)}</code></td></tr>`).join('')}</tbody></table>

    <div class="cg-tt">Тренажёр креста</div>
    <div class="cg-train">
      <p class="sub" style="margin:0">Перемешай кубик по скрамблу (белый снизу, красный к себе), за 15 с придумай крест целиком — и только потом крути. Сверься с оптимумом.</p>
      <div class="cg-scr" id="cgScr"></div>
      <div class="row">
        <button class="act" id="cgNew">Новый скрамбл</button>
        <button class="act ghost" id="cgInsp">Инспекция 15 с</button>
        <button class="act ghost" id="cgShow">Показать решение</button>
        <span class="cg-insp" id="cgClock"></span>
      </div>
      <div class="cg-sol" id="cgSol" hidden></div>
    </div>`;

  const elScr = root.querySelector('#cgScr'), elSol = root.querySelector('#cgSol'), elClock = root.querySelector('#cgClock');
  let cur = null, timer = null;

  function scramble() {
    const faces = 'URFDLB', axis = { U: 0, D: 0, R: 1, L: 1, F: 2, B: 2 };
    const out = []; let last = '', prev = '';
    while (out.length < 20) {
      const f = faces[Math.random() * 6 | 0];
      if (f === last || (axis[f] === axis[last] && f === prev)) continue;
      out.push(f + ['', "'", '2'][Math.random() * 3 | 0]);
      prev = last; last = f;
    }
    return out;
  }
  function fresh() {
    const sc = scramble();                                  // ходы в системе кубика
    const fac = sc.reduce((f, m) => F.applyMove(f, m), F.SOLVED);
    const sol = CS.solve(fac);
    cur = { view: sc.map(F.toView).join(' '), sol };
    elScr.innerHTML = `<code>${pretty(cur.view)}</code><span class="cg-opt">крест за <b>${sol.n}</b> ход.</span>`;
    elSol.hidden = true; stopInsp();
  }
  function stopInsp() { if (timer) clearInterval(timer); timer = null; elClock.textContent = ''; }
  root.querySelector('#cgNew').addEventListener('click', fresh);
  root.querySelector('#cgShow').addEventListener('click', () => {
    if (!cur) return;
    stopInsp();
    elSol.innerHTML = cur.sol.n ? `Оптимум (${cur.sol.n} ход.): <code>${pretty(cur.sol.moves.map(F.toView).join(' '))}</code> <small>— одно из лучших решений; твоё может быть другим, но той же длины.</small>` : 'Крест уже собран.';
    elSol.hidden = false;
  });
  root.querySelector('#cgInsp').addEventListener('click', () => {
    stopInsp();
    const end = performance.now() + 15000;
    const tick = () => {
      const left = Math.max(0, end - performance.now());
      elClock.textContent = left > 0 ? (left / 1000).toFixed(1) + ' с' : 'Время! Крути.';
      elClock.classList.toggle('late', left < 4000);
      if (!left) { clearInterval(timer); timer = null; }
    };
    tick(); timer = setInterval(tick, 100);
  });
  fresh();

  /* переход из разбора сборки («Гайд: быстрый крест →») */
  window.CrossGuideNav = function () {
    const over = document.getElementById('sessOver');
    if (over && !over.hidden) document.dispatchEvent(new KeyboardEvent('keydown', { code: 'Escape', key: 'Escape', bubbles: true }));
    const nav = document.getElementById('topnav');
    const t = nav && [...nav.querySelectorAll('.navtab')].find(x => x.dataset.v === 'schemes');
    if (t) t.click();
    setTimeout(() => root.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
  };
  document.addEventListener('click', ev => {
    const a = ev.target.closest && ev.target.closest('.rv-cg');
    if (a) { ev.preventDefault(); window.CrossGuideNav(); }
  });
})();
