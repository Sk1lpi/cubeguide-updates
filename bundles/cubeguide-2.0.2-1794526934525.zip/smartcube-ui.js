"use strict";
/* Smart Cube UI — состояние берём как facelets (истина с кубика), рисуем 3D (three.js) + развёртку */
(function () {
  const $ = id => document.getElementById(id);
  const elConnect = $('scConnect'), elCalib = $('scCalib'), elDisc = $('scDisc');
  const elMacRow = $('scMacRow'), elMac = $('scMac'), elMacGo = $('scMacGo');
  const elStatus = $('scStatus'), elCube3D = $('scCube3D'), elNet = $('scNet');
  const elMeta = $('scMeta'), elLog = $('scLog');

  const F = window.Facelet;
  let facelets = F ? F.SOLVED : null;
  let moveCount = 0;
  const meta = { name: '', mac: '', battery: null, hw: '', gyro: false };

  /* ---------- развёртка из facelets ----------
     Кубик отдаёт facelets в своей системе: белый верх, зелёный фронт. Собирают же
     кубик белым ВНИЗ, и все схемы в приложении нарисованы именно так: жёлтый верх,
     белый низ, красный фронт, зелёный право. Разворачиваем состояние в ту же
     ориентацию, иначе развёртка и подсказки показывали один кубик по-разному.
     Между системами — жёсткий поворот M: (x,y,z) → (z,-y,x) (он же обратный себе). */
  const M = v => [v[2], -v[1], v[0]];
  const FACELET_SLOT = {   // грань facelets → позиция кубика и нормаль в системе кубика
    U: { base: 0,  pos: (r, c) => [c - 1, 1, r - 1],  nrm: [0, 1, 0] },
    R: { base: 9,  pos: (r, c) => [1, 1 - r, 1 - c],  nrm: [1, 0, 0] },
    F: { base: 18, pos: (r, c) => [c - 1, 1 - r, 1],  nrm: [0, 0, 1] },
    D: { base: 27, pos: (r, c) => [c - 1, -1, 1 - r], nrm: [0, -1, 0] },
    L: { base: 36, pos: (r, c) => [-1, 1 - r, c - 1], nrm: [-1, 0, 0] },
    B: { base: 45, pos: (r, c) => [1 - c, 1 - r, -1], nrm: [0, 0, -1] }
  };
  // для каждой клетки развёртки — индекс наклейки в facelets
  const VIEW_IDX = (function () {
    const k = v => v.join(','), byPosNrm = new Map(), out = {};
    for (const f in FACELET_SLOT) {
      const FC = FACELET_SLOT[f];
      for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++)
        byPosNrm.set(k(FC.pos(r, c)) + '|' + k(FC.nrm), FC.base + r * 3 + c);
    }
    for (const f in FACELET_SLOT) {
      const FC = FACELET_SLOT[f], arr = [];
      for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++)
        arr.push(byPosNrm.get(k(M(FC.pos(r, c))) + '|' + k(M(FC.nrm))));
      out[f] = arr;
    }
    return out;
  })();

  const C = 22, G = 3, FG = 9, FW = 3 * C + 2 * G;
  function faceSVG(fac, face, ox, oy) {
    let s = '';
    for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) {
      const letter = fac[VIEW_IDX[face][r * 3 + c]];
      const col = (F.COLORS[letter]) || '#333';
      const x = ox + c * (C + G), y = oy + r * (C + G);
      s += `<rect x="${x}" y="${y}" width="${C}" height="${C}" rx="3.5" fill="${col}" stroke="var(--seam)" stroke-width="1.3"/>`;
    }
    return s;
  }
  function netSVG(fac) {
    const col = i => i * (FW + FG), row = i => i * (FW + FG);
    let s = '';
    s += faceSVG(fac, 'U', col(1), row(0));
    s += faceSVG(fac, 'L', col(0), row(1));
    s += faceSVG(fac, 'F', col(1), row(1));
    s += faceSVG(fac, 'R', col(2), row(1));
    s += faceSVG(fac, 'B', col(3), row(1));
    s += faceSVG(fac, 'D', col(1), row(2));
    const W = col(4) - FG, H = row(3) - FG;
    return `<svg viewBox="0 0 ${W} ${H}" role="img">${s}</svg>`;
  }

  let drawn = null;   // что уже нарисовано: пропускаем перестройку SVG/3D, если состояние то же
  function render() {
    if (!facelets) return;
    if (facelets !== drawn) {
      drawn = facelets;
      elNet.innerHTML = netSVG(facelets);
      if (window.Cube3D) Cube3D.setFacelets(facelets);
    }
    if (window.Coach) Coach.onState(facelets);
    if (window.Drill) Drill.onState(facelets);
    if (window.Session) Session.onState(facelets);
  }

  function addLog(mv) {
    const sp = document.createElement('span');
    // показываем ход так же, как он подписан на схемах (кубик рапортует в своей системе)
    sp.textContent = (F && F.toView ? F.toView(mv) : mv).replace("'", '′');
    elLog.prepend(sp);
    while (elLog.children.length > 40) elLog.removeChild(elLog.lastChild);
  }
  function setMeta() {
    const bat = meta.battery == null ? '—' : meta.battery + '%';
    elMeta.innerHTML =
      `Кубик: <b>${meta.name || '—'}</b><br>` +
      (meta.mac ? `MAC: <b>${meta.mac}</b><br>` : '') +
      (meta.hw ? `Прошивка: <b>${meta.hw}</b><br>` : '') +
      `Батарея: <b>${bat}</b><br>Ходов: <b>${moveCount}</b>` +
      (meta.gyro ? '<br>Гироскоп: <b>есть</b>' : '');
  }
  function status(text, cls) { elStatus.textContent = text; elStatus.className = 'sc-status' + (cls ? ' ' + cls : ''); }
  function setConnected(on) { elConnect.style.display = on ? 'none' : ''; elCalib.disabled = !on; elDisc.disabled = !on; }

  /* ---------- 3D ---------- */
  if (window.Cube3D && elCube3D) {
    try { Cube3D.mount(elCube3D); } catch (e) { console.error('3D mount failed', e); }
    // плитка резиновая: холст WebGL сам под неё не подстроится, поэтому следим за шириной
    if (window.ResizeObserver && Cube3D.resize) {
      try { new ResizeObserver(() => Cube3D.resize()).observe(elCube3D); } catch (e) {}
    }
  }
  const el3dReset = $('sc3dReset');
  const elFront = $('scFront');
  const FRONT_NAME = { R: 'красным', F: 'зелёным', L: 'оранжевым', B: 'синим' };
  try { const f = localStorage.getItem('cube3dFront'); if (f && elFront && FRONT_NAME[f]) elFront.value = f; } catch (e) {}
  const front = () => (elFront && FRONT_NAME[elFront.value]) ? elFront.value : 'R';
  if (elFront) elFront.addEventListener('change', () => { try { localStorage.setItem('cube3dFront', front()); } catch (e) {} });
  if (el3dReset) el3dReset.addEventListener('click', () => { if (window.Cube3D && Cube3D.resetOrientation) Cube3D.resetOrientation(front()); });

  /* ---------- проверки ---------- */
  if (!F) { status('Модуль facelet.js не загрузился.', 'err'); }
  if (!window.SmartCube) {
    status('Модуль Smart Cube не загрузился (npm run build:smartcube).', 'err');
    if (elConnect) elConnect.disabled = true;
    render(); setMeta(); return;
  }
  if (!window.SmartCube.bluetoothAvailable()) {
    const ios = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    status(ios
      ? 'Safari на iPhone не умеет Bluetooth. Для кубика открой эту страницу в бесплатном браузере Bluefy (App Store). Схемы, зубрила и таймер работают и тут.'
      : 'Браузер не умеет Bluetooth — открой в Chrome (на Android) или Edge/Chrome на компьютере.', 'err');
    if (elConnect) elConnect.disabled = true;
  }
  render(); setMeta();

  /* ---------- debounce запроса истинного состояния ---------- */
  let syncTimer = null;
  function scheduleSync() {
    if (syncTimer) clearTimeout(syncTimer);
    syncTimer = setTimeout(() => { SmartCube.requestFacelets(); }, 140);
  }

  /* ---------- события кубика ---------- */
  SmartCube.on('status', st => {
    if (window.Drill) Drill.onStatus(st);
    if (st.state === 'connecting') status(auto.busy ? 'Ищу кубик… Покрути его, чтобы он проснулся, — подключусь сам.' : 'Ищу кубик по Bluetooth…', 'wait');
    else if (st.state === 'connected') {
      meta.name = st.name || ''; meta.mac = st.mac || '';
      try { if (meta.mac) localStorage.setItem('cg-cube-mac', meta.mac.toUpperCase()); } catch (e) {}
      status('Подключён: ' + (st.name || 'GAN cube') + '. Собери кубик, поверни ' + FRONT_NAME[front()] + ' центром к себе, жёлтым вверх — и «Калибровать».', 'ok');
      setConnected(true); setMeta(); elMacRow.style.display = 'none';
      if (window.Coach) Coach.onConnection(true);
      if (window.Drill) Drill.onConnection(true);
      if (window.Session) Session.onConnection(true);
    } else if (st.state === 'disconnected') { status('Отключён.', ''); setConnected(false); if (window.Cube3D) Cube3D.useManual(); if (window.Coach) Coach.onConnection(false); if (window.Drill) Drill.onConnection(false); if (window.Session) Session.onConnection(false); }
    else if (st.state === 'need-mac') { status('Не удалось определить MAC автоматически. Введи MAC вручную — он есть в приложении GAN (или в CubeGuide на компьютере, в карточке кубика). Вводится один раз.', 'wait'); if (elMac && !elMac.value) elMac.value = savedMac() || ''; elMacRow.style.display = 'flex'; }
    else if (st.state === 'error' && auto.busy) { status('Кубик не найден — продолжаю искать. Покрути его, чтобы он проснулся.', 'wait'); setConnected(false); }
    else if (st.state === 'error') { status('Ошибка подключения: ' + st.error, 'err'); elMacRow.style.display = 'flex'; setConnected(false); }
  });

  SmartCube.on('move', ev => {
    if (F) facelets = F.applyMove(facelets, ev.move); // оптимистично, поправится истинным состоянием
    if (window.Cube3D) Cube3D.playMove(ev.move);      // 3D доворачивает слой анимацией, цвета догоняют сами
    moveCount++; addLog(ev.move); setMeta();
    if (window.Coach) Coach.onMove(ev.move);
    if (window.Drill) Drill.onMove(ev.move);
    if (window.Session) Session.onMove(ev);   // событие целиком: в нём метка времени хода
    render();
    scheduleSync();
  });
  SmartCube.on('facelets', ev => { if (ev.facelets && ev.facelets.length >= 54) { facelets = ev.facelets; render(); } });
  SmartCube.on('gyro', ev => { if (window.Cube3D && ev.quaternion) Cube3D.setQuaternion(ev.quaternion); });
  SmartCube.on('battery', ev => { meta.battery = ev.batteryLevel; setMeta(); });
  SmartCube.on('hardware', ev => { meta.hw = ev.hardwareName || ''; meta.gyro = !!ev.gyroSupported; setMeta(); });

  /* ---------- автоподключение ----------
     main.js после загрузки окна раз в несколько секунд зовёт __cgAutoConnect() «от имени
     пользователя» (Web Bluetooth без жеста не ищет устройства). Пока кубик не подключён,
     идёт поиск ~25 с, потом новый круг; отвалился кубик — снова ищем. Кнопка «Отключить»
     ставит автоподключение на паузу до следующего ручного «Подключить». */
  const auto = { busy: false, paused: false };
  const savedMac = () => { try { return localStorage.getItem('cg-cube-mac') || null; } catch (e) { return null; } };
  window.__cgAutoConnect = async function () {
    if (auto.paused || auto.busy || SmartCube.isConnected() || !SmartCube.bluetoothAvailable()) return 'skip';
    auto.busy = true;
    try { await SmartCube.connect(savedMac()); return 'ok'; }
    catch (e) { return 'fail'; }
    finally { auto.busy = false; }
  };

  /* ---------- кнопки ---------- */
  elConnect.addEventListener('click', () => {
    auto.paused = false;
    if (auto.busy) { status('Уже ищу кубик — покрути его, чтобы он проснулся.', 'wait'); return; }
    SmartCube.connect(savedMac()).catch(() => {});
  });
  elMacGo.addEventListener('click', () => {
    auto.paused = false;
    const mac = elMac.value.trim();
    SmartCube.connect(mac).then(() => { try { if (mac) localStorage.setItem('cg-cube-mac', mac.toUpperCase()); } catch (e) {} }).catch(() => {});
  });
  elCalib.addEventListener('click', async () => {
    await SmartCube.calibrate();
    if (window.Cube3D && Cube3D.calibrateFront) Cube3D.calibrateFront(front());   // модель — тем же цветом к тебе
    if (F) facelets = F.SOLVED;
    moveCount = 0; elLog.innerHTML = ''; setMeta(); render();
    if (window.Session) Session.onCalibrate();
    status('Откалибровано: ' + FRONT_NAME[front()] + ' к тебе, жёлтый сверху. Крути — дальше всё само.', 'ok');
  });
  elDisc.addEventListener('click', () => { auto.paused = true; SmartCube.disconnect(); });
})();
