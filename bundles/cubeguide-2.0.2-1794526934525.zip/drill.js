"use strict";
/* ===== Зубрила — тренажёр повторов =====
   Берём до пяти случаев из галереи схем (F2L/OLL/PLL — можно вперемешку) и гоняем
   каждый по кругу: сначала N повторов «по схеме» (стрелки + 3D перед глазами),
   затем M повторов «по памяти» — остаётся только картинка случая, ходы спрятаны.
   Кубик при этом не обязан собираться или разбираться: задача — накрутить движение
   руками, поэтому повтор отмечает сам человек (кнопка или пробел).
   Набор и текущий подход лежат в localStorage 'cg-drill' — подход переживает
   перезапуск приложения. */
(function () {
  const E = window.CubeEngine;
  const $ = id => document.getElementById(id);
  const view = $('view-drill');
  if (!E || !view) return;

  const MAX = 5, KEY = 'cg-drill', PEEK_MS = 6000;
  const TABDEF = [['f2l', 'F2L'], ['oll', 'OLL'], ['pll', 'PLL']];

  /* ---------- состояние ---------- */
  const blank = () => ({ picked: [], hints: 10, blind: 5, auto: true, run: null, last: null });
  let S = blank();
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (raw && Array.isArray(raw.picked)) S = Object.assign(blank(), raw);
  } catch (e) {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Math.round(Number(v) || 0)));

  const setupEl = $('drillSetup'), runEl = $('drillRun'), doneEl = $('drillDone');
  const tabsEl = $('drillTabs'), galEl = $('drillGallery'), trayEl = $('drillTray'), cntEl = $('drillCount');
  const hInp = $('drillHints'), bInp = $('drillBlind');

  /* Случай храним как {mode,label}: индексы в DATA пересобираются при каждом запуске,
     а подпись случая стабильна — набор переживает перезапуск. */
  const entryOf = p => (E.DATA[p.mode] || []).find(e => e.label === p.label) || null;
  const isPicked = (mode, label) => S.picked.some(p => p.mode === mode && p.label === label);
  const diagram = e => e ? E.caseDiagram(e.states[0], e.mode) : '';

  /* ---------- экран 1: набор ---------- */
  let tab = 'f2l', warn = '', knownRefresh = null;

  function renderTabs() {
    tabsEl.innerHTML = TABDEF.map(([k, n]) =>
      `<button class="tab ${k === tab ? 'on' : ''}" data-k="${k}">${n}<span class="cnt">${(E.DATA[k] || []).length}</span></button>`).join('');
  }
  function renderGallery() {
    const arr = E.DATA[tab] || [];
    let html = '', lastGrp = null;
    arr.forEach((e, i) => {
      if (e.grp && e.grp !== lastGrp) { html += `<div class="ghead">${e.grp}</div>`; lastGrp = e.grp; }
      html += `<button class="gcard${isPicked(tab, e.label) ? ' pick' : ''}" data-i="${i}" data-l="${e.label}">` +
        `<div class="thumb">${diagram(e)}</div><div class="lab">${e.label}</div><div class="mc">${e.mc} ход.</div></button>`;
    });
    galEl.innerHTML = html;
    if (knownRefresh) knownRefresh();
  }
  function renderTray() {
    trayEl.innerHTML = S.picked.length
      ? S.picked.map((p, k) => {
          const e = entryOf(p);
          return `<div class="dchip">${diagram(e)}<span class="dchip-lab">${p.label}</span>` +
            `<span class="dchip-mode">${p.mode.toUpperCase()}</span>` +
            `<button class="dchip-x" data-k="${k}" title="Убрать из набора">✕</button></div>`;
        }).join('')
      : `<p class="dhint${warn ? ' warn' : ''}">${warn || 'Пока пусто — выбери случаи ниже.'}</p>`;
    if (S.picked.length && warn) trayEl.insertAdjacentHTML('beforeend', `<p class="dhint warn">${warn}</p>`);
    cntEl.textContent = `${S.picked.length} / ${MAX}`;
    $('drillStart').disabled = !S.picked.length;
  }
  /* галерею целиком не пересобираем на каждый клик — только метки выбранного */
  function markGallery() {
    galEl.querySelectorAll('.gcard').forEach(b => {
      const e = (E.DATA[tab] || [])[Number(b.dataset.i)];
      b.classList.toggle('pick', !!e && isPicked(tab, e.label));
    });
  }
  function renderSetup() { renderTabs(); renderGallery(); renderTray(); }
  /* «Знаю» — общий с галереей схем список выученных случаев (known.js) */
  if (window.Known) knownRefresh = window.Known.attach($('drillKnownBar'), galEl, () => tab, () => (E.DATA[tab] || []).length);

  function toggleCase(mode, label) {
    const k = S.picked.findIndex(p => p.mode === mode && p.label === label);
    if (k >= 0) { S.picked.splice(k, 1); warn = ''; }
    else if (S.picked.length >= MAX) { warn = `Больше ${MAX} случаев за подход не берём — так не зубрится. Убери лишний.`; }
    else { S.picked.push({ mode, label }); warn = ''; }
    save(); renderTray(); markGallery();
  }

  tabsEl.addEventListener('click', ev => {
    const b = ev.target.closest('.tab'); if (!b) return;
    tab = b.dataset.k; renderTabs(); renderGallery();
  });
  galEl.addEventListener('click', ev => {
    const b = ev.target.closest('.gcard'); if (!b) return;
    const e = (E.DATA[tab] || [])[Number(b.dataset.i)]; if (!e) return;
    toggleCase(tab, e.label);
  });
  trayEl.addEventListener('click', ev => {
    const b = ev.target.closest('.dchip-x'); if (!b) return;
    S.picked.splice(Number(b.dataset.k), 1); warn = ''; save(); renderTray(); markGallery();
  });
  $('drillWipe').addEventListener('click', () => { S.picked = []; warn = ''; save(); renderTray(); markGallery(); });

  function syncNums() { hInp.value = S.hints; bInp.value = S.blind; }
  view.querySelectorAll('.pm').forEach(b => b.addEventListener('click', () => {
    const f = b.dataset.f;
    S[f] = clamp(S[f] + Number(b.dataset.d), f === 'hints' ? 1 : 0, 99);
    save(); syncNums();
  }));
  hInp.addEventListener('change', () => { S.hints = clamp(hInp.value, 1, 99); save(); syncNums(); });
  bInp.addEventListener('change', () => { S.blind = clamp(bInp.value, 0, 99); save(); syncNums(); });

  const freshRun = () => ({ i: 0, phase: 'hint', reps: S.picked.map(() => ({ hint: 0, blind: 0, peek: 0 })), t0: Date.now() });
  $('drillStart').addEventListener('click', () => {
    if (!S.picked.length) return;
    S.run = freshRun(); save(); showRun();
  });

  /* ---------- экран 2: прогон ---------- */
  let mounted = null, peekT = 0;

  function runSkeleton() {
    runEl.innerHTML =
      `<div class="dpills" id="drillPills"></div>
       <div id="drillBody"></div>
       <div class="dbar">
         <div class="dcnt"><b class="dbig" id="drillNum">0 / 0</b><span id="drillPhase"></span></div>
         <div class="dprog"><i id="drillProg"></i></div>
         <button class="act drep" id="drillRep">Сделал ✓</button>
         <button class="act ghost" id="drillPeek" hidden>Подсмотреть</button>
         <button class="act ghost" id="drillUndo" title="Отменить лишний повтор">−1</button>
         <button class="act ghost" id="drillSkip" title="Перейти к следующему случаю">Дальше ▸</button>
         <button class="act ghost" id="drillStop">Закончить</button>
         <p class="dkey"><kbd>Пробел</kbd> — засчитать повтор · <kbd>H</kbd> — подсмотреть ходы · <kbd>Backspace</kbd> — минус повтор</p>
         <div class="dcube" id="drillCube"></div>
       </div>`;
    $('drillRep').addEventListener('click', rep);
    $('drillPeek').addEventListener('click', peek);
    $('drillUndo').addEventListener('click', undo);
    $('drillSkip').addEventListener('click', () => { nextCase(); save(); if (S.run) renderRun(); rebase(); });
    $('drillStop').addEventListener('click', finish);
    runEl.addEventListener('click', ev => {
      const b = ev.target.closest('button'); if (!b) return;
      if (b.id === 'drillConnect') {
        cube.status = 'ищу кубик по Bluetooth…'; cube.err = false; renderCube();
        window.SmartCube.connect().catch(() => {});
      } else if (b.id === 'drillAuto') {
        S.auto = !S.auto; save();
        if (S.auto) renderCube(); else disarm();
      } else if (b.id === 'drillArm') { if (cube.armed) disarm(); else arm(); }
      else if (b.id === 'drillRebase') rebase();
    });
  }

  /* Раскладка показа: solveHTML отдаёт [картинка случая + 3D] и отдельно ленту ходов.
     В зубрилке порядок другой — слева случай и ходы под ним, 3D-куб уезжает в центр.
     Переставляем узлы до mountPlayers: плеер меряет свой контейнер при монтаже, а
     подсветку карточек он ищет через .solve — поэтому всё остаётся внутри .solve. */
  function relayoutSolve(root) {
    const solve = root.querySelector('.solve');
    if (!solve) return;
    const side = solve.querySelector('.side3d'), strip = solve.querySelector('.strip'), p3d = solve.querySelector('.p3d');
    if (!side || !strip || !p3d) return;
    const wrap = document.createElement('div');
    wrap.className = 'd3dwrap';
    wrap.appendChild(p3d);
    side.appendChild(strip);
    solve.appendChild(wrap);
  }

  function showRun() {
    if (!runEl.firstChild) runSkeleton();
    mounted = null;
    setupEl.hidden = true; doneEl.hidden = true; runEl.hidden = false;
    renderRun(); rebase();
  }
  function showSetup() {
    setupEl.hidden = false; runEl.hidden = true; doneEl.hidden = true;
    renderSetup(); syncNums();
  }

  function renderRun() {
    const r = S.run; if (!r) { showSetup(); return; }
    const p = S.picked[r.i], e = p && entryOf(p);
    if (!e) { nextCase(); save(); if (S.run) renderRun(); return; }
    const c = r.reps[r.i];

    $('drillPills').innerHTML = S.picked.map((q, k) => {
      const rr = r.reps[k] || { hint: 0, blind: 0 };
      const st = k < r.i ? ' ok' : (k === r.i ? ' on' : '');
      return `<div class="dpill${st}">${diagram(entryOf(q))}<span>${q.label}</span>` +
        `<span class="dp-n">${rr.hint + rr.blind}/${S.hints + S.blind}${k < r.i ? ' ✓' : ''}</span></div>`;
    }).join('');

    const key = r.i + ':' + r.phase;
    if (key !== mounted) {
      const body = $('drillBody');
      if (r.phase === 'hint') {
        body.innerHTML =
          `<div class="dphase"><span class="tag">По схеме</span>` +
          `<span>Повторяй ходы с картинок — <b>${S.hints} раз подряд</b>. Кубик собирать не надо, важна рука.</span></div>` +
          `<div class="dsolve">` + E.solveHTML(e.states, e.moves, e.eff, e.mode, e.label) + `</div>`;
        relayoutSolve(body);
        E.mountPlayers(body);
      } else {
        body.innerHTML =
          `<div class="dphase"><span class="tag blind">По памяти</span>` +
          `<span>Ходы спрятаны. Смотри на случай и делай <b>${S.blind} раз</b> сам.</span></div>` +
          `<div class="dblind"><div class="casebox">${diagram(e)}<div class="clabel">${e.label}</div></div>` +
          `<div class="dblind-txt"><h3>${e.label}</h3>` +
          `<p>${E.caseDesc(e.states[0], e.mode)}</p>` +
          `<div class="dsecret hid" id="drillSecret">• • • • •</div></div></div>`;
      }
      mounted = key;
    }
    $('drillPeek').hidden = r.phase !== 'blind';

    const cur = r.phase === 'hint' ? c.hint : c.blind;
    const tot = r.phase === 'hint' ? S.hints : S.blind;
    $('drillNum').textContent = `${cur} / ${tot}`;
    $('drillPhase').textContent = r.phase === 'hint'
      ? `${e.label} · по схеме`
      : `${e.label} · по памяти${c.peek ? ` · подсмотрел ${c.peek}` : ''}`;
    $('drillProg').style.width = (tot ? Math.min(1, cur / tot) * 100 : 100) + '%';
    renderCube();
  }

  /* повтор засчитан: в фазе «по схеме» перематываем 3D в начало и запускаем заново —
     показ идёт в такт с руками. Плеер сам держит паузу на стартовой позиции, чтобы
     было видно, где кончился прошлый повтор и начался следующий. */
  function replay() {
    const box = runEl.querySelector('.p3d');
    const p = box && box.__player;
    if (!p) return;
    if (p.replay) p.replay(); else { p.rewind(); p.play(); }
  }
  function flash() {
    const b = $('drillRep'); if (!b) return;
    b.classList.add('hit'); setTimeout(() => b.classList.remove('hit'), 120);
  }
  function rep() {
    const r = S.run; if (!r) return;
    const c = r.reps[r.i];
    if (r.phase === 'hint') {
      c.hint++;
      if (c.hint >= S.hints) { if (S.blind > 0) r.phase = 'blind'; else nextCase(); }
      else replay();
    } else {
      c.blind++;
      if (c.blind >= S.blind) nextCase();
    }
    save(); if (S.run) renderRun(); flash(); rebase();
  }
  function undo() {
    const r = S.run; if (!r) return;
    const c = r.reps[r.i];
    if (r.phase === 'blind') {
      if (c.blind > 0) c.blind--;
      else { r.phase = 'hint'; c.hint = Math.max(0, S.hints - 1); }
    } else if (c.hint > 0) c.hint--;
    else if (r.i > 0) {
      /* промахнулся ровно на стыке случаев — возвращаемся к предыдущему */
      r.i--;
      const prev = r.reps[r.i];
      if (S.blind > 0) { r.phase = 'blind'; prev.blind = Math.max(0, S.blind - 1); }
      else { r.phase = 'hint'; prev.hint = Math.max(0, S.hints - 1); }
    }
    save(); renderRun(); rebase();
  }
  function nextCase() {
    const r = S.run;
    r.i++; r.phase = 'hint';
    if (r.i >= S.picked.length) finish();
  }
  function peek() {
    const r = S.run; if (!r || r.phase !== 'blind') return;
    const el = $('drillSecret'); if (!el) return;
    const e = entryOf(S.picked[r.i]); if (!e) return;
    r.reps[r.i].peek++; save();
    el.textContent = e.eff.replace(/'/g, '′');
    el.classList.remove('hid');
    clearTimeout(peekT);
    peekT = setTimeout(() => { el.textContent = '• • • • •'; el.classList.add('hid'); }, PEEK_MS);
    renderRun();
  }

  /* ---------- экран 3: итог ---------- */
  function finish() {
    const r = S.run; if (!r) { showSetup(); return; }
    S.last = { picked: S.picked.slice(), reps: r.reps, hints: S.hints, blind: S.blind, ms: Date.now() - r.t0 };
    S.run = null; save();
    renderDone();
    setupEl.hidden = true; runEl.hidden = true; doneEl.hidden = false;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  const mmss = ms => {
    const s = Math.max(0, Math.round(ms / 1000));
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  };
  function renderDone() {
    const L = S.last; if (!L) { showSetup(); return; }
    const tot = L.reps.reduce((a, c) => a + c.hint + c.blind, 0);
    const peeks = L.reps.reduce((a, c) => a + c.peek, 0);
    const rows = L.picked.map((p, k) => {
      const c = L.reps[k] || { hint: 0, blind: 0, peek: 0 };
      const full = c.hint >= L.hints && c.blind >= L.blind;
      return `<div class="drow">${diagram(entryOf(p))}<span class="dr-lab">${full ? '✓ ' : ''}${p.label}</span>` +
        `<span class="dr-num">по схеме <b>${c.hint}</b> · по памяти <b>${c.blind}</b>` +
        `${c.peek ? ` · подсмотрел <b>${c.peek}</b>` : ''}</span></div>`;
    }).join('');
    doneEl.innerHTML =
      `<div class="ddone"><h2>Подход закончен</h2>` +
      `<p class="sub">Всего повторов: <b>${tot}</b> за ${mmss(L.ms)}${peeks ? `, подсмотрел ${peeks} раз` : ', ни разу не подсмотрел'}.</p>` +
      `<div class="dstats">${rows}</div>` +
      `<div class="row"><button class="act" id="drillAgain">Ещё подход тем же набором</button>` +
      `<button class="act ghost" id="drillBack">Изменить набор</button></div></div>`;
    $('drillAgain').addEventListener('click', () => {
      S.run = freshRun(); save(); showRun(); window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    $('drillBack').addEventListener('click', showSetup);
  }

  /* ================= живой кубик: авто-зачёт повторов =================
     GAN-кубик отдаёт истинное состояние (facelets). Запоминаем состояние на старте
     повтора, считаем, во что его превратит алгоритм, и ждём совпадения — тогда повтор
     засчитывается сам, без кнопки. Сверяем с двумя послаблениями:
       · как ты держишь кубик — перебираем все 24 положения куба;
       · доворот верха перед алгоритмом (U / U2 / U') — обычное дело при зубрёжке.
     Поворот всего куба (y внутри алгоритма, перехват в руках) стикеры не меняет,
     поэтому живое состояние тоже сверяем во всех 24 разворотах. */
  const cube = { connected: false, status: '', err: false, fac: null, anchors: [], moves: 0, armed: false, note: '' };
  const SLACK = 6;   // запас ходов: перехваты, довороты, поправки перед самим алгоритмом
  const ROT_PRE = ['', 'x', 'x2', "x'", 'z', "z'"];
  const yMove = { eng: 'y', face: 'y' }, uMove = { eng: 'U', face: 'U' };

  function rotations(cs) {
    const out = [];
    for (const pre of ROT_PRE) {
      let a = E.clone(cs);
      if (pre) for (const m of E.parseAlg(pre)) E.applyMove(a, m);
      for (let k = 0; k < 4; k++) { out.push(a); const b = E.clone(a); E.applyMove(b, yMove); a = b; }
    }
    return out;
  }
  function targetsFor(cs0, alg) {
    const mv = E.parseAlg(alg), set = new Set();
    for (const r of rotations(cs0)) for (let auf = 0; auf < 4; auf++) {
      const st = E.clone(r);
      for (let k = 0; k < auf; k++) E.applyMove(st, uMove);
      for (const m of mv) E.applyMove(st, m);
      set.add(E.stateColors(st));
    }
    return set;
  }
  const toCubies = fac => (window.Coach && window.Coach.faceletsToCubies) ? window.Coach.faceletsToCubies(fac) : null;

  const curEntry = () => { const r = S.run; return (r && S.picked[r.i] && entryOf(S.picked[r.i])) || null; };
  /* Сколько ходов кубик реально отрапортует: U2 — две четверти, широкий/слайс — два слоя,
     повороты всего куба он не видит. По этой мерке и считаем «ходов N / need». */
  const qcache = new Map();
  function quarterCost(alg) {
    if (qcache.has(alg)) return qcache.get(alg);
    let n = 0;
    for (const m of E.parseAlg(alg)) {
      if (m.rot) continue;
      n += (m.wide || /[MES]/.test(m.face) ? 2 : 1) * (m.dbl ? 2 : 1);
    }
    qcache.set(alg, n); return n;
  }
  const needOf = e => e ? quarterCost(e.eff) : 0;

  /* ---------- окно точек отсчёта ----------
     Раньше точка отсчёта была одна — состояние на старте повтора. Стоило разок
     довернуть кубик мимо алгоритма (перехват, откат, поправка), и она уезжала:
     совпадение больше не наступало никогда, и зачёт молча умирал до «Сбросить отсчёт».
     Теперь помним несколько последних состояний и ждём совпадения с любым из них
     плюс алгоритм. Повтор засчитывается, откуда бы ты его ни начал, а лишние
     довороты перед ним просто выпадают из окна. */
  function pushAnchor() {
    const e = curEntry();
    if (!e || !cube.armed || !cube.fac) return;
    let cs = null;
    try { cs = toCubies(cube.fac); } catch (err) { return; }
    if (!cs) return;
    cube.anchors.push(targetsFor(cs, e.eff));
    const cap = needOf(e) + SLACK + 1;
    while (cube.anchors.length > cap) cube.anchors.shift();
  }
  /* отсчёт с нуля: окно чистим и ставим текущее положение единственной точкой */
  function rebase(note) {
    cube.moves = 0; cube.note = note || ''; cube.anchors = [];
    pushAnchor();
    renderCube();
  }

  function arm()   { cube.armed = true;  rebase(); }
  function disarm(){ cube.armed = false; cube.anchors = []; cube.moves = 0; cube.note = ''; renderCube(); }

  function renderCube() {
    const el = $('drillCube'); if (!el) return;
    const SC = window.SmartCube;
    if (!SC || !SC.bluetoothAvailable()) {
      el.className = 'dcube';
      el.innerHTML = '<span class="dot"></span><span>Bluetooth недоступен — повторы отмечай кнопкой.</span>';
      return;
    }
    if (!cube.connected) {
      el.className = 'dcube' + (cube.err ? ' err' : '');
      el.innerHTML = '<span class="dot"></span>' +
        `<span>${cube.status || 'Кубик не подключён — повторы считаешь сам.'}</span>` +
        '<button class="mini" id="drillConnect">Подключить кубик</button>';
      return;
    }
    const e = curEntry(), need = needOf(e);
    const live = S.auto && cube.armed;
    el.className = 'dcube on' + (live ? ' live' : '');
    /* Пока не нажали «Начать» — ходы не считаем вовсе: точка отсчёта берётся
       в момент нажатия, иначе она уедет от любого лишнего доворота в руках. */
    const txt = !S.auto
      ? 'авто-зачёт выключен — повторы отмечай кнопкой'
      : !cube.armed
        ? 'нажми <b>«Начать отсчёт»</b>, когда возьмёшь кубик — и крути алгоритм'
        : (cube.note || (cube.moves ? 'вижу ходы — досчитаю алгоритм до конца' : 'жду первый ход'));
    el.innerHTML = '<span class="dot"></span>' +
      `<span><b>Кубик на связи</b> — ${txt}</span>` +
      (live ? `<span class="cnt">ходов: ${cube.moves}${need ? ' / ' + need : ''}</span>` : '') +
      '<span class="gap"></span>' +
      (S.auto
        ? (cube.armed
            ? '<button class="mini" id="drillRebase">⟲ Сбросить отсчёт</button><button class="mini" id="drillArm">Стоп</button>'
            : '<button class="mini go" id="drillArm">▶ Начать отсчёт</button>')
        : '') +
      `<button class="mini${S.auto ? ' on' : ''}" id="drillAuto">Авто-зачёт: ${S.auto ? 'вкл' : 'выкл'}</button>`;
  }

  function autoHit() {
    const bar = runEl.querySelector('.dbar');
    if (bar) { bar.classList.add('matched'); setTimeout(() => bar.classList.remove('matched'), 450); }
    rep();
  }

  /* уведомления от smartcube-ui.js (те же, что получает ассистент сборки) */
  window.Drill = {
    onConnection(on) {
      cube.connected = !!on; cube.err = false;
      cube.status = on ? '' : 'Кубик отключён — повторы считаешь сам.';
      if (on) rebase(); else { cube.armed = false; cube.anchors = []; cube.moves = 0; cube.note = ''; }
      renderCube();
    },
    onStatus(st) {
      if (!st) return;
      if (st.state === 'connecting') { cube.status = 'Ищу кубик по Bluetooth…'; cube.err = false; }
      else if (st.state === 'need-mac') { cube.status = 'Нужен MAC кубика — введи его в разделе «Сборка».'; cube.err = true; }
      else if (st.state === 'error') { cube.status = 'Подключиться не вышло — попробуй в разделе «Сборка».'; cube.err = true; }
      if (!cube.connected) renderCube();
    },
    onMove() {
      if (!cube.connected || !cube.armed || !S.run || view.hidden || runEl.hidden) return;
      cube.moves++; cube.note = ''; renderCube();
    },
    /* для отладки из консоли: что модуль сейчас знает про кубик */
    _dbg: () => ({ connected: cube.connected, armed: cube.armed, anchors: cube.anchors.length, moves: cube.moves, note: cube.note, fac: cube.fac ? cube.fac.slice(0, 9) : null, auto: S.auto, running: !!S.run }),
    onState(fac) {
      if (!fac || fac.length < 54 || fac === cube.fac) return;
      cube.fac = fac;
      if (!S.auto || !cube.armed || !S.run || view.hidden || runEl.hidden) return;
      let cs = null;
      try { cs = toCubies(fac); } catch (e) { return; }
      if (!cs) return;
      const keys = rotations(cs).map(E.stateColors);
      if (cube.anchors.some(t => keys.some(k => t.has(k)))) { autoHit(); return; }
      pushAnchor();      // текущее положение — тоже возможный старт следующего повтора
      const need = needOf(curEntry());
      if (need && cube.moves > need + SLACK) cube.note = 'алгоритм пока не узнал — сделай его целиком, поймаю';
      renderCube();
    }
  };

  /* ---------- горячие клавиши ---------- */
  document.addEventListener('keydown', ev => {
    if (view.hidden || runEl.hidden || !S.run) return;
    const t = ev.target;
    if (t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable)) return;
    if (ev.ctrlKey || ev.altKey || ev.metaKey) return;
    if (ev.code === 'Space' || ev.code === 'Enter' || ev.code === 'NumpadEnter') { ev.preventDefault(); rep(); }
    else if (ev.code === 'KeyH') { ev.preventDefault(); peek(); }
    else if (ev.code === 'Backspace') { ev.preventDefault(); undo(); }
  });

  /* ---------- вход в раздел ---------- */
  let inited = false;
  function open() {
    if (!inited) { inited = true; syncNums(); renderSetup(); }
    if (cube.armed) rebase();   // пока сидели в другом разделе, кубик могли крутить
    if (S.run && S.picked.length) showRun();
    else if (runEl.hidden && doneEl.hidden) showSetup();
  }
  const nav = document.getElementById('topnav');
  if (nav) nav.addEventListener('click', ev => {
    const b = ev.target.closest('.navtab');
    if (b && b.dataset.v === 'drill') open();
  });

  /* внешний вход: window.DrillNav('oll','OLL 21') — добавить случай и открыть режим */
  window.DrillNav = function (mode, label) {
    if (mode && label && !isPicked(mode, label) && S.picked.length < MAX) {
      S.picked.push({ mode, label }); save();
      if (inited) { renderTray(); markGallery(); }
    }
    const t = nav && [...nav.querySelectorAll('.navtab')].find(x => x.dataset.v === 'drill');
    if (t) t.click();
  };
})();
