"use strict";
/* Метка сборки в шапке: версия из package.json + время последней правки файлов приложения.
   Окно держит тот код, который был на диске в момент запуска, — по этой метке сразу видно,
   свежий ли он. В обычном браузере (без preload) метку просто не показываем. */
(function () {
  const el = document.getElementById('buildTag');
  const b = window.CG_BUILD;
  if (!el || !b) return;

  const d = new Date(b.at);
  const p2 = n => String(n).padStart(2, '0');
  const stamp = `${p2(d.getDate())}.${p2(d.getMonth() + 1)} ${p2(d.getHours())}:${p2(d.getMinutes())}`;

  el.textContent = `v${b.version} · ${stamp}`;
  el.title = `Сборка от ${d.toLocaleString('ru-RU')}` + (b.file ? `\nПоследним правился: ${b.file}` : '');
  el.hidden = false;
  // в приложении на телефоне: тап по версии — проверить обновления
  if (window.CG_CHECK_UPDATE) { el.style.cursor = 'pointer'; el.addEventListener('click', () => window.CG_CHECK_UPDATE()); }
})();
