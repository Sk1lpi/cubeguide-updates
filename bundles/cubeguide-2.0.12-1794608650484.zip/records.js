"use strict";
/* ===== Книжка рекордов =====
   Каждая сборка из таймера (session.js → Records.add) пишется сюда с датой. Новый
   личный рекорд (лучше всех прошлых) попадает в «Историю рекордов» — когда поставлен
   и на сколько побил прошлый. Плюс лучшие средние Ao5/Ao12 и топ-10 сборок.
   localStorage 'cg-records' = { solves:[{ms,at,mv}], pbs:[{ms,at,prev}] }.
   После каждого изменения шлём событие 'cg-records' — телефон передаёт сводку виджету. */
(function () {
  const KEY = 'cg-records', MAX_SOLVES = 1000;
  let S = { solves: [], pbs: [] };
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (raw && Array.isArray(raw.solves)) S = { solves: raw.solves, pbs: Array.isArray(raw.pbs) ? raw.pbs : [] };
  } catch (e) {}
  /* сборки до появления книжки: известно только лучшее время — без даты */
  if (!S.pbs.length) {
    try {
      const st = JSON.parse(localStorage.getItem('cg-solve-stats') || 'null');
      if (st && st.best != null) S.pbs.push({ ms: st.best, at: null, prev: null });
    } catch (e) {}
  }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
  const emit = () => window.dispatchEvent(new CustomEvent('cg-records'));

  const best = () => S.pbs.length ? S.pbs[S.pbs.length - 1].ms : null;
  /* Ao5/Ao12 по правилам WCA: без лучшей и худшей (Ao12 — тоже без одной лучшей и одной худшей) */
  function avg(list) {
    if (list.length < 3) return null;
    const a = list.map(s => s.ms).sort((x, y) => x - y).slice(1, -1);
    return a.reduce((p, c) => p + c, 0) / a.length;
  }
  function bestAvg(n) {
    let b = null;
    for (let i = n; i <= S.solves.length; i++) {
      const v = avg(S.solves.slice(i - n, i));
      if (v != null && (b == null || v < b.ms)) b = { ms: v, at: S.solves[i - 1].at };
    }
    return b;
  }
  const curAvg = n => S.solves.length >= n ? avg(S.solves.slice(-n)) : null;

  function add(ms, mv) {
    if (!(ms > 0)) return false;
    const at = Date.now();
    S.solves.push({ ms: Math.round(ms), at, mv: mv || 0 });
    if (S.solves.length > MAX_SOLVES) S.solves.splice(0, S.solves.length - MAX_SOLVES);
    const b = best(), pb = b == null || ms < b;
    if (pb) S.pbs.push({ ms: Math.round(ms), at, prev: b });
    save(); emit(); paint();
    return pb;
  }
  function removeSolve(at) {
    const k = S.solves.findIndex(s => s.at === at);
    if (k < 0) return;
    S.solves.splice(k, 1);
    /* рекорд, поставленный этой сборкой, тоже убираем — «История» должна быть честной */
    const p = S.pbs.findIndex(x => x.at === at);
    if (p >= 0) S.pbs.splice(p, 1);
    save(); emit(); paint();
  }

  /* ---------- вид ---------- */
  function fmt(ms) {
    if (ms == null) return '—';
    const t = Math.max(0, ms) / 1000, m = Math.floor(t / 60), s = t - m * 60;
    return m ? m + ':' + s.toFixed(3).padStart(6, '0') : s.toFixed(3);
  }
  const MON = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  function when(at, short) {
    if (!at) return 'до книжки';
    const d = new Date(at), now = new Date();
    const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    const day = new Date(now.getFullYear(), now.getMonth(), now.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const dd = day === 0 ? 'сегодня' : day === 864e5 ? 'вчера' : d.getDate() + ' ' + MON[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ' ' + d.getFullYear() : '');
    return short ? dd : dd + ', ' + hm;
  }

  let el = null;
  function paint() {
    if (!el) el = document.getElementById('recBook');
    if (!el) return;
    const b = best(), a5 = bestAvg(5), a12 = bestAvg(12);
    const tiles = [
      ['Рекорд', b, S.pbs.length ? when(S.pbs[S.pbs.length - 1].at) : ''],
      ['Лучшее Ao5', a5 && a5.ms, a5 ? when(a5.at) : 'нужно 5 сборок'],
      ['Лучшее Ao12', a12 && a12.ms, a12 ? when(a12.at) : 'нужно 12 сборок'],
      ['Сейчас Ao5', curAvg(5), S.solves.length + ' сборок всего']
    ].map(([n, v, sub]) => `<div class="rb-tile"><span>${n}</span><b>${fmt(v)}</b><i>${sub}</i></div>`).join('');

    const hist = S.pbs.slice().reverse().map((p, k) => {
      const gain = p.prev != null ? `<span class="rb-gain">−${((p.prev - p.ms) / 1000).toFixed(2)} с</span>` : '<span class="rb-gain first">первый</span>';
      return `<li${k === 0 ? ' class="top"' : ''}><b>${fmt(p.ms)}</b>${gain}<span class="rb-when">${when(p.at)}</span></li>`;
    }).join('');

    const top = S.solves.slice().sort((x, y) => x.ms - y.ms).slice(0, 10).map((s, k) =>
      `<li><span class="rb-n">${k + 1}</span><b>${fmt(s.ms)}</b>${s.mv ? `<span class="rb-mv">${s.mv} ход.</span>` : ''}<span class="rb-when">${when(s.at)}</span>` +
      `<button class="rb-x" data-at="${s.at}" title="Удалить эту сборку (например, ошибочную)">✕</button></li>`).join('');

    el.innerHTML =
      `<div class="rb-tiles">${tiles}</div>` +
      `<div class="rb-cols">` +
        `<div class="rb-col"><h4>История рекордов</h4>${hist ? `<ol class="rb-list rb-pbs">${hist}</ol>` : '<p class="rb-empty">Собери кубик на таймере — первый рекорд появится здесь.</p>'}</div>` +
        `<div class="rb-col"><h4>Топ-10 сборок</h4>${top ? `<ol class="rb-list rb-top">${top}</ol>` : '<p class="rb-empty">Пока ни одной сборки с датой.</p>'}</div>` +
      `</div>`;
  }
  document.addEventListener('click', ev => {
    const x = ev.target.closest && ev.target.closest('#recBook .rb-x');
    if (!x) return;
    if (confirm('Удалить эту сборку из книжки?')) removeSolve(Number(x.dataset.at));
  });

  /* сводка для виджета: последние рекорды с датами */
  function summary() {
    return {
      best: best(),
      ao5: curAvg(5),
      count: S.solves.length,
      pbs: S.pbs.slice(-4).reverse().map(p => ({ ms: p.ms, at: p.at, t: fmt(p.ms), d: when(p.at, true) }))
    };
  }

  window.Records = { add, best, summary, fmt, paint };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', paint); else paint();
})();
