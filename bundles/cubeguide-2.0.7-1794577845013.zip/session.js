"use strict";
/* ===== Сессия «разобрал → собрал» с таймером =====
   Всё идёт само, кнопки нужны только чтобы поправить:
     1. крутишь собранный кубик — приложение само переходит в «Мешай кубик» и даёт скрамбл;
     2. намешал (или прошёл скрамбл до конца) — появляется «▶ Начать»: таймер выезжает
        крупно на центр экрана;
     3. отсчёт — в одном из двух режимов (переключатель в шапке раздела):
          · «Пробел» — пробел запускает, пробел останавливает (как обычный таймер);
          · «Ходы»   — время идёт от первого хода до собранного кубика (все 54 наклейки);
     4. собрал — результат на экране; покрутил кубик — снова «Мешай кубик».
   Подсказки ассистента при этом не гасим ни на одном шаге — он живёт своей жизнью. */
(function () {
  const $ = id => document.getElementById(id);
  const F = window.Facelet;
  const elMix = $('sessScramble'), elGo = $('sessSolve');
  const elTime = $('sessTime'), elPhase = $('sessPhase'), elStats = $('sessStats'), elPane = $('sessPane');
  const elPanel = $('sessPanel'), elSeq = $('sessSeq'), elBar = $('sessMixBar'), elMixN = $('sessMixN'), elNewMix = $('sessNewMix');
  const elStepN = $('sessStepN'), elStart = $('sessStart'), elModeSeg = $('sessMode');
  const elOver = $('sessOver'), elOTime = $('sessOverTime'), elOPhase = $('sessOverPhase'),
        elOStats = $('sessOverStats'), elOMode = $('sessOverMode'), elOX = $('sessOverX');
  const elOCoach = $('sessOverCoach');
  const elReview = $('sessReview'), elLastRev = $('sessLastReview'), elLastRevBody = $('sessLastReviewBody');
  /* Блок ассистента (цепочка этапов крест → F2L → OLL → PLL и текущая схема) на время
     таймера переносим под цифры, а потом возвращаем на место. Coach ищет его по id,
     так что подсказки продолжают обновляться вживую. */
  const coachEl = document.querySelector('.coachbody');
  const coachHome = coachEl && coachEl.parentNode, coachNext = coachEl && coachEl.nextSibling;
  /* живой 3D-кубик тоже переезжает в таймер (тот же canvas — вращение и ходы не прерываются) */
  const cube3dEl = $('scCube3D'), elO3D = $('sessOver3D');
  const cube3dHome = cube3dEl && cube3dEl.parentNode, cube3dNext = cube3dEl && cube3dEl.nextSibling;
  function placeCube3D(inOverlay) {
    if (!cube3dEl || !elO3D) return;
    const want = inOverlay ? elO3D : cube3dHome;
    if (cube3dEl.parentNode === want) return;
    if (inOverlay) elO3D.appendChild(cube3dEl); else cube3dHome.insertBefore(cube3dEl, cube3dNext);
    requestAnimationFrame(() => { if (window.Cube3D && Cube3D.resize) Cube3D.resize(); });
  }
  function placeCoach(inOverlay) {
    if (!coachEl || !elOCoach) return;
    if (inOverlay && coachEl.parentNode !== elOCoach) elOCoach.appendChild(coachEl);
    else if (!inOverlay && coachEl.parentNode !== coachHome) coachHome.insertBefore(coachEl, coachNext);
  }
  const elView = $('view-assemble');
  const E = window.CubeEngine;   // движок схем: те же карточки со стрелками, что и в разделе «Схемы»
  if (!F || !elGo || !elTime) return;

  /* ---------- состояние кубика ---------- */
  const CENTER = { 4: 1, 13: 1, 22: 1, 31: 1, 40: 1, 49: 1 };
  const isSolved = fac => fac === F.SOLVED;
  function mixedCount(fac) {          // сколько подвижных наклеек не на своём месте (0..48)
    if (!fac || fac.length < 54) return 0;
    let n = 0;
    for (let i = 0; i < 54; i++) if (!CENTER[i] && fac[i] !== F.SOLVED[i]) n++;
    return n;
  }
  const MIX_OK = 30;                  // с какого «разобранности» считаем, что намешано достаточно

  /* ---------- режим отсчёта ---------- */
  const MODE_KEY = 'cg-solve-mode';
  let mode = 'move';                  // 'space' · 'move'
  try { const m = localStorage.getItem(MODE_KEY); if (m === 'space' || m === 'move') mode = m; } catch (e) {}
  function setMode(m) {
    if (m !== 'space' && m !== 'move') return;
    if (phase === 'run') return;      // посреди сборки режим не меняем
    mode = m;
    try { localStorage.setItem(MODE_KEY, m); } catch (e) {}
    paint();
  }

  /* ---------- скрамбл-подсказка ----------
     Не обязателен: мешать можно как угодно. Но если крутить по нему, видно, где ты. */
  const FACES = ['U', 'D', 'L', 'R', 'F', 'B'], OPP = { U: 'D', D: 'U', L: 'R', R: 'L', F: 'B', B: 'F' };
  function genScramble(n) {
    const out = []; let p1 = '', p2 = '';
    while (out.length < n) {
      const f = FACES[Math.random() * 6 | 0];
      if (f === p1) continue;                    // подряд одну грань не крутим
      if (f === OPP[p1] && f === p2) continue;   // и не возвращаемся к R L R
      out.push(f + ["", "'", "2"][Math.random() * 3 | 0]);
      p2 = p1; p1 = f;
    }
    return out;
  }
  // кубик рапортует только четверти: U2 — это два хода, поэтому ждём грань дважды
  function expand(tokens) {
    const steps = [];
    tokens.forEach((t, i) => {
      const q = /2/.test(t) ? 2 : 1;
      for (let k = 0; k < q; k++) steps.push({ tok: i, face: t[0], any: q === 2, prime: /'/.test(t) });
    });
    return steps;
  }

  /* Рисуем скрамбл карточками со стрелками (как в «Схемах»), а не голой нотацией. */
  function buildSeq() {
    if (!elSeq) return;
    if (!E || !E.moveCard) {
      elSeq.innerHTML = tokens.map(t => `<span>${t.replace("'", '′')}</span>`).join('');
      return;
    }
    let cs = E.solvedCube(), html = '';
    tokens.forEach((t, i) => {
      const mv = E.parseAlg(t)[0];
      if (!mv) return;
      html += E.moveCard(cs, mv, i + 1);
      cs = E.clone(cs); E.applyMove(cs, mv);
    });
    elSeq.innerHTML = html;
  }
  function newScramble() { armWhenStateLands = false; tokens = genScramble(20); steps = expand(tokens); si = 0; buildSeq(); }

  /* ---------- статистика между сессиями ---------- */
  const KEY = 'cg-solve-stats';
  let stats = { best: null, last: null, count: 0 };
  try { const s = JSON.parse(localStorage.getItem(KEY) || 'null'); if (s && typeof s === 'object') stats = Object.assign(stats, s); } catch (e) {}
  function saveStats() { try { localStorage.setItem(KEY, JSON.stringify(stats)); } catch (e) {} }

  function fmt(ms) {
    if (ms == null) return '—';
    const t = Math.max(0, ms) / 1000, m = Math.floor(t / 60), s = t - m * 60;
    return m ? m + ':' + s.toFixed(3).padStart(6, '0') : s.toFixed(3);
  }

  /* ---------- состояние сессии ---------- */
  let phase = 'off';        // off · idle · mix · armed · run · done
  let connected = false;
  let fac = F.SOLVED;
  let tokens = [], steps = [], si = 0;   // скрамбл и позиция в нём
  let t0 = 0, lastMoveAt = 0, result = null, moves = 0;
  let overlay = false;                  // крупный таймер на весь экран
  let armWhenStateLands = false;        // скрамбл пройден — откроем таймер, как придёт состояние
  let holding = false;
  let rec = null;                       // запись сборки для разбора: старт + ходы с метками
  let reviewHTML = '';                  // пробел зажат в «Готов» — старт будет на отпускании
  let dbg = null;
  let clock = 0;

  function setTime(txt) { elTime.textContent = txt; if (elOTime) elOTime.textContent = txt; }

  /* Тикаем по интервалу, а не по кадрам: requestAnimationFrame замирает, когда окно
     перекрыто, и время на экране вставало бы на паузу. Измерение — по меткам событий. */
  let statTick = 0;
  function tick() {
    if (phase !== 'run') return;
    setTime(fmt(performance.now() - t0));
    if (++statTick % 8 === 0) { const h = statsHTML(); elStats.innerHTML = h; if (elOStats) elOStats.innerHTML = h; }
  }
  function runClock() { stopClock(); statTick = 0; tick(); clock = setInterval(tick, 40); }
  function stopClock() { if (clock) clearInterval(clock); clock = 0; }

  /* ---------- отрисовка ---------- */
  const TOUCH = !!(window.matchMedia && matchMedia('(hover: none) and (pointer: coarse)').matches);
  const tw = h => !TOUCH ? h : h
    .replace('Нажми и <b>отпусти пробел</b>', 'Коснись экрана и <b>отпусти</b>')
    .replace('<b>нажатие пробела</b> остановит', '<b>касание экрана</b> остановит')
    .replace('<b>пробел</b> запускает таймер', '<b>тап по таймеру</b> запускает')
    .replace('<b>«Начать»</b> или <b>пробел</b>', '<b>«Начать»</b>')
    .replace('Жми <b>пробел</b>', 'Коснись экрана')
    .replace('<b>Пробел</b> — следующая', '<b>Тап</b> — следующая')
    .replace('пробел → пробел', 'касание → касание');
  function phrase() { return tw(phrase0()); }
  function phrase0() {
    const sp = mode === 'space';
    switch (phase) {
      case 'off':   return sp ? 'Кубик не подключён — можно и так: <b>пробел</b> запускает таймер.'
                              : 'Подключи кубик — дальше просто крути его.';
      case 'idle':  return 'Кубик собран. Начни крутить — и я дам скрамбл.';
      case 'mix':   return mixedCount(fac) >= MIX_OK || si >= steps.length
                      ? 'Намешано. Жми <b>«Начать»</b> или <b>пробел</b>.'
                      : 'Мешай кубик — по скрамблу сверху или как угодно.';
      case 'armed': return sp ? (holding ? '<b>Отпусти</b> — пойдёт время.' : 'Готов. Нажми и <b>отпусти пробел</b> — старт.')
                              : 'Готов. Время пойдёт с <b>первого хода</b>.';
      case 'run':   return sp ? (connected && isSolved(fac) ? 'Собран! Жми <b>пробел</b>.' : 'Время идёт — <b>нажатие пробела</b> остановит.')
                              : 'Время идёт — встанет на собранном кубике.';
      case 'done':  return connected ? 'Готово! Покрути кубик — начнём следующую.' : 'Готово! <b>Пробел</b> — следующая.';
    }
    return '';
  }
  function statsHTML() {
    if (phase === 'run' || (phase === 'done' && result)) {
      const ms = phase === 'run' ? performance.now() - t0 : result.ms;
      const tps = ms > 300 && moves ? (moves / (ms / 1000)).toFixed(1) : '—';
      return (connected ? `ходов <b>${moves}</b><span>·</span>TPS <b>${tps}</b><span>·</span>` : '') +
             `лучшее <b>${fmt(stats.best)}</b>`;
    }
    return `лучшее <b>${fmt(stats.best)}</b><span>·</span>прошлая <b>${fmt(stats.last)}</b><span>·</span>сборок <b>${stats.count}</b>`;
  }
  function paintSeq() {
    if (!elSeq) return;
    const cur = si < steps.length ? steps[si].tok : tokens.length;
    const kids = elSeq.children;
    for (let i = 0; i < kids.length; i++) {
      kids[i].classList.toggle('done', i < cur);
      kids[i].classList.toggle('now', i === cur);
    }
    if (elStepN) elStepN.innerHTML = cur >= tokens.length
      ? 'скрамбл пройден'
      : `ход <b>${cur + 1}</b> из <b>${tokens.length}</b>`;
    const now = kids[cur];
    // листаем только саму полосу скрамбла по горизонтали — страница не должна прыгать к ней при каждом ходе
    if (now && elSeq.scrollWidth > elSeq.clientWidth) {
      const left = now.offsetLeft - (elSeq.clientWidth - now.offsetWidth) / 2;
      elSeq.scrollTo({ left: Math.max(0, left), behavior: 'smooth' });
    }
  }
  const canStart = () => phase === 'mix' ? (!connected || !isSolved(fac)) : (mode === 'space' && (phase === 'off' || phase === 'done' || phase === 'idle'));
  function paint() {
    const mix = mixedCount(fac), pct = Math.round(mix / 48 * 100);
    const cls = phase === 'run' ? ' run' : phase === 'armed' ? ' arm' : phase === 'done' ? ' done' : '';
    elMix.disabled = !connected;
    elGo.disabled = !canStart();
    elPane.className = 'pane pane-timer' + cls;
    elPhase.innerHTML = phrase();
    elStats.innerHTML = statsHTML();
    if (elModeSeg) elModeSeg.querySelectorAll('button').forEach(b => {
      b.classList.toggle('on', b.dataset.m === mode);
      b.disabled = phase === 'run';
    });
    if (elPanel) {
      elPanel.hidden = phase !== 'mix';
      if (phase === 'mix') {
        if (elBar) elBar.style.width = Math.min(100, Math.round(mix / 40 * 100)) + '%';
        if (elMixN) elMixN.innerHTML = isSolved(fac)
          ? 'кубик пока собран — покрути его'
          : `разобран на <b>${pct}%</b>` + (mix >= MIX_OK ? ' — годится' : ' — можно ещё помешать');
        if (elStart) {
          elStart.disabled = isSolved(fac);
          elStart.classList.toggle('ready', !isSolved(fac) && (mix >= MIX_OK || si >= steps.length));
        }
        paintSeq();
      }
    }
    if (!overlay) placeCoach(false);
    placeCube3D(overlay && connected);
    if (elOver) {
      elOver.hidden = !overlay;
      const showRev = phase === 'done' && !!reviewHTML;
      const withCoach = overlay && connected && !showRev;   // после финиша вместо «Собрано!» — разбор
      if (elReview) { elReview.hidden = !(overlay && showRev); if (overlay && showRev && elReview.dataset.v !== String(stats.count)) { elReview.innerHTML = reviewHTML; elReview.dataset.v = String(stats.count); } }
      placeCoach(withCoach);
      elOver.className = 'sess-over' + cls + (holding && phase === 'armed' ? ' hold' : '') + (withCoach || (overlay && showRev) ? ' coach' : '');
      if (overlay) {
        elOPhase.innerHTML = phrase();
        elOStats.innerHTML = statsHTML();
        elOMode.innerHTML = mode === 'space'
          ? tw('режим: <b>пробел → пробел</b>')
          : 'режим: <b>первый ход → собранный кубик</b>';
        elOX.textContent = TOUCH ? (phase === 'run' ? '✕ Отменить' : '✕ Закрыть') : (phase === 'run' ? 'Esc — отменить сборку' : 'Esc — закрыть');
      }
    }
  }

  /* ---------- переходы ---------- */
  function toMix() {
    stopClock(); overlay = false; phase = 'mix'; result = null; moves = 0; t0 = 0;
    newScramble();
    setTime('0.000');
    paint();
  }
  // «Начать»: таймер на центр экрана и ждём старта (пробела или первого хода)
  function toArmed() {
    if (!canStart()) return;
    stopClock(); phase = 'armed'; moves = 0; result = null; t0 = 0; overlay = true; holding = false;
    setTime('0.000');
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();  // иначе пробел «нажмёт» кнопку
    if (window.Coach && Coach.restart) Coach.restart();   // подсказку считаем от текущего кубика
    paint();
  }
  function start(ts, firstMove) {
    rec = { startFac: fac, moves: [], t0: ts, mode };
    holding = false; phase = 'run'; t0 = ts; moves = firstMove ? 1 : 0; lastMoveAt = ts;
    paint(); runClock();
  }
  function finish(endTs) {
    stopClock(); phase = 'done';
    const ms = Math.max(0, endTs - t0);
    result = { ms, moves };
    setTime(fmt(ms));
    stats.last = ms; stats.count++;
    if (stats.best == null || ms < stats.best) stats.best = ms;
    saveStats();
    reviewHTML = '';
    if (rec && rec.moves.length && window.Review) {
      rec.tEnd = endTs;
      try { reviewHTML = Review.html(Review.build(rec)); } catch (e) { console.error('review failed', e); }
    }
    if (elLastRev && elLastRevBody) { elLastRev.hidden = !reviewHTML; if (reviewHTML) elLastRevBody.innerHTML = reviewHTML; }
    paint();
  }
  function closeOverlay() {
    holding = false;
    if (phase === 'run' || phase === 'armed') {   // отмена: время не пишем
      stopClock(); phase = connected ? (isSolved(fac) ? 'idle' : 'mix') : 'off';
      result = null; moves = 0; t0 = 0; setTime('0.000');
      if (phase === 'mix' && !tokens.length) newScramble();
    }
    overlay = false; paint();
  }
  function reset(ph) {
    stopClock(); overlay = false; phase = ph; result = null; moves = 0; t0 = 0;
    setTime('0.000'); paint();
  }

  /* ---------- кнопки ---------- */
  elMix.addEventListener('click', toMix);
  elGo.addEventListener('click', toArmed);
  elStart && elStart.addEventListener('click', toArmed);
  elNewMix && elNewMix.addEventListener('click', () => { newScramble(); paint(); });
  elOX && elOX.addEventListener('click', closeOverlay);
  elModeSeg && elModeSeg.addEventListener('click', e => { const b = e.target.closest('button'); if (b) setMode(b.dataset.m); });

  /* ---------- пробел / Esc ---------- */
  function press(now) {
    if (phase === 'run') { if (mode === 'space') finish(now); return; }   // стоп — по нажатию
    if (phase === 'armed') { if (mode === 'space') { holding = true; paint(); } return; }   // старт — на отпускании
    if (phase === 'done' && overlay && mode === 'space') { toArmed(); return; }   // сразу к следующей
    if (phase === 'done' && overlay) { overlay = false; paint(); return; }
    if (canStart()) toArmed();
  }
  function release(now) {
    if (!holding) return;
    holding = false;
    if (phase === 'armed' && mode === 'space') start(now, false);
    else paint();
  }
  document.addEventListener('keydown', ev => {
    if (elView && elView.hidden) return;
    const t = ev.target;
    if (t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable)) return;
    if (ev.ctrlKey || ev.altKey || ev.metaKey) return;
    if (ev.code === 'Escape' && overlay) { closeOverlay(); return; }
    if (ev.code !== 'Space') return;
    ev.preventDefault();
    if (ev.repeat) return;
    press(performance.now());
  });

  // Старт в режиме «Пробел» — на отпускании, и только если сам пробел нажали уже в «Готов»:
  // так нажатие, которое открыло таймер или остановило прошлую сборку, ничего не запустит.
  document.addEventListener('keyup', ev => {
    if (ev.code !== 'Space' || !holding) return;
    ev.preventDefault();
    release(performance.now());
  });

  /* ---------- касание (телефон) ----------
     На телефоне пробела нет: палец на экране таймера = пробел. Пока идёт время или ждём
     старта — считается касание в любом месте; в остальное время — только по самим цифрам,
     чтобы можно было листать разбор и подсказку. */
  const tapZone = t => !t.closest('button, a, select, input, summary, details, .sess-over-coach');
  if (elOver) {
    elOver.addEventListener('pointerdown', ev => {
      if (ev.button > 0) return;
      const live = phase === 'run' || phase === 'armed';
      if (!live && !tapZone(ev.target)) return;
      if (live && ev.target.closest('.sess-over-x')) return;
      if (ev.pointerType !== 'mouse') ev.preventDefault();
      press(performance.now());
    });
    const up = () => release(performance.now());
    elOver.addEventListener('pointerup', up);
    elOver.addEventListener('pointercancel', () => { if (holding) { holding = false; paint(); } });
  }
  if (elPane) elPane.addEventListener('click', () => { if (!overlay && canStart()) toArmed(); });
  window.addEventListener('blur', () => { if (holding) { holding = false; paint(); } });

  /* ---------- события кубика (зовёт smartcube-ui) ---------- */
  window.Session = {
    _dbg: () => ({ phase, mode, si, token: tokens[steps[si] ? steps[si].tok : tokens.length - 1], lastMove: dbg }),
    setMode,
    onConnection(on) {
      connected = on;
      reset(on ? 'idle' : 'off');
    },
    onCalibrate() { if (connected) reset('idle'); },
    onMove(ev) {
      if (!ev || !ev.move) return;
      const ts = typeof ev.localTimestamp === 'number' ? ev.localTimestamp : performance.now();
      // часы самого кубика — для «скорости пальцев» в разборе (точнее, чем приход по Bluetooth)
      const hwTs = e => (typeof e.cubeTimestamp === 'number' ? e.cubeTimestamp : null);
      if (phase === 'armed') {                                   // старт по первому ходу
        if (mode === 'move') { start(ts, true); rec.moves.push({ m: ev.move, t: ts, hw: hwTs(ev) }); }
        return;
      }
      if (phase === 'run') {
        moves++; lastMoveAt = ts;
        // в режиме «Пробел» старт/стоп меряются по performance.now() — ходы туда же
        if (rec) rec.moves.push({ m: ev.move, t: mode === 'move' ? ts : performance.now(), hw: hwTs(ev) });
        return;
      }
      // собранный кубик начали крутить (или после сборки) — сами переходим к «Мешай кубик»
      if (phase === 'idle' || phase === 'done') toMix();
      if (phase === 'mix') {
        const mv = F.toView ? F.toView(ev.move) : ev.move;
        const st = steps[si];
        dbg = { raw: ev.move, view: mv, want: st ? st.face + (st.any ? '2' : st.prime ? "'" : '') : '—' };
        if (st && mv[0] === st.face && (st.any || /'/.test(mv) === st.prime)) {
          si++; paintSeq();
          if (si >= steps.length) armWhenStateLands = true;   // скрамбл пройден — дождёмся состояния и откроем таймер
        }
      }
    },
    onState(f) {
      if (!f || f.length < 54) return;
      const was = fac; fac = f;
      if (phase === 'run') {
        if (mode === 'move' && isSolved(f)) { finish(lastMoveAt); return; }
        if (mode === 'space' && f !== was) paint();   // «Собран! Жми пробел»
        return;
      }
      if (phase === 'mix' && armWhenStateLands) {
        armWhenStateLands = false;
        if (!isSolved(f)) { toArmed(); return; }
      }
      if (phase === 'mix' && f !== was) paint();
      else if (phase === 'idle' && was !== f) paint();
    }
  };
  reset('off');
})();
