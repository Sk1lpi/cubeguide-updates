"use strict";
/* ===== «Знаю» — отметка выученных случаев =====
   Случай, который уже помнишь, зачёркивается крестиком — и в схемах, и в Зубриле
   (общий список). Отметить: правый клик по случаю, либо включить режим «Знаю»
   (кнопка над галереей) и тыкать левым кликом, потом выключить.
   «Скрыть знакомые» убирает зачёркнутые из сетки совсем.
   Храним по подписи случая ({mode: [label,…]}) в localStorage 'cg-known' —
   подписи стабильны между запусками, индексы нет. */
(function () {
  const KEY = 'cg-known';
  let S = { marks: { f2l: [], oll: [], pll: [] }, hide: false };
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (raw && raw.marks) S = { marks: Object.assign(S.marks, raw.marks), hide: !!raw.hide };
  } catch (e) {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
  const emit = () => window.dispatchEvent(new CustomEvent('cg-known'));

  const touch = !!(window.matchMedia && matchMedia('(hover:none) and (pointer:coarse)').matches);
  let editMode = false;            // режим «Знаю»: левый клик зачёркивает (на время сеанса)

  const list = mode => (S.marks[mode] = S.marks[mode] || []);
  const has = (mode, label) => list(mode).includes(label);
  function toggle(mode, label) {
    const a = list(mode), k = a.indexOf(label);
    if (k >= 0) a.splice(k, 1); else a.push(label);
    save(); emit();
  }

  /* Панель над галереей: [✕ Знаю] · знаю N из M · [Скрыть знакомые]
     bar — контейнер, gallery — сетка, getMode/getTotal — текущая вкладка. */
  function attach(bar, gallery, getMode, getTotal) {
    function paint() {
      const mode = getMode(), n = list(mode).length, total = getTotal();
      bar.innerHTML =
        `<button class="kbtn${editMode ? ' on' : ''}" data-a="edit" title="Включи и тыкай случаи, которые уже помнишь. Правый клик работает всегда.">` +
          `<span class="kbox">${editMode ? '✓' : ''}</span>Знаю</button>` +
        `<span class="kcnt">знаю <b>${n}</b> из ${total}</span>` +
        `<button class="kbtn ghost${S.hide ? ' on' : ''}" data-a="hide"><span class="kbox">${S.hide ? '✓' : ''}</span>Скрыть знакомые</button>` +
        (editMode ? `<span class="khint">Тыкай случаи, которые уже помнишь — они зачеркнутся. Выключи «Знаю», когда закончишь.</span>`
                  : `<span class="khint">${touch ? 'Долгое нажатие на случай — «знаю». Список общий для «Схем» и «Зубрилы».' : 'Правый клик по случаю — «знаю». Список общий для «Схем» и «Зубрилы».'}</span>`);
      gallery.classList.toggle('kmode', editMode);
      gallery.classList.toggle('hide-known', S.hide);
    }
    function mark() {
      const mode = getMode();
      gallery.querySelectorAll('.gcard').forEach(b => {
        const lab = b.dataset.l;
        b.classList.toggle('known', !!lab && has(mode, lab));
      });
    }
    bar.addEventListener('click', ev => {
      const b = ev.target.closest('.kbtn'); if (!b) return;
      if (b.dataset.a === 'edit') { editMode = !editMode; emit(); }
      else { S.hide = !S.hide; save(); emit(); }
    });
    gallery.addEventListener('contextmenu', ev => {
      const b = ev.target.closest('.gcard'); if (!b || !b.dataset.l) return;
      ev.preventDefault();
      if (lpT) { clearTimeout(lpT); lpT = 0; lpEat = true; }   // Android: долгое нажатие = contextmenu
      toggle(getMode(), b.dataset.l);
    });
    /* телефон: правого клика нет (iOS не шлёт contextmenu) — долгое нажатие */
    let lpT = 0, lpEat = false, lpXY = null;
    gallery.addEventListener('touchstart', ev => {
      const b = ev.target.closest('.gcard'); if (!b || !b.dataset.l || ev.touches.length > 1) return;
      const t = ev.touches[0]; lpXY = [t.clientX, t.clientY]; lpEat = false;
      clearTimeout(lpT);
      lpT = setTimeout(() => {
        lpEat = true; lpT = 0;
        if (navigator.vibrate) try { navigator.vibrate(15); } catch (e) {}
        toggle(getMode(), b.dataset.l);
      }, 480);
    }, { passive: true });
    gallery.addEventListener('touchmove', ev => {
      if (!lpT || !lpXY) return;
      const t = ev.touches[0];
      if (Math.abs(t.clientX - lpXY[0]) + Math.abs(t.clientY - lpXY[1]) > 10) { clearTimeout(lpT); lpT = 0; }
    }, { passive: true });
    const lpEnd = () => { clearTimeout(lpT); lpT = 0; };
    gallery.addEventListener('touchend', lpEnd); gallery.addEventListener('touchcancel', lpEnd);
    /* клик, который браузер шлёт после долгого нажатия, — не выбор случая */
    gallery.addEventListener('click', ev => { if (lpEat) { lpEat = false; ev.stopImmediatePropagation(); ev.preventDefault(); } }, true);
    gallery.addEventListener('contextmenu', ev => { if (lpEat && !lpT) { ev.preventDefault(); ev.stopImmediatePropagation(); } }, true);
    gallery.style.webkitTouchCallout = 'none';

    /* в режиме «Знаю» левый клик перехватываем раньше, чем его увидит галерея */
    gallery.addEventListener('click', ev => {
      if (!editMode) return;
      const b = ev.target.closest('.gcard'); if (!b || !b.dataset.l) return;
      ev.stopImmediatePropagation(); ev.preventDefault();
      toggle(getMode(), b.dataset.l);
    }, true);
    window.addEventListener('cg-known', () => { paint(); mark(); });
    const refresh = () => { paint(); mark(); };
    refresh();
    return refresh;               // зовём после перерисовки галереи / смены вкладки
  }

  window.Known = { has, toggle, attach };
})();
