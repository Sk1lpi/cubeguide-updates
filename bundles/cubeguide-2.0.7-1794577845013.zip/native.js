(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // mobile/node_modules/@capacitor/core/dist/index.js
  var ExceptionCode, CapacitorException, getPlatformId, createCapacitor, initCapacitorGlobal, Capacitor, registerPlugin, WebPlugin, encode, decode, CapacitorCookiesPluginWeb, CapacitorCookies, readBlobAsBase64, normalizeHttpHeaders, buildUrlParams, buildRequestInit, CapacitorHttpPluginWeb, CapacitorHttp, SystemBarsStyle, SystemBarType, SystemBarsPluginWeb, SystemBars;
  var init_dist = __esm({
    "mobile/node_modules/@capacitor/core/dist/index.js"() {
      (function(ExceptionCode2) {
        ExceptionCode2["Unimplemented"] = "UNIMPLEMENTED";
        ExceptionCode2["Unavailable"] = "UNAVAILABLE";
      })(ExceptionCode || (ExceptionCode = {}));
      CapacitorException = class extends Error {
        constructor(message, code, data) {
          super(message);
          this.message = message;
          this.code = code;
          this.data = data;
        }
      };
      getPlatformId = (win) => {
        var _a, _b;
        if (win === null || win === void 0 ? void 0 : win.androidBridge) {
          return "android";
        } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
          return "ios";
        } else {
          return "web";
        }
      };
      createCapacitor = (win) => {
        const capCustomPlatform = win.CapacitorCustomPlatform || null;
        const cap = win.Capacitor || {};
        const Plugins = cap.Plugins = cap.Plugins || {};
        const getPlatform = () => {
          return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
        };
        const isNativePlatform = () => getPlatform() !== "web";
        const isPluginAvailable = (pluginName) => {
          const plugin = registeredPlugins.get(pluginName);
          if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
            return true;
          }
          if (getPluginHeader(pluginName)) {
            return true;
          }
          return false;
        };
        const getPluginHeader = (pluginName) => {
          var _a;
          return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find((h) => h.name === pluginName);
        };
        const handleError = (err) => win.console.error(err);
        const registeredPlugins = /* @__PURE__ */ new Map();
        const registerPlugin2 = (pluginName, jsImplementations = {}) => {
          const registeredPlugin = registeredPlugins.get(pluginName);
          if (registeredPlugin) {
            console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
            return registeredPlugin.proxy;
          }
          const platform = getPlatform();
          const pluginHeader = getPluginHeader(pluginName);
          let jsImplementation;
          const loadPluginImplementation = async () => {
            if (!jsImplementation && platform in jsImplementations) {
              jsImplementation = typeof jsImplementations[platform] === "function" ? jsImplementation = await jsImplementations[platform]() : jsImplementation = jsImplementations[platform];
            } else if (capCustomPlatform !== null && !jsImplementation && "web" in jsImplementations) {
              jsImplementation = typeof jsImplementations["web"] === "function" ? jsImplementation = await jsImplementations["web"]() : jsImplementation = jsImplementations["web"];
            }
            return jsImplementation;
          };
          const createPluginMethod = (impl, prop) => {
            var _a, _b;
            if (pluginHeader) {
              const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find((m) => prop === m.name);
              if (methodHeader) {
                if (methodHeader.rtype === "promise") {
                  return (options) => cap.nativePromise(pluginName, prop.toString(), options);
                } else {
                  return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
                }
              } else if (impl) {
                return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
              }
            } else if (impl) {
              return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
            } else {
              throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
            }
          };
          const createPluginMethodWrapper = (prop) => {
            let remove;
            const wrapper = (...args) => {
              const p = loadPluginImplementation().then((impl) => {
                const fn = createPluginMethod(impl, prop);
                if (fn) {
                  const p2 = fn(...args);
                  remove = p2 === null || p2 === void 0 ? void 0 : p2.remove;
                  return p2;
                } else {
                  throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
                }
              });
              if (prop === "addListener") {
                p.remove = async () => remove();
              }
              return p;
            };
            wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
            Object.defineProperty(wrapper, "name", {
              value: prop,
              writable: false,
              configurable: false
            });
            return wrapper;
          };
          const addListener = createPluginMethodWrapper("addListener");
          const removeListener = createPluginMethodWrapper("removeListener");
          const addListenerNative = (eventName, callback) => {
            const call = addListener({ eventName }, callback).then((callbackId) => callbackId);
            const remove = async () => {
              const callbackId = await call;
              await removeListener({
                eventName,
                callbackId
              });
            };
            const p = new Promise((resolve) => call.then(() => resolve({ remove })));
            p.remove = async () => {
              console.warn(`Using addListener() without 'await' is deprecated.`);
              await remove();
            };
            return p;
          };
          const proxy = new Proxy({}, {
            get(_, prop) {
              switch (prop) {
                // https://github.com/facebook/react/issues/20030
                case "$$typeof":
                  return void 0;
                case "toJSON":
                  return () => ({});
                case "addListener":
                  return pluginHeader ? addListenerNative : addListener;
                case "removeListener":
                  return removeListener;
                default:
                  return createPluginMethodWrapper(prop);
              }
            }
          });
          Plugins[pluginName] = proxy;
          registeredPlugins.set(pluginName, {
            name: pluginName,
            proxy,
            platforms: /* @__PURE__ */ new Set([...Object.keys(jsImplementations), ...pluginHeader ? [platform] : []])
          });
          return proxy;
        };
        if (!cap.convertFileSrc) {
          cap.convertFileSrc = (filePath) => filePath;
        }
        cap.getPlatform = getPlatform;
        cap.handleError = handleError;
        cap.isNativePlatform = isNativePlatform;
        cap.isPluginAvailable = isPluginAvailable;
        cap.registerPlugin = registerPlugin2;
        cap.Exception = CapacitorException;
        cap.DEBUG = !!cap.DEBUG;
        cap.isLoggingEnabled = !!cap.isLoggingEnabled;
        return cap;
      };
      initCapacitorGlobal = (win) => win.Capacitor = createCapacitor(win);
      Capacitor = /* @__PURE__ */ initCapacitorGlobal(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      registerPlugin = Capacitor.registerPlugin;
      WebPlugin = class {
        constructor() {
          this.listeners = {};
          this.retainedEventArguments = {};
          this.windowListeners = {};
        }
        addListener(eventName, listenerFunc) {
          let firstListener = false;
          const listeners = this.listeners[eventName];
          if (!listeners) {
            this.listeners[eventName] = [];
            firstListener = true;
          }
          this.listeners[eventName].push(listenerFunc);
          const windowListener = this.windowListeners[eventName];
          if (windowListener && !windowListener.registered) {
            this.addWindowListener(windowListener);
          }
          if (firstListener) {
            this.sendRetainedArgumentsForEvent(eventName);
          }
          const remove = async () => this.removeListener(eventName, listenerFunc);
          const p = Promise.resolve({ remove });
          return p;
        }
        async removeAllListeners() {
          this.listeners = {};
          for (const listener in this.windowListeners) {
            this.removeWindowListener(this.windowListeners[listener]);
          }
          this.windowListeners = {};
        }
        notifyListeners(eventName, data, retainUntilConsumed) {
          const listeners = this.listeners[eventName];
          if (!listeners) {
            if (retainUntilConsumed) {
              let args = this.retainedEventArguments[eventName];
              if (!args) {
                args = [];
              }
              args.push(data);
              this.retainedEventArguments[eventName] = args;
            }
            return;
          }
          listeners.forEach((listener) => listener(data));
        }
        hasListeners(eventName) {
          var _a;
          return !!((_a = this.listeners[eventName]) === null || _a === void 0 ? void 0 : _a.length);
        }
        registerWindowListener(windowEventName, pluginEventName) {
          this.windowListeners[pluginEventName] = {
            registered: false,
            windowEventName,
            pluginEventName,
            handler: (event) => {
              this.notifyListeners(pluginEventName, event);
            }
          };
        }
        unimplemented(msg = "not implemented") {
          return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
        }
        unavailable(msg = "not available") {
          return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
        }
        async removeListener(eventName, listenerFunc) {
          const listeners = this.listeners[eventName];
          if (!listeners) {
            return;
          }
          const index = listeners.indexOf(listenerFunc);
          if (index !== -1) {
            this.listeners[eventName].splice(index, 1);
          }
          if (!this.listeners[eventName].length) {
            this.removeWindowListener(this.windowListeners[eventName]);
          }
        }
        addWindowListener(handle) {
          window.addEventListener(handle.windowEventName, handle.handler);
          handle.registered = true;
        }
        removeWindowListener(handle) {
          if (!handle) {
            return;
          }
          window.removeEventListener(handle.windowEventName, handle.handler);
          handle.registered = false;
        }
        sendRetainedArgumentsForEvent(eventName) {
          const args = this.retainedEventArguments[eventName];
          if (!args) {
            return;
          }
          delete this.retainedEventArguments[eventName];
          args.forEach((arg) => {
            this.notifyListeners(eventName, arg);
          });
        }
      };
      encode = (str) => encodeURIComponent(str).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
      decode = (str) => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
      CapacitorCookiesPluginWeb = class extends WebPlugin {
        async getCookies() {
          const cookies = document.cookie;
          const cookieMap = {};
          cookies.split(";").forEach((cookie) => {
            if (cookie.length <= 0)
              return;
            let [key, value] = cookie.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
            key = decode(key).trim();
            value = decode(value).trim();
            cookieMap[key] = value;
          });
          return cookieMap;
        }
        async setCookie(options) {
          try {
            const encodedKey = encode(options.key);
            const encodedValue = encode(options.value);
            const expires = options.expires ? `; expires=${options.expires.replace("expires=", "")}` : "";
            const path = (options.path || "/").replace("path=", "");
            const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : "";
            document.cookie = `${encodedKey}=${encodedValue || ""}${expires}; path=${path}; ${domain};`;
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async deleteCookie(options) {
          try {
            document.cookie = `${options.key}=; Max-Age=0`;
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async clearCookies() {
          try {
            const cookies = document.cookie.split(";") || [];
            for (const cookie of cookies) {
              document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
            }
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async clearAllCookies() {
          try {
            await this.clearCookies();
          } catch (error) {
            return Promise.reject(error);
          }
        }
      };
      CapacitorCookies = registerPlugin("CapacitorCookies", {
        web: () => new CapacitorCookiesPluginWeb()
      });
      readBlobAsBase64 = async (blob) => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const base64String = reader.result;
          resolve(base64String.indexOf(",") >= 0 ? base64String.split(",")[1] : base64String);
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(blob);
      });
      normalizeHttpHeaders = (headers = {}) => {
        const originalKeys = Object.keys(headers);
        const loweredKeys = Object.keys(headers).map((k) => k.toLocaleLowerCase());
        const normalized = loweredKeys.reduce((acc, key, index) => {
          acc[key] = headers[originalKeys[index]];
          return acc;
        }, {});
        return normalized;
      };
      buildUrlParams = (params, shouldEncode = true) => {
        if (!params)
          return null;
        const output = Object.entries(params).reduce((accumulator, entry) => {
          const [key, value] = entry;
          let encodedValue;
          let item;
          if (Array.isArray(value)) {
            item = "";
            value.forEach((str) => {
              encodedValue = shouldEncode ? encodeURIComponent(str) : str;
              item += `${key}=${encodedValue}&`;
            });
            item.slice(0, -1);
          } else {
            encodedValue = shouldEncode ? encodeURIComponent(value) : value;
            item = `${key}=${encodedValue}`;
          }
          return `${accumulator}&${item}`;
        }, "");
        return output.substr(1);
      };
      buildRequestInit = (options, extra = {}) => {
        const output = Object.assign({ method: options.method || "GET", headers: options.headers }, extra);
        const headers = normalizeHttpHeaders(options.headers);
        const type = headers["content-type"] || "";
        if (typeof options.data === "string") {
          output.body = options.data;
        } else if (type.includes("application/x-www-form-urlencoded")) {
          const params = new URLSearchParams();
          for (const [key, value] of Object.entries(options.data || {})) {
            params.set(key, value);
          }
          output.body = params.toString();
        } else if (type.includes("multipart/form-data") || options.data instanceof FormData) {
          const form = new FormData();
          if (options.data instanceof FormData) {
            options.data.forEach((value, key) => {
              form.append(key, value);
            });
          } else {
            for (const key of Object.keys(options.data)) {
              form.append(key, options.data[key]);
            }
          }
          output.body = form;
          const headers2 = new Headers(output.headers);
          headers2.delete("content-type");
          output.headers = headers2;
        } else if (type.includes("application/json") || typeof options.data === "object") {
          output.body = JSON.stringify(options.data);
        }
        return output;
      };
      CapacitorHttpPluginWeb = class extends WebPlugin {
        /**
         * Perform an Http request given a set of options
         * @param options Options to build the HTTP request
         */
        async request(options) {
          const requestInit = buildRequestInit(options, options.webFetchExtra);
          const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
          const url = urlParams ? `${options.url}?${urlParams}` : options.url;
          const response = await fetch(url, requestInit);
          const contentType = response.headers.get("content-type") || "";
          let { responseType = "text" } = response.ok ? options : {};
          if (contentType.includes("application/json")) {
            responseType = "json";
          }
          let data;
          let blob;
          switch (responseType) {
            case "arraybuffer":
            case "blob":
              blob = await response.blob();
              data = await readBlobAsBase64(blob);
              break;
            case "json":
              data = await response.json();
              break;
            case "document":
            case "text":
            default:
              data = await response.text();
          }
          const headers = {};
          response.headers.forEach((value, key) => {
            headers[key] = value;
          });
          return {
            data,
            headers,
            status: response.status,
            url: response.url
          };
        }
        /**
         * Perform an Http GET request given a set of options
         * @param options Options to build the HTTP request
         */
        async get(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "GET" }));
        }
        /**
         * Perform an Http POST request given a set of options
         * @param options Options to build the HTTP request
         */
        async post(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "POST" }));
        }
        /**
         * Perform an Http PUT request given a set of options
         * @param options Options to build the HTTP request
         */
        async put(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "PUT" }));
        }
        /**
         * Perform an Http PATCH request given a set of options
         * @param options Options to build the HTTP request
         */
        async patch(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "PATCH" }));
        }
        /**
         * Perform an Http DELETE request given a set of options
         * @param options Options to build the HTTP request
         */
        async delete(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "DELETE" }));
        }
      };
      CapacitorHttp = registerPlugin("CapacitorHttp", {
        web: () => new CapacitorHttpPluginWeb()
      });
      (function(SystemBarsStyle2) {
        SystemBarsStyle2["Dark"] = "DARK";
        SystemBarsStyle2["Light"] = "LIGHT";
        SystemBarsStyle2["Default"] = "DEFAULT";
      })(SystemBarsStyle || (SystemBarsStyle = {}));
      (function(SystemBarType2) {
        SystemBarType2["StatusBar"] = "StatusBar";
        SystemBarType2["NavigationBar"] = "NavigationBar";
      })(SystemBarType || (SystemBarType = {}));
      SystemBarsPluginWeb = class extends WebPlugin {
        async setStyle() {
          this.unavailable("not available for web");
        }
        async setAnimation() {
          this.unavailable("not available for web");
        }
        async show() {
          this.unavailable("not available for web");
        }
        async hide() {
          this.unavailable("not available for web");
        }
      };
      SystemBars = registerPlugin("SystemBars", {
        web: () => new SystemBarsPluginWeb()
      });
    }
  });

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/conversion.js
  function numbersToDataView(value) {
    return new DataView(Uint8Array.from(value).buffer);
  }
  function dataViewToNumbers(value) {
    return Array.from(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
  }
  function numberToUUID(value) {
    return `0000${value.toString(16).padStart(4, "0")}-0000-1000-8000-00805f9b34fb`;
  }
  function hexStringToDataView(hex) {
    const bin = [];
    let i, c, isEmpty = 1, buffer = 0;
    for (i = 0; i < hex.length; i++) {
      c = hex.charCodeAt(i);
      if (c > 47 && c < 58 || c > 64 && c < 71 || c > 96 && c < 103) {
        buffer = buffer << 4 ^ (c > 64 ? c + 9 : c) & 15;
        if (isEmpty ^= 1) {
          bin.push(buffer & 255);
        }
      }
    }
    return numbersToDataView(bin);
  }
  function dataViewToHexString(value) {
    return dataViewToNumbers(value).map((n) => {
      let s = n.toString(16);
      if (s.length == 1) {
        s = "0" + s;
      }
      return s;
    }).join("");
  }
  function webUUIDToString(uuid) {
    if (typeof uuid === "string") {
      return uuid;
    } else if (typeof uuid === "number") {
      return numberToUUID(uuid);
    } else {
      throw new Error("Invalid UUID");
    }
  }
  function mapToObject(map) {
    const obj = {};
    if (!map) {
      return void 0;
    }
    map.forEach((value, key) => {
      obj[key.toString()] = value;
    });
    return obj;
  }
  function toUint8Array(value) {
    if (value === void 0) {
      return void 0;
    }
    if (typeof value === "string") {
      const dataView = hexStringToDataView(value);
      return new Uint8Array(dataView.buffer, dataView.byteOffset, dataView.byteLength);
    }
    if (value instanceof DataView) {
      return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    }
    return value;
  }
  function toHexString(value) {
    if (value === void 0) {
      return void 0;
    }
    if (value instanceof DataView) {
      return dataViewToHexString(value);
    }
    return dataViewToHexString(new DataView(value.buffer, value.byteOffset, value.byteLength));
  }
  function toArrayBufferDataView(value) {
    if (typeof SharedArrayBuffer !== "undefined" && value.buffer instanceof SharedArrayBuffer) {
      const uint8Array = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
      const buffer = uint8Array.slice().buffer;
      return new DataView(buffer);
    }
    return value;
  }
  var init_conversion = __esm({
    "mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/conversion.js"() {
    }
  });

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/timeout.js
  async function runWithTimeout(promise, time, exception) {
    let timer;
    return Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(exception), time);
      })
    ]).finally(() => clearTimeout(timer));
  }
  var init_timeout = __esm({
    "mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/timeout.js"() {
    }
  });

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/web.js
  var web_exports = {};
  __export(web_exports, {
    BluetoothLeWeb: () => BluetoothLeWeb
  });
  var BluetoothLeWeb;
  var init_web = __esm({
    "mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/web.js"() {
      init_dist();
      init_conversion();
      init_timeout();
      BluetoothLeWeb = class extends WebPlugin {
        constructor() {
          super(...arguments);
          this.deviceMap = /* @__PURE__ */ new Map();
          this.discoveredDevices = /* @__PURE__ */ new Map();
          this.scan = null;
          this.DEFAULT_CONNECTION_TIMEOUT = 1e4;
          this.onAdvertisementReceivedCallback = this.onAdvertisementReceived.bind(this);
          this.onDisconnectedCallback = this.onDisconnected.bind(this);
          this.onCharacteristicValueChangedCallback = this.onCharacteristicValueChanged.bind(this);
        }
        async initialize() {
          if (typeof navigator === "undefined" || !navigator.bluetooth) {
            throw this.unavailable("Web Bluetooth API not available in this browser.");
          }
          const isAvailable = await navigator.bluetooth.getAvailability();
          if (!isAvailable) {
            throw this.unavailable("No Bluetooth radio available.");
          }
        }
        async isEnabled() {
          return { value: true };
        }
        async requestEnable() {
          throw this.unavailable("requestEnable is not available on web.");
        }
        async enable() {
          throw this.unavailable("enable is not available on web.");
        }
        async disable() {
          throw this.unavailable("disable is not available on web.");
        }
        async startEnabledNotifications() {
        }
        async stopEnabledNotifications() {
        }
        async isLocationEnabled() {
          throw this.unavailable("isLocationEnabled is not available on web.");
        }
        async openLocationSettings() {
          throw this.unavailable("openLocationSettings is not available on web.");
        }
        async openBluetoothSettings() {
          throw this.unavailable("openBluetoothSettings is not available on web.");
        }
        async openAppSettings() {
          throw this.unavailable("openAppSettings is not available on web.");
        }
        async setDisplayStrings() {
        }
        async requestDevice(options) {
          const filters = this.getFilters(options);
          const device = await navigator.bluetooth.requestDevice({
            filters: filters.length ? filters : void 0,
            optionalServices: options === null || options === void 0 ? void 0 : options.optionalServices,
            acceptAllDevices: filters.length === 0
          });
          this.deviceMap.set(device.id, device);
          const bleDevice = this.getBleDevice(device);
          return bleDevice;
        }
        async requestLEScan(options) {
          this.requestBleDeviceOptions = options;
          const filters = this.getFilters(options);
          await this.stopLEScan();
          this.discoveredDevices = /* @__PURE__ */ new Map();
          navigator.bluetooth.removeEventListener("advertisementreceived", this.onAdvertisementReceivedCallback);
          navigator.bluetooth.addEventListener("advertisementreceived", this.onAdvertisementReceivedCallback);
          this.scan = await navigator.bluetooth.requestLEScan({
            filters: filters.length ? filters : void 0,
            acceptAllAdvertisements: filters.length === 0,
            keepRepeatedDevices: options === null || options === void 0 ? void 0 : options.allowDuplicates
          });
        }
        onAdvertisementReceived(event) {
          var _a, _b, _c;
          const deviceId = event.device.id;
          this.deviceMap.set(deviceId, event.device);
          const isNew = !this.discoveredDevices.has(deviceId);
          if (((_a = this.requestBleDeviceOptions) === null || _a === void 0 ? void 0 : _a.serviceData) && !this.matchesServiceDataFilter(event)) {
            return;
          }
          if (isNew || ((_b = this.requestBleDeviceOptions) === null || _b === void 0 ? void 0 : _b.allowDuplicates)) {
            this.discoveredDevices.set(deviceId, true);
            const device = this.getBleDevice(event.device);
            const result = {
              device,
              localName: device.name,
              rssi: event.rssi,
              txPower: event.txPower,
              manufacturerData: mapToObject(event.manufacturerData),
              serviceData: mapToObject(event.serviceData),
              uuids: (_c = event.uuids) === null || _c === void 0 ? void 0 : _c.map(webUUIDToString)
            };
            this.notifyListeners("onScanResult", result);
          }
        }
        async stopLEScan() {
          var _a;
          if ((_a = this.scan) === null || _a === void 0 ? void 0 : _a.active) {
            this.scan.stop();
          }
          this.scan = null;
        }
        async getDevices(options) {
          const devices = await navigator.bluetooth.getDevices();
          const bleDevices = devices.filter((device) => options.deviceIds.includes(device.id)).map((device) => {
            this.deviceMap.set(device.id, device);
            const bleDevice = this.getBleDevice(device);
            return bleDevice;
          });
          return { devices: bleDevices };
        }
        async getConnectedDevices(_options) {
          const devices = await navigator.bluetooth.getDevices();
          const bleDevices = devices.filter((device) => {
            var _a;
            return (_a = device.gatt) === null || _a === void 0 ? void 0 : _a.connected;
          }).map((device) => {
            this.deviceMap.set(device.id, device);
            const bleDevice = this.getBleDevice(device);
            return bleDevice;
          });
          return { devices: bleDevices };
        }
        async getBondedDevices() {
          return {};
        }
        async connect(options) {
          var _a, _b;
          const device = this.getDeviceFromMap(options.deviceId);
          device.removeEventListener("gattserverdisconnected", this.onDisconnectedCallback);
          device.addEventListener("gattserverdisconnected", this.onDisconnectedCallback);
          const timeoutError = /* @__PURE__ */ Symbol();
          if (device.gatt === void 0) {
            throw new Error("No gatt server available.");
          }
          try {
            const timeout = (_a = options.timeout) !== null && _a !== void 0 ? _a : this.DEFAULT_CONNECTION_TIMEOUT;
            await runWithTimeout(device.gatt.connect(), timeout, timeoutError);
          } catch (error) {
            await ((_b = device.gatt) === null || _b === void 0 ? void 0 : _b.disconnect());
            if (error === timeoutError) {
              throw new Error("Connection timeout");
            } else {
              throw error;
            }
          }
        }
        onDisconnected(event) {
          const deviceId = event.target.id;
          const key = `disconnected|${deviceId}`;
          this.notifyListeners(key, null);
        }
        async createBond(_options) {
          throw this.unavailable("createBond is not available on web.");
        }
        async isBonded(_options) {
          throw this.unavailable("isBonded is not available on web.");
        }
        async disconnect(options) {
          var _a;
          (_a = this.getDeviceFromMap(options.deviceId).gatt) === null || _a === void 0 ? void 0 : _a.disconnect();
        }
        async getServices(options) {
          var _a, _b;
          const services = (_b = await ((_a = this.getDeviceFromMap(options.deviceId).gatt) === null || _a === void 0 ? void 0 : _a.getPrimaryServices())) !== null && _b !== void 0 ? _b : [];
          const bleServices = [];
          for (const service of services) {
            const characteristics = await service.getCharacteristics();
            const bleCharacteristics = [];
            for (const characteristic of characteristics) {
              bleCharacteristics.push({
                uuid: characteristic.uuid,
                properties: this.getProperties(characteristic),
                descriptors: await this.getDescriptors(characteristic)
              });
            }
            bleServices.push({ uuid: service.uuid, characteristics: bleCharacteristics });
          }
          return { services: bleServices };
        }
        async getDescriptors(characteristic) {
          try {
            const descriptors = await characteristic.getDescriptors();
            return descriptors.map((descriptor) => ({
              uuid: descriptor.uuid
            }));
          } catch (_a) {
            return [];
          }
        }
        getProperties(characteristic) {
          return {
            broadcast: characteristic.properties.broadcast,
            read: characteristic.properties.read,
            writeWithoutResponse: characteristic.properties.writeWithoutResponse,
            write: characteristic.properties.write,
            notify: characteristic.properties.notify,
            indicate: characteristic.properties.indicate,
            authenticatedSignedWrites: characteristic.properties.authenticatedSignedWrites,
            reliableWrite: characteristic.properties.reliableWrite,
            writableAuxiliaries: characteristic.properties.writableAuxiliaries
          };
        }
        async getCharacteristic(options) {
          var _a;
          const service = await ((_a = this.getDeviceFromMap(options.deviceId).gatt) === null || _a === void 0 ? void 0 : _a.getPrimaryService(options === null || options === void 0 ? void 0 : options.service));
          return service === null || service === void 0 ? void 0 : service.getCharacteristic(options === null || options === void 0 ? void 0 : options.characteristic);
        }
        async getDescriptor(options) {
          const characteristic = await this.getCharacteristic(options);
          return characteristic === null || characteristic === void 0 ? void 0 : characteristic.getDescriptor(options === null || options === void 0 ? void 0 : options.descriptor);
        }
        async discoverServices(_options) {
          throw this.unavailable("discoverServices is not available on web.");
        }
        async getMtu(_options) {
          throw this.unavailable("getMtu is not available on web.");
        }
        async requestConnectionPriority(_options) {
          throw this.unavailable("requestConnectionPriority is not available on web.");
        }
        async readRssi(_options) {
          throw this.unavailable("readRssi is not available on web.");
        }
        async read(options) {
          const characteristic = await this.getCharacteristic(options);
          const value = await (characteristic === null || characteristic === void 0 ? void 0 : characteristic.readValue());
          return { value };
        }
        async write(options) {
          const characteristic = await this.getCharacteristic(options);
          let dataView;
          if (typeof options.value === "string") {
            dataView = hexStringToDataView(options.value);
          } else {
            dataView = options.value;
          }
          await (characteristic === null || characteristic === void 0 ? void 0 : characteristic.writeValueWithResponse(toArrayBufferDataView(dataView)));
        }
        async writeWithoutResponse(options) {
          const characteristic = await this.getCharacteristic(options);
          let dataView;
          if (typeof options.value === "string") {
            dataView = hexStringToDataView(options.value);
          } else {
            dataView = options.value;
          }
          await (characteristic === null || characteristic === void 0 ? void 0 : characteristic.writeValueWithoutResponse(toArrayBufferDataView(dataView)));
        }
        async readDescriptor(options) {
          const descriptor = await this.getDescriptor(options);
          const value = await (descriptor === null || descriptor === void 0 ? void 0 : descriptor.readValue());
          return { value };
        }
        async writeDescriptor(options) {
          const descriptor = await this.getDescriptor(options);
          let dataView;
          if (typeof options.value === "string") {
            dataView = hexStringToDataView(options.value);
          } else {
            dataView = options.value;
          }
          await (descriptor === null || descriptor === void 0 ? void 0 : descriptor.writeValue(toArrayBufferDataView(dataView)));
        }
        async startNotifications(options) {
          const characteristic = await this.getCharacteristic(options);
          characteristic === null || characteristic === void 0 ? void 0 : characteristic.removeEventListener("characteristicvaluechanged", this.onCharacteristicValueChangedCallback);
          characteristic === null || characteristic === void 0 ? void 0 : characteristic.addEventListener("characteristicvaluechanged", this.onCharacteristicValueChangedCallback);
          await (characteristic === null || characteristic === void 0 ? void 0 : characteristic.startNotifications());
        }
        onCharacteristicValueChanged(event) {
          var _a, _b;
          const characteristic = event.target;
          const key = `notification|${(_a = characteristic.service) === null || _a === void 0 ? void 0 : _a.device.id}|${(_b = characteristic.service) === null || _b === void 0 ? void 0 : _b.uuid}|${characteristic.uuid}`;
          this.notifyListeners(key, {
            value: characteristic.value
          });
        }
        async stopNotifications(options) {
          const characteristic = await this.getCharacteristic(options);
          await (characteristic === null || characteristic === void 0 ? void 0 : characteristic.stopNotifications());
        }
        getFilters(options) {
          var _a, _b;
          const filters = [];
          for (const service of (_a = options === null || options === void 0 ? void 0 : options.services) !== null && _a !== void 0 ? _a : []) {
            filters.push({
              services: [service],
              name: options === null || options === void 0 ? void 0 : options.name,
              namePrefix: options === null || options === void 0 ? void 0 : options.namePrefix
            });
          }
          if (((options === null || options === void 0 ? void 0 : options.name) || (options === null || options === void 0 ? void 0 : options.namePrefix)) && filters.length === 0) {
            filters.push({
              name: options.name,
              namePrefix: options.namePrefix
            });
          }
          for (const manufacturerData of (_b = options === null || options === void 0 ? void 0 : options.manufacturerData) !== null && _b !== void 0 ? _b : []) {
            filters.push({
              manufacturerData: [manufacturerData]
            });
          }
          return filters;
        }
        matchesServiceDataFilter(event) {
          var _a;
          const filters = (_a = this.requestBleDeviceOptions) === null || _a === void 0 ? void 0 : _a.serviceData;
          if (!filters || filters.length === 0) {
            return true;
          }
          if (!event.serviceData) {
            return false;
          }
          for (const filter of filters) {
            const serviceData = event.serviceData.get(filter.serviceUuid);
            if (!serviceData) {
              continue;
            }
            if (!filter.dataPrefix) {
              return true;
            }
            const data = new Uint8Array(serviceData.buffer);
            const prefixView = filter.dataPrefix;
            if (data.length < prefixView.byteLength) {
              continue;
            }
            if (filter.mask) {
              const maskView = filter.mask;
              let matches2 = true;
              for (let i = 0; i < prefixView.byteLength; i++) {
                if ((data[i] & maskView.getUint8(i)) !== (prefixView.getUint8(i) & maskView.getUint8(i))) {
                  matches2 = false;
                  break;
                }
              }
              if (matches2) {
                return true;
              }
            } else {
              let matches2 = true;
              for (let i = 0; i < prefixView.byteLength; i++) {
                if (data[i] !== prefixView.getUint8(i)) {
                  matches2 = false;
                  break;
                }
              }
              if (matches2) {
                return true;
              }
            }
          }
          return false;
        }
        getDeviceFromMap(deviceId) {
          const device = this.deviceMap.get(deviceId);
          if (device === void 0) {
            throw new Error('Device not found. Call "requestDevice", "requestLEScan" or "getDevices" first.');
          }
          return device;
        }
        getBleDevice(device) {
          var _a;
          const bleDevice = {
            deviceId: device.id,
            // use undefined instead of null if name is not available
            name: (_a = device.name) !== null && _a !== void 0 ? _a : void 0
          };
          return bleDevice;
        }
      };
    }
  });

  // mobile/node_modules/@capgo/capacitor-updater/dist/esm/definitions.js
  var AppUpdateAvailability, FlexibleUpdateInstallStatus, AppUpdateResultCode;
  var init_definitions = __esm({
    "mobile/node_modules/@capgo/capacitor-updater/dist/esm/definitions.js"() {
      (function(AppUpdateAvailability2) {
        AppUpdateAvailability2[AppUpdateAvailability2["UNKNOWN"] = 0] = "UNKNOWN";
        AppUpdateAvailability2[AppUpdateAvailability2["UPDATE_NOT_AVAILABLE"] = 1] = "UPDATE_NOT_AVAILABLE";
        AppUpdateAvailability2[AppUpdateAvailability2["UPDATE_AVAILABLE"] = 2] = "UPDATE_AVAILABLE";
        AppUpdateAvailability2[AppUpdateAvailability2["UPDATE_IN_PROGRESS"] = 3] = "UPDATE_IN_PROGRESS";
      })(AppUpdateAvailability || (AppUpdateAvailability = {}));
      (function(FlexibleUpdateInstallStatus2) {
        FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["UNKNOWN"] = 0] = "UNKNOWN";
        FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["PENDING"] = 1] = "PENDING";
        FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["DOWNLOADING"] = 2] = "DOWNLOADING";
        FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["INSTALLING"] = 3] = "INSTALLING";
        FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["INSTALLED"] = 4] = "INSTALLED";
        FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["FAILED"] = 5] = "FAILED";
        FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["CANCELED"] = 6] = "CANCELED";
        FlexibleUpdateInstallStatus2[FlexibleUpdateInstallStatus2["DOWNLOADED"] = 11] = "DOWNLOADED";
      })(FlexibleUpdateInstallStatus || (FlexibleUpdateInstallStatus = {}));
      (function(AppUpdateResultCode2) {
        AppUpdateResultCode2[AppUpdateResultCode2["OK"] = 0] = "OK";
        AppUpdateResultCode2[AppUpdateResultCode2["CANCELED"] = 1] = "CANCELED";
        AppUpdateResultCode2[AppUpdateResultCode2["FAILED"] = 2] = "FAILED";
        AppUpdateResultCode2[AppUpdateResultCode2["NOT_AVAILABLE"] = 3] = "NOT_AVAILABLE";
        AppUpdateResultCode2[AppUpdateResultCode2["NOT_ALLOWED"] = 4] = "NOT_ALLOWED";
        AppUpdateResultCode2[AppUpdateResultCode2["INFO_MISSING"] = 5] = "INFO_MISSING";
      })(AppUpdateResultCode || (AppUpdateResultCode = {}));
    }
  });

  // mobile/node_modules/@capgo/capacitor-updater/dist/esm/web.js
  var web_exports2 = {};
  __export(web_exports2, {
    CapacitorUpdaterWeb: () => CapacitorUpdaterWeb
  });
  var BUNDLE_BUILTIN, CapacitorUpdaterWeb;
  var init_web2 = __esm({
    "mobile/node_modules/@capgo/capacitor-updater/dist/esm/web.js"() {
      init_dist();
      init_definitions();
      BUNDLE_BUILTIN = {
        status: "success",
        version: "",
        downloaded: "1970-01-01T00:00:00.000Z",
        id: "builtin",
        checksum: ""
      };
      CapacitorUpdaterWeb = class extends WebPlugin {
        async setStatsUrl(options) {
          console.warn("Cannot setStatsUrl in web", options);
          return;
        }
        async setUpdateUrl(options) {
          console.warn("Cannot setUpdateUrl in web", options);
          return;
        }
        async setChannelUrl(options) {
          console.warn("Cannot setChannelUrl in web", options);
          return;
        }
        async download(options) {
          console.warn("Cannot download version in web", options);
          return BUNDLE_BUILTIN;
        }
        async next(options) {
          console.warn("Cannot set next version in web", options);
          return BUNDLE_BUILTIN;
        }
        async isAutoUpdateEnabled() {
          console.warn("Cannot get isAutoUpdateEnabled in web");
          return { enabled: false };
        }
        async set(options) {
          console.warn("Cannot set active bundle in web", options);
          return;
        }
        async startPreviewSession(options) {
          console.warn("Cannot start preview session in web", options);
          return;
        }
        async listPreviews() {
          console.warn("Cannot list previews in web");
          return { previews: [], currentBundle: BUNDLE_BUILTIN };
        }
        async setPreview(options) {
          console.warn("Cannot set preview in web", options);
          return;
        }
        async resetPreview() {
          console.warn("Cannot reset preview in web");
          return;
        }
        async deletePreview(options) {
          console.warn("Cannot delete preview in web", options);
          return { removed: false, deleted: false };
        }
        async checkPreviewUpdate(options) {
          console.warn("Cannot check preview update in web", options);
          throw this.unimplemented("Preview updates are not available on web platform");
        }
        async updatePreview(options) {
          console.warn("Cannot update preview in web", options);
          throw this.unimplemented("Preview updates are not available on web platform");
        }
        async getDeviceId() {
          console.warn("Cannot get ID in web");
          return { deviceId: "default" };
        }
        async getBuiltinVersion() {
          console.warn("Cannot get version in web");
          return { version: "default" };
        }
        async getPluginVersion() {
          console.warn("Cannot get plugin version in web");
          return { version: "default" };
        }
        async delete(options) {
          console.warn("Cannot delete bundle in web", options);
        }
        async setBundleError(options) {
          console.warn("Cannot setBundleError in web", options);
          return BUNDLE_BUILTIN;
        }
        async list() {
          console.warn("Cannot list bundles in web");
          return { bundles: [] };
        }
        async reset(options) {
          console.warn("Cannot reset version in web", options);
        }
        async current() {
          console.warn("Cannot get current bundle in web");
          return { bundle: BUNDLE_BUILTIN, native: "0.0.0" };
        }
        async reload() {
          console.warn("Cannot reload current bundle in web");
          return;
        }
        async getLatest() {
          console.warn("Cannot getLatest current bundle in web");
          return {
            version: "0.0.0",
            message: "Cannot getLatest current bundle in web"
          };
        }
        async triggerUpdateCheck() {
          console.warn("Cannot triggerUpdateCheck in web");
          return { status: "unavailable", queued: false };
        }
        async getMissingBundleFiles(options) {
          var _a, _b, _c;
          console.warn("Cannot inspect missing bundle files in web", { manifestLength: (_b = (_a = options.manifest) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0 });
          const missing = (_c = options.manifest) !== null && _c !== void 0 ? _c : [];
          return {
            missing,
            total: missing.length,
            missingCount: missing.length,
            reusableCount: 0
          };
        }
        async getBundleDownloadSize(options) {
          var _a, _b, _c, _d, _e;
          console.warn("Cannot estimate bundle download size in web", { manifestLength: (_b = (_a = options.manifest) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0 });
          return {
            totalSize: 0,
            knownFiles: 0,
            unknownFiles: (_d = (_c = options.manifest) === null || _c === void 0 ? void 0 : _c.length) !== null && _d !== void 0 ? _d : 0,
            files: ((_e = options.manifest) !== null && _e !== void 0 ? _e : []).map((entry) => ({
              file_name: entry.file_name,
              file_hash: entry.file_hash,
              download_url: entry.download_url,
              error: "unavailable"
            }))
          };
        }
        async setChannel(options) {
          console.warn("Cannot setChannel in web", options);
          return {
            status: "error",
            error: "Cannot setChannel in web"
          };
        }
        async unsetChannel(options) {
          console.warn("Cannot unsetChannel in web", options);
          return;
        }
        async setCustomId(options) {
          console.warn("Cannot setCustomId in web", options);
          return;
        }
        async getChannel() {
          console.warn("Cannot getChannel in web");
          return {
            status: "error",
            error: "Cannot getChannel in web"
          };
        }
        async listChannels() {
          console.warn("Cannot listChannels in web");
          throw {
            message: "Cannot listChannels in web",
            error: "platform_not_supported"
          };
        }
        async notifyAppReady() {
          return { bundle: BUNDLE_BUILTIN };
        }
        async setMultiDelay(options) {
          console.warn("Cannot setMultiDelay in web", options === null || options === void 0 ? void 0 : options.delayConditions);
          return;
        }
        async cancelDelay() {
          console.warn("Cannot cancelDelay in web");
          return;
        }
        async isAutoUpdateAvailable() {
          console.warn("Cannot isAutoUpdateAvailable in web");
          return { available: false };
        }
        async getCurrentBundle() {
          console.warn("Cannot get current bundle in web");
          return BUNDLE_BUILTIN;
        }
        async getNextBundle() {
          return Promise.resolve(null);
        }
        async getFailedUpdate() {
          console.warn("Cannot getFailedUpdate in web");
          return null;
        }
        async setShakeMenu(_options) {
          throw this.unimplemented("Shake menu not available on web platform");
        }
        async isShakeMenuEnabled() {
          return Promise.resolve({ enabled: false, gesture: "shake" });
        }
        async setShakeChannelSelector(_options) {
          throw this.unimplemented("Shake channel selector not available on web platform");
        }
        async isShakeChannelSelectorEnabled() {
          return Promise.resolve({ enabled: false });
        }
        async getAppId() {
          console.warn("Cannot getAppId in web");
          return { appId: "default" };
        }
        async setAppId(options) {
          console.warn("Cannot setAppId in web", options);
          return;
        }
        // ============================================================================
        // App Store / Play Store Update Methods (Web stubs)
        // ============================================================================
        async getAppUpdateInfo(_options) {
          console.warn("getAppUpdateInfo is not available on web platform");
          return {
            currentVersionName: "0.0.0",
            currentVersionCode: "0",
            updateAvailability: AppUpdateAvailability.UNKNOWN
          };
        }
        async openAppStore(_options) {
          throw this.unimplemented("openAppStore is not available on web platform");
        }
        async performImmediateUpdate() {
          throw this.unimplemented("performImmediateUpdate is only available on Android");
        }
        async startFlexibleUpdate() {
          throw this.unimplemented("startFlexibleUpdate is only available on Android");
        }
        async completeFlexibleUpdate() {
          throw this.unimplemented("completeFlexibleUpdate is only available on Android");
        }
      };
    }
  });

  // mobile/src/ble-shim.js
  init_dist();

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/definitions.js
  var ScanMode;
  (function(ScanMode2) {
    ScanMode2[ScanMode2["SCAN_MODE_LOW_POWER"] = 0] = "SCAN_MODE_LOW_POWER";
    ScanMode2[ScanMode2["SCAN_MODE_BALANCED"] = 1] = "SCAN_MODE_BALANCED";
    ScanMode2[ScanMode2["SCAN_MODE_LOW_LATENCY"] = 2] = "SCAN_MODE_LOW_LATENCY";
  })(ScanMode || (ScanMode = {}));
  var ConnectionPriority;
  (function(ConnectionPriority2) {
    ConnectionPriority2[ConnectionPriority2["CONNECTION_PRIORITY_BALANCED"] = 0] = "CONNECTION_PRIORITY_BALANCED";
    ConnectionPriority2[ConnectionPriority2["CONNECTION_PRIORITY_HIGH"] = 1] = "CONNECTION_PRIORITY_HIGH";
    ConnectionPriority2[ConnectionPriority2["CONNECTION_PRIORITY_LOW_POWER"] = 2] = "CONNECTION_PRIORITY_LOW_POWER";
  })(ConnectionPriority || (ConnectionPriority = {}));

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/bleClient.js
  init_dist();
  init_conversion();

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/plugin.js
  init_dist();
  var BluetoothLe = registerPlugin("BluetoothLe", {
    web: () => Promise.resolve().then(() => (init_web(), web_exports)).then((m) => new m.BluetoothLeWeb())
  });

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/queue.js
  var makeQueue = () => {
    let currentTask = Promise.resolve();
    return (fn) => new Promise((resolve, reject) => {
      currentTask = currentTask.then(() => fn()).then(resolve).catch(reject);
    });
  };
  function getQueue(enabled) {
    if (enabled) {
      return makeQueue();
    }
    return (fn) => fn();
  }

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/validators.js
  function parseUUID(uuid) {
    if (typeof uuid !== "string") {
      throw new Error(`Invalid UUID type ${typeof uuid}. Expected string.`);
    }
    uuid = uuid.toLowerCase();
    const is128BitUuid = uuid.search(/^[0-9a-f]{8}\b-[0-9a-f]{4}\b-[0-9a-f]{4}\b-[0-9a-f]{4}\b-[0-9a-f]{12}$/) >= 0;
    if (!is128BitUuid) {
      throw new Error(`Invalid UUID format ${uuid}. Expected 128 bit string (e.g. "0000180d-0000-1000-8000-00805f9b34fb").`);
    }
    return uuid;
  }

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/bleClient.js
  var BleClientClass = class {
    constructor() {
      this.scanListener = null;
      this.eventListeners = /* @__PURE__ */ new Map();
      this.queue = getQueue(true);
    }
    enableQueue() {
      this.queue = getQueue(true);
    }
    disableQueue() {
      this.queue = getQueue(false);
    }
    async initialize(options) {
      await this.queue(async () => {
        await BluetoothLe.initialize(options);
      });
    }
    async isEnabled() {
      const enabled = await this.queue(async () => {
        const result = await BluetoothLe.isEnabled();
        return result.value;
      });
      return enabled;
    }
    async requestEnable() {
      await this.queue(async () => {
        await BluetoothLe.requestEnable();
      });
    }
    async enable() {
      await this.queue(async () => {
        await BluetoothLe.enable();
      });
    }
    async disable() {
      await this.queue(async () => {
        await BluetoothLe.disable();
      });
    }
    async startEnabledNotifications(callback) {
      await this.queue(async () => {
        var _a;
        const key = `onEnabledChanged`;
        await ((_a = this.eventListeners.get(key)) === null || _a === void 0 ? void 0 : _a.remove());
        const listener = await BluetoothLe.addListener(key, (result) => {
          callback(result.value);
        });
        this.eventListeners.set(key, listener);
        await BluetoothLe.startEnabledNotifications();
      });
    }
    async stopEnabledNotifications() {
      await this.queue(async () => {
        var _a;
        const key = `onEnabledChanged`;
        await ((_a = this.eventListeners.get(key)) === null || _a === void 0 ? void 0 : _a.remove());
        this.eventListeners.delete(key);
        await BluetoothLe.stopEnabledNotifications();
      });
    }
    async isLocationEnabled() {
      const enabled = await this.queue(async () => {
        const result = await BluetoothLe.isLocationEnabled();
        return result.value;
      });
      return enabled;
    }
    async openLocationSettings() {
      await this.queue(async () => {
        await BluetoothLe.openLocationSettings();
      });
    }
    async openBluetoothSettings() {
      await this.queue(async () => {
        await BluetoothLe.openBluetoothSettings();
      });
    }
    async openAppSettings() {
      await this.queue(async () => {
        await BluetoothLe.openAppSettings();
      });
    }
    async setDisplayStrings(displayStrings) {
      await this.queue(async () => {
        await BluetoothLe.setDisplayStrings(displayStrings);
      });
    }
    async requestDevice(options) {
      options = options ? this.validateRequestBleDeviceOptions(options) : void 0;
      const result = await this.queue(async () => {
        const device = await BluetoothLe.requestDevice(options);
        return device;
      });
      return result;
    }
    async requestLEScan(options, callback) {
      options = this.validateRequestBleDeviceOptions(options);
      await this.queue(async () => {
        var _a;
        await ((_a = this.scanListener) === null || _a === void 0 ? void 0 : _a.remove());
        this.scanListener = await BluetoothLe.addListener("onScanResult", (resultInternal) => {
          const result = Object.assign(Object.assign({}, resultInternal), { manufacturerData: this.convertObject(resultInternal.manufacturerData), serviceData: this.convertObject(resultInternal.serviceData), rawAdvertisement: resultInternal.rawAdvertisement ? this.convertValue(resultInternal.rawAdvertisement) : void 0 });
          callback(result);
        });
        await BluetoothLe.requestLEScan(options);
      });
    }
    async stopLEScan() {
      await this.queue(async () => {
        var _a;
        await ((_a = this.scanListener) === null || _a === void 0 ? void 0 : _a.remove());
        this.scanListener = null;
        await BluetoothLe.stopLEScan();
      });
    }
    async getDevices(deviceIds) {
      if (!Array.isArray(deviceIds)) {
        throw new Error("deviceIds must be an array");
      }
      return this.queue(async () => {
        const result = await BluetoothLe.getDevices({ deviceIds });
        return result.devices;
      });
    }
    async getConnectedDevices(services) {
      if (!Array.isArray(services)) {
        throw new Error("services must be an array");
      }
      services = services.map(parseUUID);
      return this.queue(async () => {
        const result = await BluetoothLe.getConnectedDevices({ services });
        return result.devices;
      });
    }
    async getBondedDevices() {
      return this.queue(async () => {
        const result = await BluetoothLe.getBondedDevices();
        return result.devices;
      });
    }
    async connect(deviceId, onDisconnect, options) {
      await this.queue(async () => {
        var _a;
        if (onDisconnect) {
          const key = `disconnected|${deviceId}`;
          await ((_a = this.eventListeners.get(key)) === null || _a === void 0 ? void 0 : _a.remove());
          const listener = await BluetoothLe.addListener(key, () => {
            onDisconnect(deviceId);
          });
          this.eventListeners.set(key, listener);
        }
        await BluetoothLe.connect(Object.assign({ deviceId }, options));
      });
    }
    async createBond(deviceId, options) {
      await this.queue(async () => {
        await BluetoothLe.createBond(Object.assign({ deviceId }, options));
      });
    }
    async isBonded(deviceId) {
      const isBonded = await this.queue(async () => {
        const result = await BluetoothLe.isBonded({ deviceId });
        return result.value;
      });
      return isBonded;
    }
    async disconnect(deviceId) {
      await this.queue(async () => {
        await BluetoothLe.disconnect({ deviceId });
      });
    }
    async getServices(deviceId) {
      const services = await this.queue(async () => {
        const result = await BluetoothLe.getServices({ deviceId });
        return result.services;
      });
      return services;
    }
    async discoverServices(deviceId) {
      await this.queue(async () => {
        await BluetoothLe.discoverServices({ deviceId });
      });
    }
    async getMtu(deviceId) {
      const value = await this.queue(async () => {
        const result = await BluetoothLe.getMtu({ deviceId });
        return result.value;
      });
      return value;
    }
    async requestConnectionPriority(deviceId, connectionPriority) {
      await this.queue(async () => {
        await BluetoothLe.requestConnectionPriority({ deviceId, connectionPriority });
      });
    }
    async readRssi(deviceId) {
      const value = await this.queue(async () => {
        const result = await BluetoothLe.readRssi({ deviceId });
        return parseFloat(result.value);
      });
      return value;
    }
    async read(deviceId, service, characteristic, options) {
      service = parseUUID(service);
      characteristic = parseUUID(characteristic);
      const value = await this.queue(async () => {
        const result = await BluetoothLe.read(Object.assign({
          deviceId,
          service,
          characteristic
        }, options));
        return this.convertValue(result.value);
      });
      return value;
    }
    async write(deviceId, service, characteristic, value, options) {
      service = parseUUID(service);
      characteristic = parseUUID(characteristic);
      return this.queue(async () => {
        if (!(value === null || value === void 0 ? void 0 : value.buffer)) {
          throw new Error("Invalid data.");
        }
        let writeValue = value;
        if (Capacitor.getPlatform() !== "web") {
          writeValue = dataViewToHexString(value);
        }
        await BluetoothLe.write(Object.assign({
          deviceId,
          service,
          characteristic,
          value: writeValue
        }, options));
      });
    }
    async writeWithoutResponse(deviceId, service, characteristic, value, options) {
      service = parseUUID(service);
      characteristic = parseUUID(characteristic);
      await this.queue(async () => {
        if (!(value === null || value === void 0 ? void 0 : value.buffer)) {
          throw new Error("Invalid data.");
        }
        let writeValue = value;
        if (Capacitor.getPlatform() !== "web") {
          writeValue = dataViewToHexString(value);
        }
        await BluetoothLe.writeWithoutResponse(Object.assign({
          deviceId,
          service,
          characteristic,
          value: writeValue
        }, options));
      });
    }
    async readDescriptor(deviceId, service, characteristic, descriptor, options) {
      service = parseUUID(service);
      characteristic = parseUUID(characteristic);
      descriptor = parseUUID(descriptor);
      const value = await this.queue(async () => {
        const result = await BluetoothLe.readDescriptor(Object.assign({
          deviceId,
          service,
          characteristic,
          descriptor
        }, options));
        return this.convertValue(result.value);
      });
      return value;
    }
    async writeDescriptor(deviceId, service, characteristic, descriptor, value, options) {
      service = parseUUID(service);
      characteristic = parseUUID(characteristic);
      descriptor = parseUUID(descriptor);
      return this.queue(async () => {
        if (!(value === null || value === void 0 ? void 0 : value.buffer)) {
          throw new Error("Invalid data.");
        }
        let writeValue = value;
        if (Capacitor.getPlatform() !== "web") {
          writeValue = dataViewToHexString(value);
        }
        await BluetoothLe.writeDescriptor(Object.assign({
          deviceId,
          service,
          characteristic,
          descriptor,
          value: writeValue
        }, options));
      });
    }
    async startNotifications(deviceId, service, characteristic, callback, options) {
      service = parseUUID(service);
      characteristic = parseUUID(characteristic);
      await this.queue(async () => {
        var _a;
        const key = `notification|${deviceId}|${service}|${characteristic}`;
        await ((_a = this.eventListeners.get(key)) === null || _a === void 0 ? void 0 : _a.remove());
        const listener = await BluetoothLe.addListener(key, (event) => {
          callback(this.convertValue(event === null || event === void 0 ? void 0 : event.value));
        });
        this.eventListeners.set(key, listener);
        await BluetoothLe.startNotifications(Object.assign({
          deviceId,
          service,
          characteristic
        }, options));
      });
    }
    async stopNotifications(deviceId, service, characteristic) {
      service = parseUUID(service);
      characteristic = parseUUID(characteristic);
      await this.queue(async () => {
        var _a;
        const key = `notification|${deviceId}|${service}|${characteristic}`;
        await ((_a = this.eventListeners.get(key)) === null || _a === void 0 ? void 0 : _a.remove());
        this.eventListeners.delete(key);
        await BluetoothLe.stopNotifications({
          deviceId,
          service,
          characteristic
        });
      });
    }
    validateRequestBleDeviceOptions(options) {
      options = Object.assign({}, options);
      if (options.services) {
        options.services = options.services.map(parseUUID);
      }
      if (options.optionalServices) {
        options.optionalServices = options.optionalServices.map(parseUUID);
      }
      if (options.serviceData && Capacitor.getPlatform() !== "web") {
        options.serviceData = options.serviceData.map((filter) => Object.assign(Object.assign({}, filter), { serviceUuid: parseUUID(filter.serviceUuid), dataPrefix: toHexString(filter.dataPrefix), mask: toHexString(filter.mask) }));
      }
      if (options.manufacturerData) {
        if (Capacitor.getPlatform() !== "web") {
          options.manufacturerData = options.manufacturerData.map((filter) => Object.assign(Object.assign({}, filter), { dataPrefix: toHexString(filter.dataPrefix), mask: toHexString(filter.mask) }));
        } else {
          options.manufacturerData = options.manufacturerData.map((filter) => Object.assign(Object.assign({}, filter), { dataPrefix: toUint8Array(filter.dataPrefix), mask: toUint8Array(filter.mask) }));
        }
      }
      return options;
    }
    convertValue(value) {
      if (typeof value === "string") {
        return hexStringToDataView(value);
      } else if (value === void 0) {
        return new DataView(new ArrayBuffer(0));
      }
      return value;
    }
    convertObject(obj) {
      if (obj === void 0) {
        return void 0;
      }
      const result = {};
      for (const key of Object.keys(obj)) {
        result[key] = this.convertValue(obj[key]);
      }
      return result;
    }
  };
  var BleClient = new BleClientClass();

  // mobile/node_modules/@capacitor-community/bluetooth-le/dist/esm/index.js
  init_conversion();

  // mobile/src/ble-shim.js
  var copyView = (dv) => {
    const u = new Uint8Array(dv.buffer, dv.byteOffset, dv.byteLength);
    return new DataView(u.slice().buffer);
  };
  var toView = (v) => {
    if (v instanceof DataView) return copyView(v);
    if (ArrayBuffer.isView(v)) return new DataView(new Uint8Array(v.buffer, v.byteOffset, v.byteLength).slice().buffer);
    return new DataView(v.slice(0));
  };
  var inited = null;
  var init = () => inited = inited || BleClient.initialize({ androidNeverForLocation: true }).catch((e) => {
    inited = null;
    throw e;
  });
  var Characteristic = class extends EventTarget {
    constructor(dev, svc, uuid) {
      super();
      this.device = dev;
      this.service = svc;
      this.uuid = uuid;
      this.value = null;
    }
    async startNotifications() {
      await BleClient.startNotifications(this.device.id, this.service.uuid, this.uuid, (v) => {
        this.value = copyView(v);
        this.dispatchEvent(new Event("characteristicvaluechanged"));
      });
      return this;
    }
    async stopNotifications() {
      try {
        await BleClient.stopNotifications(this.device.id, this.service.uuid, this.uuid);
      } catch (e) {
      }
      return this;
    }
    async writeValue(buf) {
      const v = toView(buf);
      try {
        await BleClient.write(this.device.id, this.service.uuid, this.uuid, v);
      } catch (e) {
        await BleClient.writeWithoutResponse(this.device.id, this.service.uuid, this.uuid, v);
      }
    }
    writeValueWithResponse(b) {
      return this.writeValue(b);
    }
    writeValueWithoutResponse(b) {
      return BleClient.writeWithoutResponse(this.device.id, this.service.uuid, this.uuid, toView(b));
    }
    async readValue() {
      this.value = copyView(await BleClient.read(this.device.id, this.service.uuid, this.uuid));
      return this.value;
    }
  };
  var Service = class {
    constructor(dev, s) {
      this.device = dev;
      this.uuid = s.uuid.toLowerCase();
      this._chars = s.characteristics || [];
    }
    async getCharacteristic(uuid) {
      uuid = String(uuid).toLowerCase();
      if (!this._chars.find((c) => c.uuid.toLowerCase() === uuid)) throw new Error("Characteristic not found: " + uuid);
      return new Characteristic(this.device, this, uuid);
    }
  };
  var Gatt = class {
    constructor(dev) {
      this.device = dev;
      this.connected = false;
    }
    async connect() {
      await BleClient.connect(this.device.id, () => {
        this.connected = false;
        this.device.dispatchEvent(new Event("gattserverdisconnected"));
      }, { timeout: 15e3 });
      this.connected = true;
      return this;
    }
    async getPrimaryServices() {
      const list = await BleClient.getServices(this.device.id);
      return list.map((s) => new Service(this.device, s));
    }
    async getPrimaryService(uuid) {
      uuid = String(uuid).toLowerCase();
      const s = (await this.getPrimaryServices()).find((x) => x.uuid === uuid);
      if (!s) throw new Error("Service not found: " + uuid);
      return s;
    }
    disconnect() {
      this.connected = false;
      BleClient.disconnect(this.device.id).catch(() => {
      });
    }
  };
  var Device = class extends EventTarget {
    constructor(scan) {
      super();
      this.id = scan.device.deviceId;
      this.name = scan.device.name || scan.localName || "";
      this.gatt = new Gatt(this);
      this._mfd = /* @__PURE__ */ new Map();
      for (const k in scan.manufacturerData || {}) this._mfd.set(Number(k), copyView(scan.manufacturerData[k]));
    }
    async watchAdvertisements() {
      setTimeout(() => {
        const ev = new Event("advertisementreceived");
        ev.manufacturerData = this._mfd;
        this.dispatchEvent(ev);
      }, 0);
    }
  };
  var matches = (name, filters) => !filters || !filters.length || filters.some((f) => f.name && name === f.name || f.namePrefix && name.startsWith(f.namePrefix));
  async function requestDevice(opts = {}) {
    await init();
    const filters = opts.filters || [];
    return new Promise((resolve, reject) => {
      let done = false, best = null, graceT = null;
      const finish = (err, scan) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        clearTimeout(graceT);
        BleClient.stopLEScan().catch(() => {
        });
        err ? reject(err) : resolve(new Device(scan));
      };
      const timer = setTimeout(() => best ? finish(null, best) : finish(Object.assign(new Error("\u041A\u0443\u0431\u0438\u043A \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D"), { name: "NotFoundError" })), 2e4);
      BleClient.requestLEScan({ allowDuplicates: true }, (r) => {
        const name = r.device && r.device.name || r.localName || "";
        if (!name || !matches(name, filters)) return;
        const hasMfd = r.manufacturerData && Object.keys(r.manufacturerData).length > 0;
        if (!best || hasMfd) best = r;
        if (hasMfd) finish(null, r);
        else if (!graceT) graceT = setTimeout(() => finish(null, best), 1500);
      }).catch((e) => finish(e));
    });
  }
  if (Capacitor.isNativePlatform()) {
    const bluetooth = {
      requestDevice,
      getAvailability: async () => {
        try {
          await init();
          return await BleClient.isEnabled();
        } catch (e) {
          return false;
        }
      },
      getDevices: async () => []
    };
    try {
      Object.defineProperty(navigator, "bluetooth", { value: bluetooth, configurable: true });
    } catch (e) {
      navigator.bluetooth = bluetooth;
    }
    window.CG_NATIVE = Capacitor.getPlatform();
    document.documentElement.classList.add("native");
    const tick = async () => {
      let r = "skip";
      try {
        r = window.__cgAutoConnect ? await window.__cgAutoConnect() : "skip";
      } catch (e) {
      }
      setTimeout(tick, r === "fail" ? 2500 : 3e3);
    };
    window.addEventListener("load", () => setTimeout(tick, 1e3));
  }

  // mobile/src/updater.js
  init_dist();

  // mobile/node_modules/@capgo/capacitor-updater/dist/esm/index.js
  init_dist();

  // mobile/node_modules/@capgo/capacitor-updater/dist/esm/history.js
  var KEEP_FLAG_KEY = "__capgo_keep_url_path_after_reload";
  var HISTORY_STORAGE_KEY = "__capgo_history_stack__";
  var MAX_STACK_ENTRIES = 100;
  var isBrowser = typeof window !== "undefined" && typeof document !== "undefined" && typeof history !== "undefined";
  if (isBrowser) {
    const win = window;
    if (!win.__capgoHistoryPatched) {
      win.__capgoHistoryPatched = true;
      const isFeatureConfigured = () => {
        try {
          if (win.__capgoKeepUrlPathAfterReload) {
            return true;
          }
        } catch (_a) {
        }
        try {
          return window.localStorage.getItem(KEEP_FLAG_KEY) === "1";
        } catch (_b) {
          return false;
        }
      };
      const readStored = () => {
        try {
          const raw = window.sessionStorage.getItem(HISTORY_STORAGE_KEY);
          if (!raw) {
            return { stack: [], index: -1 };
          }
          const parsed = JSON.parse(raw);
          if (!parsed || !Array.isArray(parsed.stack) || typeof parsed.index !== "number") {
            return { stack: [], index: -1 };
          }
          return parsed;
        } catch (_a) {
          return { stack: [], index: -1 };
        }
      };
      const writeStored = (stack, index) => {
        try {
          window.sessionStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify({ stack, index }));
        } catch (_a) {
        }
      };
      const clearStored = () => {
        try {
          window.sessionStorage.removeItem(HISTORY_STORAGE_KEY);
        } catch (_a) {
        }
      };
      const normalize = (url) => {
        try {
          const base = url !== null && url !== void 0 ? url : window.location.href;
          const parsed = new URL(base instanceof URL ? base.toString() : base, window.location.href);
          return `${parsed.pathname}${parsed.search}${parsed.hash}`;
        } catch (_a) {
          return null;
        }
      };
      const trimStack = (stack, index) => {
        if (stack.length <= MAX_STACK_ENTRIES) {
          return { stack, index };
        }
        const start = stack.length - MAX_STACK_ENTRIES;
        const trimmed = stack.slice(start);
        const adjustedIndex = Math.max(0, index - start);
        return { stack: trimmed, index: adjustedIndex };
      };
      const runWhenReady = (fn) => {
        if (document.readyState === "complete" || document.readyState === "interactive") {
          fn();
        } else {
          window.addEventListener("DOMContentLoaded", fn, { once: true });
        }
      };
      let featureActive = false;
      let isRestoring = false;
      let restoreScheduled = false;
      const ensureCurrentTracked = () => {
        if (!featureActive) {
          return;
        }
        const stored = readStored();
        const current = normalize();
        if (!current) {
          return;
        }
        if (stored.stack.length === 0) {
          stored.stack.push(current);
          stored.index = 0;
          writeStored(stored.stack, stored.index);
          return;
        }
        if (stored.index < 0 || stored.index >= stored.stack.length) {
          stored.index = stored.stack.length - 1;
        }
        if (stored.stack[stored.index] !== current) {
          stored.stack[stored.index] = current;
          writeStored(stored.stack, stored.index);
        }
      };
      const record = (url, replace) => {
        if (!featureActive || isRestoring) {
          return;
        }
        const normalized = normalize(url);
        if (!normalized) {
          return;
        }
        let { stack, index } = readStored();
        if (stack.length === 0) {
          stack.push(normalized);
          index = stack.length - 1;
        } else if (replace) {
          if (index < 0 || index >= stack.length) {
            index = stack.length - 1;
          }
          stack[index] = normalized;
        } else {
          if (index >= stack.length - 1) {
            stack.push(normalized);
            index = stack.length - 1;
          } else {
            stack = stack.slice(0, index + 1);
            stack.push(normalized);
            index = stack.length - 1;
          }
        }
        ({ stack, index } = trimStack(stack, index));
        writeStored(stack, index);
      };
      const restoreHistory = () => {
        if (!featureActive || isRestoring) {
          return;
        }
        const stored = readStored();
        if (stored.stack.length === 0) {
          ensureCurrentTracked();
          return;
        }
        const targetIndex = stored.index >= 0 && stored.index < stored.stack.length ? stored.index : stored.stack.length - 1;
        const normalizedCurrent = normalize();
        if (stored.stack.length === 1 && normalizedCurrent === stored.stack[0]) {
          return;
        }
        const firstEntry = stored.stack[0];
        if (!firstEntry) {
          return;
        }
        isRestoring = true;
        try {
          history.replaceState(history.state, document.title, firstEntry);
          for (let i = 1; i < stored.stack.length; i += 1) {
            history.pushState(history.state, document.title, stored.stack[i]);
          }
        } catch (_a) {
          isRestoring = false;
          return;
        }
        isRestoring = false;
        const currentIndex = stored.stack.length - 1;
        const offset = targetIndex - currentIndex;
        if (offset !== 0) {
          history.go(offset);
        } else {
          history.replaceState(history.state, document.title, stored.stack[targetIndex]);
          window.dispatchEvent(new PopStateEvent("popstate"));
        }
      };
      const scheduleRestore = () => {
        if (!featureActive || restoreScheduled) {
          return;
        }
        restoreScheduled = true;
        runWhenReady(() => {
          restoreScheduled = false;
          restoreHistory();
        });
      };
      let originalPushState = null;
      let originalReplaceState = null;
      const popstateHandler = () => {
        if (!featureActive || isRestoring) {
          return;
        }
        const normalized = normalize();
        if (!normalized) {
          return;
        }
        const stored = readStored();
        const idx = stored.stack.lastIndexOf(normalized);
        if (idx >= 0) {
          stored.index = idx;
        } else {
          stored.stack.push(normalized);
          stored.index = stored.stack.length - 1;
        }
        const trimmed = trimStack(stored.stack, stored.index);
        writeStored(trimmed.stack, trimmed.index);
      };
      const patchHistory = () => {
        if (originalPushState && originalReplaceState) {
          return;
        }
        originalPushState = history.pushState;
        originalReplaceState = history.replaceState;
        history.pushState = function pushStatePatched(state, title, url) {
          const result = originalPushState === null || originalPushState === void 0 ? void 0 : originalPushState.call(history, state, title, url);
          record(url, false);
          return result;
        };
        history.replaceState = function replaceStatePatched(state, title, url) {
          const result = originalReplaceState === null || originalReplaceState === void 0 ? void 0 : originalReplaceState.call(history, state, title, url);
          record(url, true);
          return result;
        };
        window.addEventListener("popstate", popstateHandler);
      };
      const unpatchHistory = () => {
        if (originalPushState) {
          history.pushState = originalPushState;
          originalPushState = null;
        }
        if (originalReplaceState) {
          history.replaceState = originalReplaceState;
          originalReplaceState = null;
        }
        window.removeEventListener("popstate", popstateHandler);
      };
      const setFeatureActive = (enabled) => {
        if (featureActive === enabled) {
          if (featureActive) {
            ensureCurrentTracked();
            scheduleRestore();
          }
          return;
        }
        featureActive = enabled;
        if (featureActive) {
          patchHistory();
          ensureCurrentTracked();
          scheduleRestore();
        } else {
          unpatchHistory();
          clearStored();
        }
      };
      window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload", (event) => {
        var _a;
        const evt = event;
        const enabled = (_a = evt === null || evt === void 0 ? void 0 : evt.detail) === null || _a === void 0 ? void 0 : _a.enabled;
        if (typeof enabled === "boolean") {
          win.__capgoKeepUrlPathAfterReload = enabled;
          setFeatureActive(enabled);
        } else {
          win.__capgoKeepUrlPathAfterReload = true;
          setFeatureActive(true);
        }
      });
      setFeatureActive(isFeatureConfigured());
    }
  }

  // mobile/node_modules/@capgo/capacitor-updater/dist/esm/index.js
  init_definitions();
  var CapacitorUpdater = registerPlugin("CapacitorUpdater", {
    web: () => Promise.resolve().then(() => (init_web2(), web_exports2)).then((m) => new m.CapacitorUpdaterWeb())
  });

  // mobile/src/updater.js
  var UPDATE_BASE = "https://sk1lpi.github.io/cubeguide-updates/";
  var cmpVer = (a, b) => {
    const pa = String(a || "0").split(".").map((n) => parseInt(n, 10) || 0), pb = String(b || "0").split(".").map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
    return 0;
  };
  var myVer = () => window.CG_BUILD && window.CG_BUILD.version || "?";
  var esc = (t) => String(t || "").replace(/[<&]/g, (c) => c === "<" ? "&lt;" : "&amp;");
  var CSS = `
#cgUpdM{position:fixed;inset:0;z-index:3000;display:grid;place-items:center;padding:24px;background:rgba(3,5,9,.62);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);animation:cgF .18s ease}
#cgUpdM .box{width:min(360px,100%);background:var(--surface,#141922);color:var(--ink,#e9eef6);border-radius:22px;padding:22px 20px 18px;text-align:center;box-shadow:0 24px 60px rgba(0,0,0,.55);animation:cgP .22s cubic-bezier(.2,.9,.3,1.2)}
#cgUpdM .ic{width:54px;height:54px;margin:0 auto 12px;border-radius:16px;display:grid;place-items:center;background:var(--grad,linear-gradient(135deg,#6d8cff,#8f6dff));color:#fff}
#cgUpdM .ic svg{width:28px;height:28px}
#cgUpdM h3{margin:0 0 6px;font:700 19px/1.25 var(--display,system-ui);letter-spacing:-.01em}
#cgUpdM .v{font:600 13px var(--mono,monospace);color:var(--muted,#8592a6);margin-bottom:10px}
#cgUpdM .v b{color:var(--accent,#6d8cff)}
#cgUpdM .n{font-size:14px;line-height:1.45;color:var(--ink-dim,#c3ccda);margin:0 0 16px}
#cgUpdM .bar{height:12px;border-radius:99px;background:var(--tile-hi,#232b37);overflow:hidden;margin:6px 0 8px}
#cgUpdM .bar i{display:block;height:100%;width:0;border-radius:99px;background:var(--grad,linear-gradient(90deg,#6d8cff,#22d3ac));transition:width .25s ease}
#cgUpdM .pct{font:700 15px var(--mono,monospace);margin-bottom:4px}
#cgUpdM .st{font-size:13px;color:var(--muted,#8592a6);min-height:18px}
#cgUpdM .row{display:flex;gap:10px}
#cgUpdM button{flex:1;border:0;border-radius:14px;padding:13px 0;font:700 15px var(--font,system-ui);cursor:pointer}
#cgUpdM .later{background:var(--tile-hi,#232b37);color:var(--ink-dim,#c3ccda)}
#cgUpdM .go{background:var(--grad,linear-gradient(135deg,#6d8cff,#8f6dff));color:#fff}
#cgUpdM .err{color:var(--red,#ff5f6d);font-size:13px;margin:0 0 12px;word-break:break-word}
#cgUpdT{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(14px + env(safe-area-inset-bottom));z-index:2000;padding:9px 14px;border-radius:99px;
  background:var(--raise,#1a212c);color:var(--ink-dim,#c3ccda);font:600 12.5px var(--mono,monospace);box-shadow:0 8px 24px rgba(0,0,0,.4);white-space:nowrap;animation:cgF .2s ease}
#cgUpdT b{color:var(--accent,#6d8cff)}
@keyframes cgF{from{opacity:0}to{opacity:1}}
@keyframes cgP{from{opacity:0;transform:scale(.92)}to{opacity:1;transform:none}}`;
  function css() {
    if (!document.getElementById("cgUpdCss")) {
      const s = document.createElement("style");
      s.id = "cgUpdCss";
      s.textContent = CSS;
      document.head.appendChild(s);
    }
  }
  var ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 20h14"/></svg>';
  function modal(html) {
    css();
    let m = document.getElementById("cgUpdM");
    if (!m) {
      m = document.createElement("div");
      m.id = "cgUpdM";
      document.body.appendChild(m);
    }
    m.innerHTML = `<div class="box">${html}</div>`;
    return m;
  }
  var closeModal = () => {
    const m = document.getElementById("cgUpdM");
    if (m) m.remove();
  };
  function pill(html, ms) {
    css();
    let t = document.getElementById("cgUpdT");
    if (!t) {
      t = document.createElement("div");
      t.id = "cgUpdT";
      document.body.appendChild(t);
    }
    t.innerHTML = html;
    clearTimeout(pill._t);
    pill._t = setTimeout(() => t.remove(), ms || 2600);
  }
  function offer(L) {
    const m = modal(`<div class="ic">${ICON}</div><h3>\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u043D\u043E\u0432\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F!</h3>
    <div class="v">\u0443 \u0442\u0435\u0431\u044F v${esc(myVer())} \u2192 <b>v${esc(L.version)}</b></div>
    ${L.notes ? `<p class="n">${esc(L.notes)}</p>` : '<p class="n">\u041E\u0431\u043D\u043E\u0432\u0438, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 \u0438\u0441\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F.</p>'}
    <div class="row"><button class="later">\u041F\u043E\u0437\u0436\u0435</button><button class="go">\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C</button></div>`);
    m.querySelector(".later").onclick = closeModal;
    m.querySelector(".go").onclick = () => install(L);
  }
  var busy = false;
  async function install(L) {
    if (busy) return;
    busy = true;
    const m = modal(`<div class="ic">${ICON}</div><h3>\u041E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 v${esc(L.version)}</h3>
    <div class="bar"><i></i></div><div class="pct">0%</div><div class="st">\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u044E\u2026</div>`);
    const bar = m.querySelector(".bar i"), pct = m.querySelector(".pct"), st = m.querySelector(".st");
    const setP = (p) => {
      p = Math.max(0, Math.min(100, Math.round(p)));
      bar.style.width = p + "%";
      pct.textContent = p + "%";
    };
    let h = null, fake = 0, timer = null;
    timer = setInterval(() => {
      if (fake < 85) {
        fake += 3;
        if (fake > parseFloat(bar.style.width || 0)) setP(fake);
      }
    }, 250);
    try {
      h = await CapacitorUpdater.addListener("download", (e) => {
        if (e && e.percent != null) {
          fake = Math.max(fake, e.percent);
          setP(e.percent);
        }
      });
    } catch (e) {
    }
    try {
      const bundle = await withTimeout(CapacitorUpdater.download({
        url: new URL(L.url, UPDATE_BASE).href,
        version: L.version + "-" + L.build,
        checksum: L.checksum || ""
      }), 12e4, "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0430\u0441\u044C \u0437\u0430 2 \u043C\u0438\u043D\u0443\u0442\u044B");
      clearInterval(timer);
      setP(100);
      st.textContent = "\u0413\u043E\u0442\u043E\u0432\u043E! \u041F\u0435\u0440\u0435\u0437\u0430\u043F\u0443\u0441\u043A\u0430\u044E \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u2026";
      try {
        localStorage.setItem("cg-upd-from", myVer());
      } catch (e) {
      }
      await new Promise((r) => setTimeout(r, 700));
      await CapacitorUpdater.set({ id: bundle.id });
    } catch (e) {
      clearInterval(timer);
      const msg = e && (e.message || e.errorMessage) || String(e);
      const mm = modal(`<div class="ic">${ICON}</div><h3>\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C</h3>
      <p class="err">${esc(msg)}</p>
      <div class="row"><button class="later">\u0417\u0430\u043A\u0440\u044B\u0442\u044C</button><button class="go">\u0415\u0449\u0451 \u0440\u0430\u0437</button></div>`);
      mm.querySelector(".later").onclick = closeModal;
      mm.querySelector(".go").onclick = () => install(L);
    } finally {
      busy = false;
      if (h && h.remove) h.remove();
    }
  }
  var withTimeout = (p, ms, msg) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(msg)), ms))]);
  var checking = false;
  async function check(manual) {
    if (checking) return;
    checking = true;
    try {
      const mine = window.CG_BUILD && +window.CG_BUILD.at || 0;
      const r = await fetch(UPDATE_BASE + "latest.json?t=" + Date.now(), { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const L = await r.json();
      if (!(+L.build > mine)) {
        pill(`CubeGuide <b>v${esc(myVer())}</b> \xB7 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u2713`, manual ? 3500 : 2600);
        return;
      }
      const cur = await withTimeout(CapacitorUpdater.current(), 5e3, "timeout").catch(() => null);
      if (L.minNative && cur && cur.native && cmpVer(cur.native, L.minNative) < 0) {
        const m = modal(`<div class="ic">${ICON}</div><h3>\u0412\u044B\u0448\u043B\u0430 v${esc(L.version)}</h3>
        <p class="n">\u042D\u0442\u0443 \u0432\u0435\u0440\u0441\u0438\u044E \u043D\u0443\u0436\u043D\u043E \u043F\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0437\u0430\u043D\u043E\u0432\u043E (Sideloadly \u043D\u0430 \u043A\u043E\u043C\u043F\u044C\u044E\u0442\u0435\u0440\u0435 / \u043D\u043E\u0432\u044B\u0439 .apk). \u0423 \u0442\u0435\u0431\u044F v${esc(myVer())}.</p>
        <div class="row"><button class="go">\u041F\u043E\u043D\u044F\u043B</button></div>`);
        m.querySelector(".go").onclick = closeModal;
        return;
      }
      offer(L);
    } catch (e) {
      console.warn("update check failed", e);
      if (manual) pill("\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u2014 \u043D\u0435\u0442 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442\u0430?", 3500);
    } finally {
      checking = false;
    }
  }
  function showVersion() {
    const foot = document.querySelector(".skin-foot");
    if (foot && !document.getElementById("cgVer")) {
      const p = document.createElement("p");
      p.id = "cgVer";
      p.style.cssText = "margin:0;padding:10px 20px 14px;text-align:center;font:500 12px var(--mono,monospace);color:var(--muted,#8592a6)";
      p.innerHTML = `CubeGuide v${esc(myVer())} \xB7 <u style="cursor:pointer">\u043F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F</u>`;
      p.querySelector("u").onclick = () => check(true);
      foot.parentNode.insertBefore(p, foot);
    }
    let from = null;
    try {
      from = localStorage.getItem("cg-upd-from");
      localStorage.removeItem("cg-upd-from");
    } catch (e) {
    }
    if (from && from !== myVer()) {
      pill(`\u041E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u043E: v${esc(from)} \u2192 <b>v${esc(myVer())}</b> \u2713`, 4e3);
      return true;
    }
    return false;
  }
  if (Capacitor.isNativePlatform()) {
    CapacitorUpdater.notifyAppReady().catch(() => {
    });
    window.CG_CHECK_UPDATE = () => check(true);
    window.addEventListener("load", () => {
      const justUpdated = showVersion();
      setTimeout(() => check(false), justUpdated ? 4500 : 1200);
    });
    let hiddenAt = 0;
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) hiddenAt = Date.now();
      else if (hiddenAt && Date.now() - hiddenAt > 10 * 60 * 1e3) check(false);
    });
  }
})();
/*! Bundled license information:

@capacitor/core/dist/index.js:
  (*! Capacitor: https://capacitorjs.com/ - MIT License *)
*/
